#!/usr/bin/env bash
# Phase 1: Download and prepare the local LanguageTool server.
# Run this ON YOUR MACHINE (Linux Mint), not in any sandbox.
#
# What this does:
#   1. Checks you have Java (you do, OpenJDK works fine, LT needs Java 17+)
#   2. Downloads LanguageTool standalone server (the official build)
#   3. Unpacks it to ~/.local/share/ibus-local-grammar/languagetool/
#   4. Does NOT start it yet -- that's the next script

set -euo pipefail

INSTALL_DIR="$HOME/.local/share/ibus-local-grammar"
LT_DIR="$INSTALL_DIR/languagetool"
LT_VERSION="6.5"  # check https://languagetool.org/download/ for current stable
LT_URL="https://languagetool.org/download/LanguageTool-stable.zip"

echo "== Checking Java version =="
java -version

JAVA_MAJOR=$(java -version 2>&1 | head -1 | sed -E 's/.*version "([0-9]+).*/\1/')
if [ "$JAVA_MAJOR" -lt 17 ]; then
    echo "ERROR: LanguageTool needs Java 17+. You have Java $JAVA_MAJOR."
    echo "Install with: sudo apt install openjdk-21-jre-headless"
    exit 1
fi

mkdir -p "$INSTALL_DIR"
cd "$INSTALL_DIR"

if [ -d "$LT_DIR" ]; then
    echo "LanguageTool dir already exists at $LT_DIR -- skipping download."
    echo "Delete it first if you want a clean re-download."
    exit 0
fi

echo "== Downloading LanguageTool (this is ~250MB, may take a few minutes) =="
curl -L -o LanguageTool-stable.zip "$LT_URL"

echo "== Unzipping =="
unzip -q LanguageTool-stable.zip
# The zip extracts to a versioned folder name like LanguageTool-6.5
EXTRACTED=$(find . -maxdepth 1 -type d -name "LanguageTool-*" | head -1)
mv "$EXTRACTED" "$LT_DIR"
rm LanguageTool-stable.zip

echo "== Done =="
echo "LanguageTool installed at: $LT_DIR"
echo "Next: run scripts/test_languagetool.sh"
