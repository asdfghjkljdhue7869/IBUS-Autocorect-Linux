#!/usr/bin/env bash
# Phase 1 test: start the LanguageTool HTTP server and confirm it works.
# Run this AFTER setup_languagetool.sh has completed successfully.
#
# This starts LT in the FOREGROUND so you can see logs and Ctrl+C to stop it.
# We'll wrap it as a proper background daemon/systemd service in a later phase.

set -euo pipefail

INSTALL_DIR="$HOME/.local/share/ibus-local-grammar"
LT_DIR="$INSTALL_DIR/languagetool"
PORT=8081

if [ ! -d "$LT_DIR" ]; then
    echo "ERROR: LanguageTool not found at $LT_DIR"
    echo "Run setup_languagetool.sh first."
    exit 1
fi

echo "== Starting LanguageTool server on port $PORT =="
echo "(Ctrl+C to stop once you've confirmed it works)"
echo ""

cd "$LT_DIR"
java -cp languagetool-server.jar org.languagetool.server.HTTPServer \
    --port "$PORT" \
    --allow-origin "*" &
LT_PID=$!

echo "Server starting (PID $LT_PID), waiting for it to come up..."

# Wait up to 30 seconds for the server to respond
for i in $(seq 1 30); do
    if curl -s "http://localhost:$PORT/v2/languages" > /dev/null 2>&1; then
        echo "Server is up after ${i}s."
        break
    fi
    sleep 1
done

echo ""
echo "== Test 1: list supported languages (should include English variants and Hungarian) =="
curl -s "http://localhost:$PORT/v2/languages" | python3 -m json.tool | grep -iE '"name"|"longCode"' | grep -iE 'english|hungarian|british'

echo ""
echo "== Test 2: check a sentence with a deliberate grammar error =="
curl -s --data "language=en-GB&text=He don't like coffee, and there is many problem with it." \
    "http://localhost:$PORT/v2/check" | python3 -m json.tool | head -60

echo ""
echo "== If you see 'matches' above with actual error descriptions, LanguageTool is working. =="
echo "Press Ctrl+C to stop the server, or leave it running and open a new terminal."

wait $LT_PID
