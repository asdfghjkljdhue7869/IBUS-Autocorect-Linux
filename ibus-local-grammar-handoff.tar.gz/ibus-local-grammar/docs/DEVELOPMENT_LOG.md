# Development Log

A plain-language running record of what we've found and decided, in order.
This is the "what happened and why" file -- append-only, newest at the bottom.
Generated via terminal heredoc commands as the project progresses.

---

## Entry 1 -- Phase 1: LanguageTool (English grammar engine)

**Date context:** early build, Phase 1.

- Got LanguageTool (stable, version 6.6) running locally as an HTTP server
  on port 8081.
- Confirmed it correctly detects real grammar errors (tested with "He don't
  like coffee, and there is many problem with it." -- caught the
  subject-verb agreement error correctly).
- Confirmed English (GB) plus other English variants are supported.
- Measured real performance: first request ~4.3 seconds (one-time JVM
  warmup), every request after that ~89-113ms. That's fast enough to feel
  responsive once warmed up.
- Switched from an accidentally-grabbed development snapshot build (6.9-SNAPSHOT)
  to the official stable release (6.6), because the snapshot was missing
  Hungarian and we needed to rule out "snapshot is just incomplete" as an
  explanation.

**Conclusion: LanguageTool fully works for English. Confirmed and tested
on the actual target machine, not just in theory.**

---

## Entry 2 -- The Hungarian problem

- Checked LanguageTool's complete supported-language list directly from
  the running server. Hungarian is not in it. Not on the snapshot build,
  not on the stable release. This isn't a download or config issue --
  LanguageTool genuinely does not support Hungarian grammar checking,
  full stop.
- Hungarian spelling is unaffected by this -- that's a separate tool
  (Hunspell) and Hungarian Hunspell dictionaries are mature and have
  existed for years.
- So the real gap is specifically: Hungarian *grammar* checking, not
  spelling.

**Decision made:** rather than ship English-only or settle for
Hungarian-spelling-only, look for a separate Hungarian grammar tool and
figure out how to plug it in alongside LanguageTool.

---

## Entry 3 -- Finding "Magyar mondatellenőrző" (Lightproof for Hungarian)

- Found a real, actively maintained (last release: 2025-06-08) open-source
  Hungarian grammar/proofreading tool, distributed as a LibreOffice
  extension, built on something called "Lightproof."
- Licensed under MPL (Mozilla Public License) -- compatible with our
  GPL-3.0 project since we're calling it as a separate component, not
  statically linking code together.
- Downloaded the extension package (.oxt file, which is just a zip) and
  looked inside.

**What we found inside:**
- The actual grammar rules are a plain Python list of regex-based rules
  in `lightproof_lightproof_hu.py`. Each rule is a 5-part pattern: the
  regex to match, what to replace it with, a human-readable error message,
  an optional condition, and a priority number.
- This is genuinely substantial, well-built linguistic work -- comma
  rules, date formatting, capitalization, compound word hyphenation,
  geographic name conventions, suffix vowel harmony, and dozens more
  real Hungarian grammar patterns. Not a toy.
- The catch: some of these rules don't just use plain regex. They call
  helper functions like `morph()`, `stem()`, and `spell()` that need
  real Hungarian morphological analysis (i.e. understanding word forms,
  not just pattern matching). In the original extension, those functions
  go through LibreOffice's internal plumbing (something called "UNO,"
  LibreOffice's API bridge) to ask LibreOffice's own spellchecker for
  that analysis.

**The real question this raised:** can we get that same morphological
analysis without needing LibreOffice running in the background? Because
if not, this whole approach falls apart -- we'd be dragging in an entire
office suite just to check grammar in the background.

---

## Entry 4 -- Solving the morphology question

- Installed Hungarian Hunspell (the spell-checking engine, separate from
  LibreOffice) to test directly.
- First attempt used Hunspell's standard "-a" mode (its normal
  spell-check interface). This only returned yes/no-style results, not
  the rich grammatical detail the Lightproof rules needed. Looked like a
  dead end at first.
- Hit and fixed an unrelated technical snag: Hungarian text was getting
  garbled because the proper Hungarian language settings ("locale") weren't
  installed. Fixed by installing and generating the hu_HU.UTF-8 locale.
- Found the real answer: Hunspell has a separate, different mode (the
  "-m" flag, for "morphological analysis") that's specifically built for
  this. Testing it gave results like:
    - "ház" (house) -> stem: ház, part of speech: noun, case: nominative
    - "kellett" (was needed -- correct spelling) -> stem: kell, verb,
      past tense
    - "kellet" (common misspelling of the above) -> different stem
      entirely, confirming Hunspell can tell these apart
    - "megint" -> correctly returned TWO possible readings (it can mean
      "again" as an adverb, OR be a verb form of "to warn") -- this kind
      of double-meaning detection is exactly what some of the Lightproof
      rules are designed to catch.

**Conclusion: this works.** The same morphological depth LibreOffice was
using internally is directly available through plain Hunspell on the
command line, no LibreOffice installation required. This means the
Hungarian grammar checker can run as its own lightweight, independent
piece -- not bolted onto a whole office suite.

---

## Entry 5 -- Where things stand now

**Confirmed and working:**
- English grammar + spelling: LanguageTool, tested and fast.
- Hungarian grammar rules: real, substantial rule set extracted from an
  actively maintained open-source tool, MPL-licensed.
- Hungarian morphological analysis: confirmed possible without
  LibreOffice, via Hunspell's `-m` mode.

**Real work still ahead (not yet built):**
- Writing the small piece of code that translates Hunspell's `-m` output
  format into exactly what the Lightproof rules expect when they call
  `morph()`, `stem()`, `spell()`.
- Making this fast enough to run live as someone types (likely by
  keeping one Hunspell process running continuously and feeding it words,
  rather than starting a new process per word, which would be slow).
- A few rules use a `calc()` helper for things like unit conversion --
  separate from the morphology question, should be straightforward to
  port as-is.
- Proper attribution to the original Lightproof/Hungarian grammar checker
  authors in our project, since we're directly reusing their rule data.

**Project structure decision:** this Hungarian grammar piece is being
treated as its own build phase ("Phase 1B"), completed before moving on
to building the actual IBus engine (the part that hooks into the
operating system and shows underlines while typing). Both language
backends (English via LanguageTool, Hungarian via the extracted
Lightproof rules + Hunspell) will exist and be tested independently
before we build the thing that calls them.

---

## Entry 8 -- Two fixes from real feedback, both automated rather than hand-tested

- The user gave direct, specific feedback after reviewing the real logs
  from the previous test session (also referencing a separate
  conversation they'd had about this same project): checking spelling
  on every single keystroke while still typing a word is wasteful and
  would eventually cause a real annoyance -- a word like "prog" would
  flash as misspelled while someone is still in the middle of typing
  "programming". Fixed: the engine now only checks a word once a space
  has just been typed after it, not while its letters are still being
  typed.
- While fixing that, found and fixed a real bug introduced by the fix
  itself: a leftover piece of old code was silently undoing the new
  behavior in exactly the one situation it was meant to handle. This
  was caught because an automated test was written for the new
  behavior rather than just eyeballing the change -- the test failed,
  which is exactly what a test is for, and pointed straight at the bug.
- Separately, finished the next planned step on the "reopen a
  previously-typed word when the cursor moves back into it" detection
  logic: it now correctly fires only ONCE when the cursor lands exactly
  on a word's edge via a single arrow-key press or backspace/delete,
  instead of re-triggering on every individual step while moving
  through a word with repeated key presses. This matches how the real,
  mature reference engine (ibus-typing-booster) does it.
- At the user's request, both of these fixes are now covered by
  automated tests instead of needing manual retesting on the real
  machine -- this logic is pure text/cursor-position math with no
  dependency on a live desktop session, so there's no good reason to
  spend the user's time manually retyping the same scenarios over and
  over. 23 automated tests now exist and all pass.

**Conclusion: detection logic is meaningfully more correct and more
efficient now, confirmed by tests that can be re-run in seconds any
time this code changes again, without needing the user's machine. The
rendering question (how to safely show this visually) remains the one
piece still requiring a fresh, careful design, paused since the
document-corruption incident in Entry 7.**

---

## Entry 9 -- Bilingual spelling detection now works, including the original "van" problem

- Tested a standard, widely-used statistical language detector
  (python3-langdetect) directly against real single words. It was
  unusable: "hello" detected as Finnish, "kutya" (Hungarian for "dog")
  detected as Swahili, and "van" -- the exact English/Hungarian
  ambiguous case raised at the very start of this project -- detected
  as Afrikaans. This isn't a minor inaccuracy; statistical detectors
  fundamentally need much more text than one word to mean anything.
- Built a different, much more reliable approach instead: ask both the
  English and Hungarian spelling dictionaries directly whether they
  recognize a word, and use that as the real signal. For genuinely
  ambiguous words (recognized by both languages, or by neither), fall
  back to whatever language the rest of the current sentence has
  mostly been -- a far better-justified guess than statistics on a
  single short word.
- Wired this into the actual engine: it now checks spelling against
  the correct language's dictionary automatically, word by word, with
  no manual switching needed.
- Directly verified the original "van" problem is now solved both
  ways: "I bought a van" correctly recognizes "van" as English (a
  vehicle); "A kutya itt van" correctly recognizes "van" as Hungarian
  (part of the sentence meaning "the dog is here"). Both are correctly
  NOT flagged as errors, because both are genuinely correct words in
  their respective languages.
- All of this is covered by 44 automated tests now, all passing,
  re-runnable in seconds without needing the real machine.

**Conclusion: at the user's request, "fully working" detection (before
moving on to rendering) was scoped as bilingual spelling PLUS full
sentence-level grammar checking. Bilingual spelling detection is now
done and verified. Sentence-level grammar checking (wiring in
LanguageTool for English and the custom Hungarian engine from Phase 1B,
plus sensible throttling so it doesn't run too often while typing
quickly) is the next and final piece before detection can be called
complete.**

---

## Entry 10 -- Detection is now "fully working": spelling AND grammar, both languages

- Added the last missing piece: full sentence-level grammar checking,
  not just single-word spelling. The engine now watches for natural
  pauses in typing and, once it detects one, checks the whole current
  sentence -- not just the most recent word -- against the right
  grammar engine for whatever language that sentence is in.
- This deliberately waits for a short pause (about 0.7 seconds) after
  the last word before actually running the grammar check, rather than
  checking after every single word. Grammar checking is much heavier
  than spelling checking, so this avoids it ever needing to run faster
  than someone can comfortably read its results anyway, and avoids
  wasting effort on checks that would just get immediately superseded
  by the next word.
- Found and fixed two real, subtle bugs while building this, both
  involving sentences that end with a period -- which is to say,
  basically all real sentences. In short: the code that decides "where
  does the current sentence end" was getting confused by the period
  itself, and would sometimes conclude the sentence that was JUST
  finished was actually empty, silently skipping it entirely. Both
  bugs were caught by testing with a normal, realistic sentence (one
  that actually ends in a period) rather than a conveniently simple
  test case, and were fixed before this ever needed to be tested on
  the real machine.
- Confirmed working end to end, fully automatically: typed a real
  Hungarian sentence with a real grammar mistake (missing comma)
  word by word, with realistic pauses between words, and the system
  correctly waited for the pause at the end, correctly figured out it
  was a Hungarian sentence, and correctly caught the missing comma --
  all without any manual intervention.
- The English half of this (using LanguageTool) is built and tested
  the same way, but using a stand-in fake server rather than the real
  one, since the real LanguageTool program isn't available in this
  building environment. It correctly fails safely (no crash, a single
  clear note in the log) when there's nothing to connect to, which is
  exactly the expected, honest behavior given that limitation. The
  real LanguageTool connection was already proven to work back in an
  earlier phase, on the user's own machine -- this current work
  doesn't change that part, just connects to it properly.

**Conclusion: this completes the scope the user explicitly asked for
under "I want it to first work" -- bilingual spelling AND full
sentence-level grammar checking, both languages, automatically routed,
properly paced so it doesn't run wastefully. Everything is still
detection-only; nothing is drawn on screen yet. Rendering is the one
remaining piece, still paused since the earlier document-corruption
incident, pending a careful, safe redesign.**

---

## Entry 11 -- Confirming the real LanguageTool connection still works

- Went to manually verify the English grammar path against a real,
  live LanguageTool server (rather than the stand-in fake one used for
  automated testing). Hit a "port already in use" error -- a
  LanguageTool server from an earlier session was apparently still
  running in the background and had never been stopped. Not a new bug,
  just a leftover process from previous testing.
- Cleared the stuck process and restarted cleanly to continue the
  real-server verification.
- Confirmed: with a real, live LanguageTool server running, the full
  pipeline test suite passes against it directly -- no mock involved.
  The English grammar check correctly reached the real server, waited
  for its real response (a few seconds, likely due to the server
  having just been freshly restarted), and correctly reported no
  errors for a grammatically correct test sentence. This confirms the
  real integration works end to end, not just against the stand-in
  fake server used for automated testing.

**Conclusion: the one remaining unverified piece from Entry 10 -- the
real LanguageTool server connection -- is now confirmed working on the
real machine. Detection (spelling + grammar, both languages) is fully
verified end to end, real backends, real timing, real machine. Moving
on to the rendering redesign next.**

---

## Entry 12 -- First rendering attempt since the corruption incident, built carefully and switched off by default

- Studied the real, proven rendering approach used by the mature
  reference engine in detail: remove the already-typed word from the
  document, then immediately redraw that same word as fresh, in-
  progress text with the colored underline attached, then put it back
  exactly as it was. This is fundamentally different from the earlier
  broken approach, which tried to relabel text that was already
  considered "finished" -- this new approach genuinely treats it as
  freshly in-progress again, which is what caused the previous
  approach to fail.
- Found, while reading their real code, a specific and non-obvious
  safety step they had to add after hard experience: sometimes,
  removing text doesn't visually disappear right away unless something
  else forces the display to refresh first. Copied this same safety
  step rather than skipping it, since it came from a real, documented
  bug report, not a guess.
- Built this very narrowly and cautiously on purpose: for now, it only
  proves that removing the word and immediately putting it back
  (unchanged, with the new colored-underline styling) is safe and
  leaves the document exactly as it was -- it does NOT yet let someone
  actually edit the word while this is happening. That bigger, riskier
  step comes later, only after this safer foundation is confirmed
  solid.
- The new code is switched off by default behind a clearly named
  on/off switch, and confirmed -- not just assumed -- to never actually
  run while switched off, using an automated test built specifically to
  check that. All 66 existing automated tests still pass unchanged with
  this new, currently-dormant code present.

**Conclusion: this is ready for a careful, supervised test on the real
machine, in the scratch file only, by switching the on/off flag from
off to on. Given what happened last time real rendering was attempted,
this should be treated as a genuine "let's see what breaks" moment,
same spirit as before, just in a place where breaking it costs
nothing.**

---

## Entry 13 -- First successful real rendering test: safe, with a minor caveat

- Ran the gated delete-redraw-recommit test on the real machine, in
  the scratch file, with real (somewhat messy, realistic) typing:
  landing on several different words, including single-character ones,
  going back and forth multiple times.
- Result: every single reopen-and-recommit cycle completed safely.
  Text matched what was expected afterward every time -- no
  duplication, no loss, nothing like the earlier corruption incident.
  This is a genuinely different and much better outcome than the first
  rendering attempt.
- One minor, honestly-reported caveat: a barely-noticeable visual
  flicker was occasionally felt during the reopen moments, though
  rarely and not disruptively. This is expected to some degree, since
  real character-level removal and retyping is happening very quickly
  at the operating-system level -- the key result is that it never
  caused any actual incorrect end state, only a possible brief visual
  blip.
- Not yet directly confirmed: whether the colored underline styling
  itself was visible at all during the brief moment a word was
  reopened -- the cycle happens fast enough that this needs a
  deliberately slowed-down or held-open test to actually see it,
  rather than relying on noticing it during fast, natural typing.

**Conclusion: the core safety property (no document corruption) is
holding up under real, varied testing. The next thing to verify is
whether the visual styling itself is actually visible and looks right,
which needs a different kind of test than this one -- something that
holds the reopened state open long enough to actually look at it,
rather than completing in a fraction of a second.**

---

## Entry 14 -- Real corruption found with the slow-motion visual test, different cause than before

- Ran the slow-motion (2-second delay) version of the rendering test to
  try to actually see the underline styling. This intentionally held
  each reopened word "open" much longer than normal.
- This surfaced a real, different bug: while one word was still in its
  held-open state, continued typing triggered ADDITIONAL reopens on
  other words before the first one had finished. These overlapping,
  simultaneous reopen-and-recommit cycles interfered with each other
  and produced real, visible text corruption in the document --
  garbled, duplicated fragments of text.
- This is a different root cause than the first corruption incident.
  That one was a feedback loop on a single word. This one is a missing
  safeguard against MULTIPLE reopens happening at the same time. The
  fast version (immediate recommit) happened to avoid this by accident
  -- each cycle finished so quickly that a second one rarely started
  before the first was done. The slow-motion test removed that
  accidental protection and exposed the real, underlying gap.
- This is a well-understood, fixable kind of bug: the next step is
  adding an explicit check that refuses to start a new reopen while one
  is still in progress, rather than relying on speed alone to avoid
  collisions.

**Conclusion: real, valuable finding from deliberately slowing things
down to see more clearly -- exactly what this test was for. The
underlying delete-redraw-recommit mechanism itself is not necessarily
wrong, but it currently has no protection against being triggered
multiple times concurrently, which the slow-motion test exposed clearly
where the fast version was hiding it. This needs a fix before any
further visual or slow-motion testing.**

---

## Entry 15 -- Decision: drop the cursor-reopen mechanism, clarified actual product goal

- Tested the concurrency guard from Entry 14 with a much longer
  artificial delay (2 seconds) to really stress it. The guard itself
  worked correctly -- no more of the interleaving corruption from
  before. But a deeper, related problem remained: typing normally
  during the time a word is held "open" lands on a document that's
  temporarily in an in-between state (the word removed, not yet put
  back), which still produced wrong end results, just through a
  different, less severe mechanism than before.
- This led to an important product clarification: the actual desired
  experience is closer to Grammarly's real behavior -- finish writing a
  sentence, then see underlines on errors, hover or click to accept a
  fix, move to the next one. Explicitly NOT wanted: phone-style
  autocorrect that silently changes words while still typing them.
- Given that, the cursor-reopen mechanism (re-checking a word the
  instant the cursor moves back into it) turned out not to be needed
  for the actual desired experience at all -- Grammarly itself mostly
  works on completed sentences and pauses, not live cursor tracking.
  The only thing the risky mechanism would have added is a minor
  freshness improvement (seeing a word re-checked instantly when
  clicking back into it, rather than after finishing the sentence),
  which isn't worth its demonstrated fragility.
- Decision: drop the cursor-reopen mechanism for now. Focus instead on
  the safe, already-proven path -- checking and underlining completed
  sentences -- and build the actual desired hover-to-fix experience on
  top of that, rather than continuing to chase a much harder problem
  that doesn't serve the real product goal.

**Conclusion: this is a genuine scope simplification, not a setback.
The hard-won lessons from the reopen experiments (the real IBus
mechanics, the delete/redraw/recommit pattern, the debounce/guard
patterns) remain valuable and may be revisited later, but they are not
on the critical path for the actual desired product experience. Next:
design the completed-sentence underline + hover-to-fix mechanism
properly.**

---

## Entry 16 -- Real product scope locked in: Grammarly-style, Android-bubble-style suggestions

After discussion, the actual target experience is now concrete:

1. **Detection**: re-scan fresh each time, including a NEW capability --
   scanning an entire already-open document for existing errors when it
   first opens, not just checking text as it's freshly typed. No
   positional memory needed between sessions.
2. **Ignore-list**: a simple, toggleable personal list of words the user
   has told the system to stop flagging. No document-position tracking
   needed -- just "don't flag this specific word again."
3. **Suggestion UI**: modeled on Android's text-selection bubble --
   2-3 suggested replacement words plus a dismiss ("X") option, shown
   near a flagged word. IBus has an existing, proven mechanism for
   exactly this shape of UI (its lookup-table / candidate-list
   feature, the same one used for word-completion popups), so this
   isn't a from-scratch UI -- it's using a real, existing primitive.
4. **App priority**: Kate first, confirmed explicitly; Brave and others
   later.

**This is a real, significant scope reduction from the "persistent
overlay window with cross-session document-position memory" version
discussed earlier in this same conversation.** That harder version is
explicitly the long-term goal but is being set aside for now in favor
of this more achievable version, with the door deliberately left open
to revisit the harder version later.

**Decision: the cursor-reopen mechanism built and tested in Entries
11-15 is retired for now.** It solved a different problem (relabeling
text while actively navigating back into it) that turned out not to be
needed for this actual target experience. The code and lessons learned
remain in git history but won't be built on further for the time being.

**Build order agreed: (1) whole-document scanning capability -- pure
backend, fully testable without real-machine involvement; (2) the
ignore-list mechanism -- also pure backend; (3) the actual IBus
lookup-table suggestion UI -- the part that genuinely needs real Kate
testing, built last once the backend pieces are solid.**

---

## Entry 17 -- Build steps 1 and 2 of 3 done: document scanning + ignore list

- Built the whole-document scanning capability: given a full document's
  text, it finds every spelling and grammar mistake in it, in both
  languages, reusing all the same checking logic already built and
  proven for live typing -- no new checking logic needed, just a new
  way to feed it text (a whole document at once, instead of one word
  as it's typed).
- Built the personal ignore list: a simple, toggleable list of specific
  words the user has said to stop flagging. Confirmed working exactly
  as designed: turning the feature off hides the list without deleting
  it, and turning it back on restores it exactly as it was. Saved as a
  plain, human-readable text file, one word per line.
- Verified the two pieces work correctly together: scanning a real
  document with a real ignore list in place correctly skips the
  ignored word while still catching everything else wrong with the
  document.
- Per the user's explicit decision, no persistent memory of exactly
  WHERE in a document an error was found is being built right now --
  that's deliberately being left for later, only if and when an actual
  concrete need for it shows up.

**Conclusion: both backend pieces of the three-part plan from Entry 16
are done and fully verified, all without needing the real machine,
since both are pure logic and simple file storage. The remaining piece
-- the actual Android-bubble-style suggestion popup using IBus's
existing lookup-table feature -- is the one that genuinely needs real
testing in Kate, and is next.**

---

## Entry 18 -- Visual style decision: native IBus popup now, custom bubble UI later

- Discussed the look of the suggestion popup. The user's real
  preference is an Android-style floating bubble, but also likes
  KDE's native look and macOS's frosted-glass style, and wasn't fully
  decided between them.
- Important technical limit to flag honestly: IBus's built-in
  suggestion popup is rendered by IBus/Plasma itself, using whatever
  theme is active on the system. This project can control which COLORS
  are used (e.g. matching the user's current Plasma accent color, the
  original plan from the very start of this project) and what text/
  options appear in it, but cannot reshape the popup itself into an
  Android-style floating bubble or add visual effects like frosted
  glass -- that would require building an entirely separate, custom
  overlay window instead of using IBus's native popup mechanism.
- Decision: build the functional version using IBus's native popup
  now, themed to match the system's colors. The fully custom Android-
  bubble-style visual redesign is acknowledged as a real, desired,
  separate future phase, not abandoned -- just appropriately sequenced
  after the working, native-styled version.

**Conclusion: proceeding with IBus's native lookup-table/popup
mechanism for the suggestion UI, color-themed to the system, as the
practical next build target. The custom bubble UI is documented here
as an explicit future phase to return to.**

---

## Entry 19 -- Researching IBus's built-in suggestion popup mechanism

- Started looking into the real, built-in IBus feature that's the
  closest match to the desired "show 2-3 suggestions, pick one or
  dismiss" experience -- it's called a "lookup table" in IBus's own
  terminology (same underlying mechanism behind things like Chinese/
  Japanese character selection popups, and reused by mature engines
  like Typing Booster for their word-completion suggestions).
- Confirmed it directly supports the things needed: a way to add
  candidate suggestions, set how many show at once, track which one is
  currently selected/highlighted, and show or hide the cursor
  highlighting a particular option.
- This is genuinely the right native building block for the feature --
  next step is working out exactly how to wire it up: triggering it
  when a flagged word is nearby, populating it with the real
  suggestions our existing checkers already produce, and handling
  what happens when the user picks one (or dismisses it).

---

## Entry 20 -- Built the missing piece: fetching real suggested corrections

- The suggestion-popup feature needs actual suggested replacement
  words to show (e.g. "world", "wild", "weld" for a misspelled "wrld")
  -- but the spelling-checking piece built earlier in this project only
  ever answered yes/no ("is this word spelled correctly"), never
  "what should it have been". Built a new, separate piece specifically
  to fetch those real suggestions, for both English and Hungarian.
- Kept this as its own separate, focused piece rather than bolting it
  onto the existing spelling-checking code, since they use genuinely
  different modes of the underlying spelling tool and mixing them risked
  introducing confusion for no real benefit.
- Found and handled one new, real quirk specific to this mode: it prints
  an introductory banner line the moment it starts up, before being
  asked anything -- if not properly accounted for, this would have
  thrown off every single suggestion request that followed it,
  silently misreading answers.
- Verified directly with real misspelled and correctly-spelled words in
  both languages, plus a stress test of many repeated alternating
  requests in a row to specifically check for the kind of silent mix-up
  bug that caused real problems earlier in this project.

**Conclusion: the last missing backend piece needed for the suggestion
popup is now built and fully verified. Next: actually wire up the
real, native suggestion popup itself inside the engine -- the part that
genuinely needs testing in Kate on the real machine, since it's new,
real-world UI behavior that can't be fully predicted from documentation
alone.**

---

## Entry 22 -- Found and fixed a real, serious bug from the first popup test

- The very first real test of the suggestion popup revealed a serious
  problem: every single time a suggestion was clicked, the replacement
  landed in the wrong place in the document -- sometimes leaving
  behind extra blank spaces, sometimes putting the replacement word at
  the very beginning of the entire text instead of where the mistake
  actually was.
- Root cause: the position used to figure out "where exactly should
  this go" was calculated back when the popup first appeared, but a
  real click happens several seconds later, during which more typing
  naturally continues -- so by the time the click actually registered,
  that old saved position no longer matched where things actually were
  anymore.
- A first attempted fix (just remembering the cursor's position more
  carefully at the moment the popup appears) was considered, but
  reasoning it through showed it wouldn't actually be enough either,
  for the same underlying reason -- so that approach was deliberately
  not shipped.
- The real fix: instead of trusting any previously saved position at
  all, the system now looks for the actual word, fresh, right at the
  moment of the click, in whatever the document currently looks like at
  that exact moment. If it can't find the word anymore for some reason
  (for instance, if it was already changed by hand before the click),
  it now safely does nothing instead of guessing and risking damage to
  the wrong part of the document.
- Verified directly against the exact situation that caused the
  original problem, and also verified that the new "give up safely"
  behavior works correctly when the word genuinely isn't there anymore.

**Conclusion: a real, serious bug, caught immediately by testing on
the real machine, the way it's supposed to work. This needs to be
re-verified for real before anything resembling "this part is ready"
can be said. Once confirmed, this is the fix that would actually make
the interactive suggestion experience trustworthy.**

---

## Entry 23 -- Critical position fix confirmed working; found a smaller, cosmetic follow-up issue

- Retested the click-to-replace fix on the real machine, deliberately
  typing more text before clicking each time (the exact condition that
  broke things before). Every single replacement this time correctly
  found and replaced the right word -- no more text landing in the
  wrong place, no more replacements appearing at the start of the
  document. The serious bug from before is genuinely fixed.
- Found a smaller, separate, purely cosmetic issue: every replacement
  leaves an extra space behind where the old word used to be. Traced
  this down precisely -- it's not actually a bug in the replacement
  logic. A misspelled word sitting between two spaces will, by simple
  arithmetic, always leave two adjacent spaces behind once it's
  removed, the same way manually deleting a word in any text editor
  would. The replacement mechanism is doing exactly what it's supposed
  to; this is just an additional, deliberate UX polish step that
  hasn't been added yet (consuming one of the two adjacent spaces when
  replacing a word, the way real autocorrect systems do).

**Conclusion: the serious, document-corrupting bug from the previous
test is confirmed fixed on the real machine. The double-space issue is
real but minor and purely cosmetic, not a safety concern -- a
reasonable next small polish item, not an urgent fix.**

---

## Entry 24 -- Removed the old, retired cursor-tracking code entirely

- The earlier cursor-tracking mechanism (deciding back in Entry 16 not
  to pursue it further) had been left sitting dormant rather than
  removed -- it could never actually touch the document, but it was
  still quietly watching cursor movement and logging about it.
- The user noticed and rightly flagged this as confusing -- it looked
  like something was reacting to cursor movement even though nothing
  actually was.
- Removed it completely rather than just leaving it switched off.
  Confirmed nothing else in the project depended on it, removed the
  now-irrelevant tests along with it, and confirmed everything else
  still works correctly afterward.

**Conclusion: the project is now simpler and its logs more honest --
nothing remaining in the code does anything it doesn't say it's doing.
All the real lessons learned while building and testing that earlier
approach remain recorded in this log and in the project's history, in
case they're ever useful again later.**

---

## Entry 25 -- Starting the custom underline overlay: a genuinely new piece of architecture

- The user explicitly wants a real, persistent visual underline, not
  just the suggestion popup -- and is willing to take on a bigger,
  separate piece of software to get it, rather than settle.
- Confirmed the real building blocks needed exist: IBus actually does
  tell us the on-screen pixel location of the text cursor (not just
  abstract character positions) -- this is the missing piece that
  makes a real, custom-drawn underline at least possible to attempt.
- Confirmed the desktop session is running on the older, more
  permissive X11 display system rather than the newer Wayland one --
  this matters because X11 has long-standing, well-supported ways for
  a separate small program to draw a borderless, see-through,
  always-on-top window at an exact screen location, which is exactly
  what's needed here. Wayland deliberately restricts this kind of
  thing for security reasons, so that would likely need a different
  approach later -- explicitly set aside as a separate, future
  question, not bundled into this work.
- Confirmed the specific toolkit features needed for this kind of
  window all exist and are the right tool for the job.
- Could not fully test actually opening and positioning such a window
  from the building environment -- it doesn't have a real graphical
  display to draw on, the same kind of limitation that affected
  testing the IBus engine itself early in this project. This part
  will need real verification on the actual machine, same as before.

**Conclusion: this is confirmed to be genuinely possible to attempt,
not a dead end, with the real missing piece (on-screen pixel location)
confirmed available. This is a real, separate piece of new software (a
small, standalone overlay helper, distinct from the main engine) and
will be built and explained step by step, with real testing on the
actual machine once there's something concrete to look at.**

---

## Entry 26 -- Real-machine test of the custom underline: two real problems found

- The underline did appear on screen, confirming the basic mechanism
  (a separate small program drawing on top of other windows) works at
  all -- a genuine, meaningful milestone.
- However, two real problems showed up:
  1. The underline's size and position were both unreliable -- at
     times far too small (roughly a tenth of the real word's width),
     and its horizontal position drifted inconsistently (sometimes
     under the start of the word, sometimes the middle, sometimes the
     end) rather than consistently lining up.
  2. More seriously: at one point the small underline mark got stuck
     on screen and would not go away -- it remained visible even after
     leaving the text editor, closing the document entirely, and
     switching the typing system to a different language. It had to be
     manually force-stopped.
- The double-space problem from earlier remains fixed and held up even
  under this heavier round of testing.
- The word-suggestion quality issue (seeing options like "beret" or
  "beer" instead of the obviously intended "better") was also raised
  again. Looked into this separately: this turns out to be a real,
  structural limitation of the underlying spelling-suggestion tool
  itself, not something wrong with how we're calling it -- its own
  maintainers describe its suggestion ordering as fixed by internal
  design rather than ranked by closeness to the original word. There
  is a real, recognized way to teach it specific common misspellings
  directly (so "beter" could be explicitly taught to suggest "better"
  first), though building out a comprehensive list this way could
  become large over time, a concern the user raised directly.

**Conclusion: the underline mechanism is proven to work in principle,
but its current positioning approach is not reliable enough to use as-
is, and -- more importantly -- has a real bug where it can get stuck
visibly on screen well beyond where or when it should ever appear.
That stuck-overlay bug needs to be understood and fixed before any
further work on making the positioning more accurate, since a visual
bug that persists incorrectly is a worse experience than one that's
just imprecisely placed.**

---

## Entry 27 -- Stuck-overlay bug fixed; sizing mystery narrowed but not solved

- Fixed the stuck-overlay bug from Entry 26: traced it to a simple but
  real oversight -- the part of the code that tells the underline to
  appear was never paired with anything telling it to disappear,
  anywhere, under any circumstance. Added the missing "make it go away"
  calls at every point where that should happen (switching apps,
  leaving the text field, clicking a suggestion, the system resetting),
  plus a backup safety timer directly in the underline program itself
  that will always hide it automatically after a few seconds no matter
  what, so this specific kind of bug can never fully recur even if a
  future change misses one of those spots.
- Investigated the sizing issue further. Confirmed the user's screen
  is at standard 100% scaling, which rules out the most likely simple
  explanation. The numbers don't add up in a way that points to a
  single obvious fix: a width that was supposed to span an entire
  4-letter word visually only covered about one letter's worth of
  space, suggesting some kind of mismatch between the coordinate
  system this project assumes and the one actually being used on
  screen, rather than just a wrong guess at letter width. This needs
  real, hands-on measurement on the actual machine to resolve properly
  rather than further guessing.

**Conclusion: the more serious of the two bugs (the stuck overlay) is
fixed and should be retested. The sizing issue remains open and is
the next concrete thing to investigate, ideally with a simple, direct
measurement on the real machine rather than more guessing.**
