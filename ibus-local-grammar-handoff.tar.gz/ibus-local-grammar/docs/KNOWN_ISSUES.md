# Known Issues / Honest Limitations

This file exists so nobody -- including future us -- oversells what this does.

## Browser/app coverage (untested claims are marked as such)

| App | Status | Notes |
|---|---|---|
| Kate / GTK text editors | Expected to work well | IBus pre-edit attributes are native here. Not yet verified on this build. |
| LibreOffice Writer | Expected to work | LO has solid historical IBus support. Not yet verified. |
| Firefox | Expected to work, untested | Not the user's primary browser, lower priority to verify. |
| Brave (.deb) | **UNKNOWN -- this is the single biggest open risk in this project** | Chromium-based. Chromium's IBus pre-edit underline rendering has been inconsistent across versions historically. Must be tested directly on the target machine. If it fails, fallback plan is a browser extension front-end talking to the same local daemon backend. |
| Terminal apps | Out of scope | Not a target use case for this project. |

## Plasma 6 portability

Not yet attempted. Plasma 6 moved to Qt6/KF6 and some config file locations
and D-Bus interfaces may differ from Plasma 5's `kdeglobals`-based approach
used here. The accent-color-reading code is structured as an isolated
function specifically so this can be patched without touching the rest of
the engine, but it has not been tested on a real Plasma 6 system.

## Grammar quality vs. Grammarly

LanguageTool is rule-based with some statistical components. It is good at
mechanical grammar and spelling. It is NOT going to match Grammarly's
proprietary ML-based style/clarity/tone suggestions. Don't expect parity --
expect "solid grammar checking," not "AI writing coach."

## Resource usage (estimates, not yet measured on real hardware)

- LanguageTool JVM process: estimated 400MB-1GB RAM resident, brief CPU
  spike per check (debounced, not per-keystroke). Not yet measured on the
  actual target machine (Dell Latitude, i5-10th-gen, 16GB RAM).
- Low-power mode: LanguageTool process not running, Hunspell-only checking,
  expected to be near-zero overhead. Not yet measured.

## What's definitely NOT built yet (as of this file's creation)

Everything except a setup/test script for LanguageTool. There is no IBus
engine code yet. Do not assume any underlining, theming, or dictionary
features work -- they don't exist yet.
