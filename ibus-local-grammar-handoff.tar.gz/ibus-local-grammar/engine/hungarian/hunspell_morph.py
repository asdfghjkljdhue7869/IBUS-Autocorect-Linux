# -*- encoding: UTF-8 -*-
"""
hunspell_morph.py

A long-running Hunspell subprocess wrapper that provides the morphological
analysis primitives the Lightproof Hungarian rules need: morph(), stem(),
and spell(). This replaces LibreOffice's internal UNO-based spellchecker
service (the original lightproof_impl used calls like
spellchecker.spell(query_xml, locale, ())) with plain Hunspell calls.

Why a long-running subprocess instead of one-shot calls:
  Spawning a new `hunspell` process per word would work but is slow --
  each spawn costs real time (process startup, dictionary loading).
  Hunspell supports a pipe mode: feed it words on stdin, one per line,
  get analysis back on stdout, one block per word, separated by a blank
  line. We keep ONE Hunspell process alive for the life of the engine
  and write/read to it repeatedly. This is much faster for live-typing
  use, where we'll be analyzing words constantly.

Hunspell morphological analysis format (the -m flag, NOT -a):
  Input:  "ház"
  Output: "ház  st:ház po:noun ts:NOM al:házak"
          ""   (blank line = end of this word's analyses)

  A word can have multiple analyses (ambiguous words), each on its own
  line, still followed by exactly one blank line at the end.

  A word with NO valid analysis just echoes back alone with no tags,
  e.g. for "xqzwj":  "xqzwj"
                      ""

Tag meanings (the ones the Hungarian rules actually use):
  st: stem (base form) of the word
  po: part of speech (noun, vrb, adj, adv, etc.)
  ts: morphological suffix tag (NOM=nominative, PLUR=plural, etc.)
  is: inflectional suffix tag (INSTR=instrumental, PAST_INDIC..., etc.)
  ip: prefix tag (PREF = has a verb prefix)
  sp: the prefix string itself
  al: alternative/related word form
"""

import subprocess
import threading


class HunspellMorphAnalyzer:
    """
    Wraps a long-running `hunspell -d <dict> -m` process.

    Thread-safety note: Hunspell's pipe protocol is strictly
    request-then-response, one word at a time. We use a lock so this
    class is safe to call from multiple threads, but it does NOT pipeline
    requests -- each call blocks until its own answer comes back.
    """

    def __init__(self, dictionary="hu_HU", hunspell_path="hunspell"):
        self.dictionary = dictionary
        self._lock = threading.Lock()
        self._proc = None
        self._start_process(hunspell_path)

    def _start_process(self, hunspell_path):
        # IMPORTANT: Hunspell buffers its stdout fully (not line-by-line)
        # when its output is a pipe rather than a terminal. Without
        # `stdbuf -oL`, our readline() calls will hang waiting for data
        # that's sitting in Hunspell's internal buffer. `stdbuf -oL`
        # forces line-buffered output regardless of where stdout goes.
        # This was confirmed necessary by testing directly -- without it,
        # the wrapper hangs indefinitely on the very first query.
        self._proc = subprocess.Popen(
            ["stdbuf", "-oL", hunspell_path, "-d", self.dictionary, "-m"],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            text=True,
            encoding="utf-8",
            bufsize=1,  # line-buffered on the Python side too
        )

    def _restart_if_dead(self):
        if self._proc.poll() is not None:
            self._start_process("hunspell")

    def _query_raw(self, word):
        """
        Send one word to Hunspell, read back its analysis block.
        Returns a list of raw analysis-line strings (without the word
        prefix), or an empty list if the word has no valid analysis.
        """
        if not word:
            return []

        with self._lock:
            self._restart_if_dead()
            self._proc.stdin.write(word + "\n")
            self._proc.stdin.flush()

            lines = []
            while True:
                line = self._proc.stdout.readline()
                if line == "":
                    # Process died mid-read; bail out cleanly.
                    break
                line = line.rstrip("\n")
                if line == "":
                    # blank line = end of this word's analysis block
                    break
                lines.append(line)
            return lines

    def analyze(self, word):
        """
        Return a list of tag-strings for each analysis of `word`.
        Each entry looks like: "st:ház po:noun ts:NOM al:házak"
        (the word itself, the leading whitespace, is stripped off).
        Returns [] if the word has no valid analysis (likely misspelled
        or genuinely not in the dictionary).
        """
        raw_lines = self._query_raw(word)
        results = []
        for line in raw_lines:
            # Each line looks like: "<word>  st:... po:... ts:..."
            # (word repeated, then two spaces, then the tag string)
            # If there are no tags at all, this is a bare echo -> skip it.
            parts = line.split(None, 1)
            if len(parts) < 2:
                continue
            tag_string = parts[1]
            results.append(tag_string)
        return results

    def is_valid(self, word):
        """
        True if Hunspell recognizes this word (has at least one
        analysis), False otherwise. Equivalent to the original
        spell()/isValid() call.
        """
        return len(self.analyze(word)) > 0

    def stem(self, word):
        """
        Return a list of distinct stems (base forms) found across all
        analyses of `word`. Equivalent to the original stem() call.
        """
        stems = []
        for tag_string in self.analyze(word):
            for tag in tag_string.split():
                if tag.startswith("st:"):
                    s = tag[3:]
                    if s not in stems:
                        stems.append(s)
        return stems

    def close(self):
        if self._proc and self._proc.poll() is None:
            try:
                self._proc.stdin.close()
            except Exception:
                pass
            self._proc.terminate()
            try:
                self._proc.wait(timeout=2)
            except Exception:
                self._proc.kill()

    def __del__(self):
        self.close()
