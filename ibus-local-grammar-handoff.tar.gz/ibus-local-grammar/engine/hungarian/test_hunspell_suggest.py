# -*- encoding: UTF-8 -*-
"""
test_hunspell_suggest.py

Automated tests for hunspell_suggest.py, using REAL Hunspell processes
for both English and Hungarian (same pattern as test_hunspell_morph
testing elsewhere in this project -- real dictionaries, not mocks,
since correctness of actual suggestions is the entire point).

Run directly: python3 test_hunspell_suggest.py
"""

import sys
import os
import importlib.util

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
spec = importlib.util.spec_from_file_location(
    "hunspell_suggest", os.path.join(SCRIPT_DIR, "hunspell_suggest.py")
)
hunspell_suggest = importlib.util.module_from_spec(spec)
spec.loader.exec_module(hunspell_suggest)


def test_misspelled_english_word_gets_suggestions():
    s = hunspell_suggest.HunspellSuggester(dictionary="en_GB")
    suggestions = s.suggest("wrld")
    ok = "world" in suggestions and len(suggestions) > 0
    print(f"[{'PASS' if ok else 'FAIL'}] misspelled English word 'wrld' "
          f"gets real suggestions including 'world'")
    if not ok:
        print(f"       got: {suggestions}")
    s.close()
    return ok


def test_correctly_spelled_english_word_gets_no_suggestions():
    s = hunspell_suggest.HunspellSuggester(dictionary="en_GB")
    suggestions = s.suggest("world")
    ok = suggestions == []
    print(f"[{'PASS' if ok else 'FAIL'}] correctly spelled word 'world' "
          f"gets no suggestions (it's already correct)")
    if not ok:
        print(f"       got: {suggestions}")
    s.close()
    return ok


def test_misspelled_hungarian_word_gets_suggestions():
    s = hunspell_suggest.HunspellSuggester(dictionary="hu_HU")
    suggestions = s.suggest("kutyaa")
    ok = "kutya" in suggestions
    print(f"[{'PASS' if ok else 'FAIL'}] misspelled Hungarian word "
          f"'kutyaa' gets real suggestions including 'kutya'")
    if not ok:
        print(f"       got: {suggestions}")
    s.close()
    return ok


def test_many_repeated_queries_dont_desync():
    """
    Regression-style test against the exact class of bug that bit the
    morphological analyzer earlier in this project (buffering causing
    hangs, or the protocol getting out of sync after many calls).
    """
    s = hunspell_suggest.HunspellSuggester(dictionary="en_GB")
    words = ["wrld", "world", "teh", "the", "haet", "heat"] * 10
    results = [s.suggest(w) for w in words]
    # Spot check a few -- if desync had occurred, results would be
    # misaligned (e.g. "world"'s result showing "wrld"'s suggestions).
    ok = (
        len(results) == len(words)
        and results[1] == []  # "world", correct, no suggestions
        and "world" in results[0]  # "wrld" -> includes "world"
    )
    print(f"[{'PASS' if ok else 'FAIL'}] 60 repeated alternating queries "
          f"complete without hanging or desyncing")
    if not ok:
        print(f"       results[0]={results[0]} results[1]={results[1]}")
    s.close()
    return ok


def test_empty_word_returns_empty_list_safely():
    s = hunspell_suggest.HunspellSuggester(dictionary="en_GB")
    suggestions = s.suggest("")
    ok = suggestions == []
    print(f"[{'PASS' if ok else 'FAIL'}] empty string input handled "
          f"safely (no crash, no hang)")
    s.close()
    return ok


def main():
    results = [
        test_misspelled_english_word_gets_suggestions(),
        test_correctly_spelled_english_word_gets_no_suggestions(),
        test_misspelled_hungarian_word_gets_suggestions(),
        test_many_repeated_queries_dont_desync(),
        test_empty_word_returns_empty_list_safely(),
    ]
    passed = sum(results)
    failed = len(results) - passed
    print(f"\n== Summary: {passed} passed, {failed} failed out of {len(results)} ==")
    if failed > 0:
        sys.exit(1)


if __name__ == "__main__":
    main()
