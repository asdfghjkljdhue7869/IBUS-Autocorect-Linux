# -*- encoding: UTF-8 -*-
"""
test_hungarian_engine.py

Runs the standalone Hungarian grammar engine against a set of sentences
with deliberate, known errors, and a couple of clean control sentences
that should produce NO errors. Prints clear pass/fail per case.

This is meant to be run directly (not via pytest or similar) so the
output is easy to read and paste back for debugging if something looks
wrong on a different machine than the one this was built on.
"""

import sys
import time
from lightproof_engine import HungarianGrammarChecker


# Each test case: (sentence, should_find_error, short description)
# "should_find_error" of True just means "at least one error expected" --
# we're not pinning down the exact message, since rule wording can be
# legitimately reworded upstream over time.
TEST_CASES = [
    ("Szeretem a a kávét.", True, "doubled word 'a a'"),
    ("Tudtam hogy ez fog történni.", True, "missing comma before 'hogy'"),
    ("Azt mondta hogy nem ér rá.", True, "missing comma before 'hogy'"),
    ("1996 január 5-én volt az esküvő.", True, "missing period after year in date"),
    ("Ez egy alma alma.", True, "doubled word 'alma alma'"),
    ("Megint elkezdtem írni.", False, "clean sentence, should have NO errors"),
    ("A kutya a kertben szaladgál.", False, "clean sentence, should have NO errors"),
]


def main():
    print("Loading Hungarian grammar engine...")
    start = time.time()
    checker = HungarianGrammarChecker()
    load_time = time.time() - start
    print(f"Loaded {len(checker.compiled_rules)} rules in {load_time:.2f}s.\n")

    passed = 0
    failed = 0

    for sentence, should_find_error, description in TEST_CASES:
        errors = checker.check(sentence)
        found_error = len(errors) > 0

        ok = (found_error == should_find_error)
        status = "PASS" if ok else "FAIL"
        if ok:
            passed += 1
        else:
            failed += 1

        print(f"[{status}] {description}")
        print(f"       sentence: {sentence}")
        if errors:
            for e in errors:
                print(f"       -> \"{e['matched_text']}\" => {e['suggestions']} ({e['message']})")
        else:
            print("       -> no errors found")
        print()

    print("== Performance check ==")
    # warm up first (first call after load can be slightly slower)
    checker.check("Ez egy teszt mondat.")
    bench_sentence = "Tudtam hogy ez fog történni, és nem mondta hogy mikor jön vissza."
    n = 20
    start = time.time()
    for _ in range(n):
        checker.check(bench_sentence)
    elapsed = time.time() - start
    print(f"{n} checks took {elapsed:.3f}s total, average {elapsed/n*1000:.1f}ms per check.")
    print("(For reference: this was ~1.4ms per check on the original build machine.")
    print(" Anything under ~20ms is plenty fast for live-typing use.)")

    checker.close()

    print()
    print(f"== Summary: {passed} passed, {failed} failed out of {len(TEST_CASES)} ==")
    if failed > 0:
        print("Something behaves differently on this machine than expected.")
        print("Paste this full output back for debugging.")
        sys.exit(1)
    else:
        print("All tests passed. The Hungarian grammar engine works correctly")
        print("on this machine.")


if __name__ == "__main__":
    main()
