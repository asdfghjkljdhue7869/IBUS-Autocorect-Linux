# -*- encoding: UTF-8 -*-
"""
lightproof_engine.py

A standalone reimplementation of the Lightproof rule-execution engine,
originally built for LibreOffice (see lightproof_impl_hu_HU.py upstream).

This file does NOT reuse the original engine's code. It re-derives the
same behavior using Hunspell's command-line morphological analysis
(via hunspell_morph.py) instead of LibreOffice's internal UNO API. The
only thing reused verbatim from upstream is the RULE DATA in
rules_hu_raw.py (see that file's header for full attribution).

What this engine does, in plain terms:
  1. Take a sentence of text.
  2. For each rule in the rule list, check if its regex matches anywhere
     in the sentence.
  3. If it matches AND the rule's optional condition (if any) evaluates
     to True, record it as an error with a suggestion and message.
  4. Return all matches found.

The condition strings in the rule data are literal Python expressions,
written assuming a few specific helper names exist in scope: morph(),
stem(), spell(), affix(), option(), word(), wordmin(), calc(), plus the
match object `m`, the sentence string `s`, and a `LOCALE` placeholder.
We provide all of these (except calc(), which is for spreadsheet-style
unit conversion rules and is treated as a no-op -- see NOTES below).
"""

import re
import importlib.util
import os

from hunspell_morph import HunspellMorphAnalyzer


def _load_rules(path):
    spec = importlib.util.spec_from_file_location("rules_hu_raw", path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod.dic


class HungarianGrammarChecker:
    """
    Loads the Hungarian Lightproof rule set and checks text against it.
    """

    # Default option values. The original LibreOffice extension exposes
    # these as user-configurable checkboxes (comma usage, capitalization,
    # spacing rules, etc.) defaulting mostly to "on" for the core ones.
    # We default everything relevant to True/1 since we don't (yet) have
    # a settings UI -- see docs/DEVELOPMENT_LOG.md for the plan to expose
    # these properly later if wanted.
    DEFAULT_OPTIONS = {
        "comma": 1,
        "cap": 1,
        "dash": 1,
        "elli": 1,
        "spaces": 1,
        "spaces2": 0,
        "apost": 1,
        "quot": 1,
        "money": 1,
        "thin": 0,
        "numpart": 1,
        "minus": 1,
        "compound": 0,      # "is this a valid compound word?" -- noisy, off by default
        "allcompound": 0,
        "style": 0,         # disputed-style-word warnings -- off by default
        "wordpart": 1,
        "dup0": 1,
        "dup": 0,           # repeated-word-at-a-distance -- can be noisy, off by default
        "dup2": 0,
        "dup3": 0,
        "ligature": 0,
        "noligature": 0,
        "frac": 0,
        "idx": 0,
        "SI": 0,
        "hyphen": 0,
        "grammar": 1,
    }

    def __init__(self, rules_path=None, hunspell_dict="hu_HU"):
        if rules_path is None:
            rules_path = os.path.join(os.path.dirname(__file__), "rules_hu_raw.py")
        raw_rules = _load_rules(rules_path)
        self._analyzer = HunspellMorphAnalyzer(dictionary=hunspell_dict)
        self.options = dict(self.DEFAULT_OPTIONS)
        self.compiled_rules = self._compile_rules(raw_rules)

    # ------------------------------------------------------------------
    # Helper functions available to rule condition strings (via eval()).
    # These mirror the names/signatures used in the original rule data
    # so the condition strings can run completely unmodified.
    # ------------------------------------------------------------------

    def morph(self, _locale_unused, word, pattern, all=True):
        """Check the word's morphological tags against `pattern`."""
        if not word:
            return None
        analyses = self._analyzer.analyze(word)
        if not analyses:
            return None
        p = re.compile(pattern)
        result = None
        for tag_string in analyses:
            result = p.search(tag_string)
            if result:
                result = result.group(0)
                if not all:
                    return result
            elif all:
                return None
        return result

    def affix(self, _locale_unused, word, pattern, all=True):
        """Like morph(), but only checks the affix portion of the tags."""
        if not word:
            return None
        analyses = self._analyzer.analyze(word)
        if not analyses:
            return None
        p = re.compile(pattern)
        result = None
        for tag_string in analyses:
            filtered = self._onlymorph(tag_string)
            result = p.search(filtered)
            if result:
                result = result.group(0)
                if not all:
                    return result
            elif all:
                return None
        return result

    @staticmethod
    def _onlymorph(tag_string):
        """
        Port of the original onlymorph(): strip everything except the
        last stem/part-of-speech field and its directly attached affix
        tags. This is used by affix() to check ONLY suffix/prefix
        behavior, ignoring which specific word/stem it is.
        """
        st = tag_string
        st = re.sub(r"^.*(st:|po:)", r"\1", st)
        st = re.sub(r"\b(?=[dit][sp]:)", "@", st)
        st = re.sub(r"(?<!@)\b\w\w:\w+", "", st).replace("@", "").strip()
        return st

    def spell(self, _locale_unused, word):
        if not word:
            return None
        return self._analyzer.is_valid(word)

    def stem(self, _locale_unused, word):
        if not word:
            return []
        return self._analyzer.stem(word)

    def option(self, _locale_unused, opt):
        return self.options.get(opt, 0)

    @staticmethod
    def word(s, n):
        """Get the nth word from the start of string s, or '' if absent."""
        m = re.match(r"(?u)( [-.\w%]+){" + str(n - 1) + r"}( [-.\w%]+)", s)
        if not m:
            return ""
        return m.group(2)[1:]

    @staticmethod
    def wordmin(s, n):
        """Get the nth-from-the-end word in string s, or '' if absent."""
        m = re.search(r"(?u)([-.\w%]+ )([-.\w%]+ ){" + str(n - 1) + r"}$", s)
        if not m:
            return ""
        return m.group(1)[:-1]

    @staticmethod
    def calc(funcname, par):
        """
        NOT IMPLEMENTED. The original calc() calls LibreOffice Calc's
        spreadsheet function engine (e.g. for NUMBERTEXT number-to-words
        conversion, used by a couple of money-amount-checking rules).
        We don't have a spreadsheet engine standalone, so this returns
        None, which means any rule condition using calc() will safely
        evaluate to a falsy result and that specific rule will never
        fire. This affects a small number of rules (the "money amount
        spelled out in words doesn't match" checks). Documented here
        and in docs/DEVELOPMENT_LOG.md rather than silently ignored.
        """
        return None

    @staticmethod
    def cap(suggestions, iscap):
        """Capitalize suggestions if the matched text was capitalized."""
        if not iscap:
            return suggestions
        result = []
        for s in suggestions:
            if s[:1] == "i":
                result.append("I" + s[1:])
            else:
                result.append(s.capitalize())
        return result

    # ------------------------------------------------------------------
    # Rule compilation and execution
    # ------------------------------------------------------------------

    def _compile_rules(self, raw_rules):
        compiled = []
        for rule in raw_rules:
            pattern_str, replacement, message, condition, _priority = rule
            try:
                # The original engine special-cases "(?iu)" patterns for
                # its own casing-related reasons; for us, plain re.compile
                # with the flags already embedded in the string is fine
                # since Python's re module supports (?iu) as written here
                # (these source strings already have correct flag-prefix
                # placement, unlike the raw .dat DSL source we found
                # incompatible with Python 3.12 -- see DEVELOPMENT_LOG.md).
                compiled_pattern = re.compile(pattern_str)
            except re.error as e:
                # Skip any rule that fails to compile, but don't crash
                # the whole engine over one bad rule.
                print(f"WARNING: skipping rule with bad regex: {e}\n  pattern: {pattern_str}")
                continue
            compiled.append({
                "pattern": compiled_pattern,
                "replacement": replacement,
                "message": message,
                "condition": condition,
            })
        return compiled

    def check(self, sentence):
        """
        Run all rules against `sentence`. Returns a list of dicts:
          {
            "start": int,           # character offset where the error starts
            "end": int,             # character offset where it ends
            "matched_text": str,    # the actual text that was flagged
            "suggestions": [str],   # suggested replacement(s)
            "message": str,         # human-readable explanation
          }
        """
        errors = []
        s = sentence
        LOCALE = None  # unused placeholder, kept for condition-string compatibility

        for rule in self.compiled_rules:
            pattern = rule["pattern"]
            for m in pattern.finditer(s):
                if rule["condition"]:
                    try:
                        # The condition string is a literal Python boolean
                        # expression from the original rule data. It
                        # references morph, stem, spell, affix, option,
                        # word, wordmin, calc, m, s, LOCALE -- all of
                        # which are in scope here via locals()/self.
                        condition_result = eval(
                            rule["condition"],
                            {
                                "morph": self.morph,
                                "stem": self.stem,
                                "spell": self.spell,
                                "affix": self.affix,
                                "option": self.option,
                                "word": self.word,
                                "wordmin": self.wordmin,
                                "calc": self.calc,
                                "re": re,
                            },
                            {"m": m, "s": s, "LOCALE": LOCALE},
                        )
                    except Exception as e:
                        # A rule whose condition throws (e.g. due to our
                        # calc() stub, or an edge case in morph()) is
                        # skipped for this match rather than crashing
                        # the whole check. Comment so this is visible
                        # rather than silently swallowed during testing.
                        # print(f"DEBUG: condition error in rule, skipping: {e}")
                        continue
                    if not condition_result:
                        continue

                replacement = rule["replacement"]
                iscap = m.group(0)[0:1].isupper()

                if replacement[0:1] == "=":
                    try:
                        suggestion_text = eval(
                            replacement[1:],
                            {"re": re, "m": m, "s": s},
                            {"m": m, "s": s},
                        )
                    except Exception:
                        suggestion_text = ""
                    suggestions = suggestion_text.replace("|", "\n").split("\n")
                elif replacement == "_":
                    suggestions = []
                else:
                    # Replacement can contain multiple pipe-separated
                    # alternatives, e.g. "fix1|fix2". Expand each
                    # alternative independently so that a broken group
                    # reference in ONE alternative (this happens in a
                    # couple of upstream rules -- see DEVELOPMENT_LOG.md,
                    # e.g. a rule referencing \g<aword_2> when only
                    # \g<aword_1> is actually captured) doesn't discard
                    # the other, valid alternative(s).
                    suggestions = []
                    for alt in replacement.split("|"):
                        try:
                            suggestions.append(m.expand(alt))
                        except Exception:
                            # This specific alternative has a bad group
                            # reference upstream; skip just this one
                            # rather than losing all suggestions for
                            # the match.
                            continue

                suggestions = self.cap(suggestions, iscap)

                message = rule["message"]
                if message[0:1] == "=":
                    try:
                        message = eval(message[1:], {"re": re, "m": m}, {"m": m})
                    except Exception:
                        message = "(error generating message)"
                else:
                    try:
                        message = m.expand(message)
                    except Exception:
                        pass
                short_message = message.replace("|", "\n").split("\n")[0].strip()

                errors.append({
                    "start": m.start(),
                    "end": m.end(),
                    "matched_text": m.group(0),
                    "suggestions": [s for s in suggestions if s],
                    "message": short_message,
                })

        errors.sort(key=lambda e: e["start"])
        return errors

    def close(self):
        self._analyzer.close()

    def __del__(self):
        try:
            self.close()
        except Exception:
            pass
