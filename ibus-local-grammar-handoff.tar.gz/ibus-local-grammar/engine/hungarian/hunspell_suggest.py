# -*- encoding: UTF-8 -*-
"""
hunspell_suggest.py

A long-running Hunspell subprocess wrapper specifically for fetching
SUGGESTED CORRECTIONS for misspelled words (Hunspell's "-a" / Ispell
pipe interface mode), as opposed to hunspell_morph.py's "-m"
morphological analysis mode.

Kept as a SEPARATE class/file rather than added to HunspellMorphAnalyzer,
deliberately: that class is already proven, working, and used throughout
the Hungarian grammar engine (lightproof_engine.py) via its -m mode.
Adding -a-mode suggestion-fetching to the same class would mean running
TWO different Hunspell subprocess modes through one wrapper, which adds
real risk of confusing the two output formats for no benefit -- a
second, focused class is simpler and safer.

Hunspell -a mode output format:
  Correct word:    "*" (a single asterisk)
  Misspelled, with suggestions: "& word N M: sugg1, sugg2, sugg3"
      N = number of suggestions found, M = offset in line (unused here)
  Misspelled, no suggestions: "# word M" (rare, unused here)

Verified directly: "wrld" against en_GB returns
  "& wrld 4 0: weld, world, wild, wold"
"""

import subprocess
import threading


class HunspellSuggester:
    """
    Wraps a long-running `hunspell -d <dict> -a` process to fetch
    suggested corrections for misspelled words. Same subprocess
    lifecycle pattern as HunspellMorphAnalyzer (long-running pipe,
    stdbuf -oL workaround for buffering, lock for thread safety) since
    those were all hard-won, verified-necessary details the first time
    around -- no reason to relearn them.
    """

    def __init__(self, dictionary="en_GB", hunspell_path="hunspell"):
        self.dictionary = dictionary
        self._lock = threading.Lock()
        self._proc = None
        self._start_process(hunspell_path)

    def _start_process(self, hunspell_path):
        self._proc = subprocess.Popen(
            ["stdbuf", "-oL", hunspell_path, "-d", self.dictionary, "-a"],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            text=True,
            encoding="utf-8",
            bufsize=1,
        )
        # Hunspell's -a mode prints a version banner line on startup,
        # BEFORE any input is even sent. Must consume it here, or the
        # first real query's response would be misread as two lines
        # (banner + actual answer) instead of one.
        self._proc.stdout.readline()

    def _restart_if_dead(self):
        if self._proc.poll() is not None:
            self._start_process("hunspell")

    def suggest(self, word):
        """
        Returns a list of suggested corrections for `word`, or an empty
        list if the word is already correctly spelled (or if Hunspell
        has no suggestions at all for it).
        """
        if not word:
            return []

        with self._lock:
            self._restart_if_dead()
            self._proc.stdin.write(word + "\n")
            self._proc.stdin.flush()

            line = self._proc.stdout.readline()
            # -a mode emits exactly one response line per input word,
            # followed by a blank line.
            blank = self._proc.stdout.readline()  # noqa: F841 -- consumed to keep the stream in sync for the next call

        line = line.rstrip("\n")
        if line.startswith("*") or line.startswith("+"):
            return []  # correctly spelled (or found via affix/compound rule)
        if line.startswith("&"):
            # Format: "& word N offset: sugg1, sugg2, sugg3"
            after_colon = line.split(":", 1)
            if len(after_colon) < 2:
                return []
            suggestions = [s.strip() for s in after_colon[1].split(",")]
            return [s for s in suggestions if s]
        # "#" (no suggestions) or anything unexpected -> no suggestions.
        return []

    def close(self):
        if self._proc and self._proc.poll() is None:
            try:
                self._proc.stdin.close()
            except Exception:
                pass
            self._proc.terminate()
            try:
                self._proc.wait(timeout=2)
            except Exception:
                self._proc.kill()

    def __del__(self):
        self.close()
