#!/usr/bin/env bash
# Phase 1B test: verify the standalone Hungarian grammar engine works
# on YOUR machine, not just in the build sandbox.
#
# Prerequisites this checks/installs:
#   - hunspell + hunspell-hu (the Hungarian dictionary)
#   - the hu_HU.UTF-8 locale (needed for correct accented-character handling)
#
# Run this from the project's engine/hungarian/ directory.

set -euo pipefail

echo "== Checking for hunspell + Hungarian dictionary =="
if ! command -v hunspell &> /dev/null; then
    echo "hunspell not found. Installing hunspell + hunspell-hu..."
    sudo apt-get install -y hunspell hunspell-hu
else
    echo "hunspell found: $(which hunspell)"
    if [ ! -f /usr/share/hunspell/hu_HU.dic ]; then
        echo "Hungarian dictionary not found. Installing hunspell-hu..."
        sudo apt-get install -y hunspell-hu
    else
        echo "Hungarian dictionary found."
    fi
fi

echo ""
echo "== Checking for hu_HU.UTF-8 locale =="
if locale -a 2>/dev/null | grep -qi "hu_HU.utf8"; then
    echo "hu_HU.UTF-8 locale already present."
else
    echo "Generating hu_HU.UTF-8 locale (needs sudo)..."
    sudo sed -i 's/# hu_HU.UTF-8 UTF-8/hu_HU.UTF-8 UTF-8/' /etc/locale.gen
    sudo locale-gen hu_HU.UTF-8
fi

echo ""
echo "== Checking for stdbuf (needed to prevent Hunspell pipe buffering issues) =="
if ! command -v stdbuf &> /dev/null; then
    echo "ERROR: stdbuf not found. This is normally part of coreutils and should"
    echo "already be installed. Something unusual about this system -- stopping."
    exit 1
else
    echo "stdbuf found: $(which stdbuf)"
fi

echo ""
echo "== Running the Hungarian grammar engine test =="
export LANG=hu_HU.utf8
export LC_ALL=hu_HU.utf8

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

python3 test_hungarian_engine.py
