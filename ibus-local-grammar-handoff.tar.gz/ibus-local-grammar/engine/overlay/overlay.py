#!/usr/bin/env python3
# -*- encoding: UTF-8 -*-
"""
overlay.py

A standalone, separate process that draws a small, borderless,
click-through, always-on-top colored underline at an arbitrary screen
position, controlled remotely by the IBus engine over a local Unix
domain socket.

WHY THIS IS A SEPARATE PROCESS, not part of engine.py:
IBus's own rendering primitives (pre-edit text, lookup tables) are
fundamentally tied to the text cursor -- there is no IBus mechanism to
draw a persistent visual marker on already-committed text sitting
elsewhere in a document. This overlay sidesteps that entirely by not
using IBus's rendering at all -- it's a normal GTK window, positioned
at real screen pixel coordinates (which IBus DOES give us, via the
do_set_cursor_location callback), drawn on top of whatever application
is focused. Since it never touches the document's actual text content,
it cannot corrupt anything -- a fundamentally different risk profile
than every previous rendering approach tried in this project (see
docs/DEVELOPMENT_LOG.md Entries 7, 11-15 for the approaches that COULD
corrupt text, and why).

PROTOCOL (newline-delimited JSON over a Unix domain socket):
  Show an underline:
    {"action": "show", "x": 100, "y": 200, "width": 50, "height": 4, "color": "#3daee9"}
  Hide it:
    {"action": "hide"}

The socket path defaults to ~/.local/share/ibus-local-grammar/overlay.sock
(same directory convention as the engine's log file and ignore list).

KNOWN LIMITATION, stated honestly: this is built and confirmed correct
against X11's windowing model (the user's confirmed current session
type). Wayland deliberately restricts this kind of arbitrary-position,
always-on-top overlay for security/sandboxing reasons -- this has NOT
been tested or adapted for Wayland, and may need a fundamentally
different approach there (e.g. a compositor-specific extension) rather
than the same code. Explicitly out of scope for this increment.
"""

import os
import sys
import json
import socket
import threading
import logging

import gi
gi.require_version("Gtk", "3.0")
from gi.repository import Gtk, GLib, Gdk

log = logging.getLogger("ibus-local-grammar-overlay")

DEFAULT_SOCKET_PATH = os.path.expanduser(
    "~/.local/share/ibus-local-grammar/overlay.sock"
)


class UnderlineOverlay:
    """
    Owns the actual GTK popup window used to draw the underline, plus
    the Unix socket server that listens for show/hide commands. All
    GTK calls happen on the GLib main thread (required by GTK); socket
    commands arrive on a background thread and are marshalled onto the
    main thread via GLib.idle_add, since GTK is not thread-safe to call
    into directly from another thread.
    """

    # Safety-net auto-hide delay -- see the comment in show() for why
    # this exists. Generous enough not to interfere with normal use
    # (nobody looks at one underline for 10 seconds while still
    # actively deciding what to do about it), short enough that a
    # forgotten hide() call can never leave a stuck mark for long.
    AUTO_HIDE_MS = 10000

    def __init__(self, socket_path=None):
        self._socket_path = socket_path or DEFAULT_SOCKET_PATH
        self._window = None
        self._drawing_area = None
        self._current_color = (0.0, 0.0, 0.0)  # RGB floats 0-1, set per-show
        self._auto_hide_timer_id = None
        self._build_window()

    def _build_window(self):
        win = Gtk.Window(type=Gtk.WindowType.POPUP)
        win.set_decorated(False)
        win.set_skip_taskbar_hint(True)
        win.set_skip_pager_hint(True)
        win.set_accept_focus(False)  # never steals keyboard focus from the real app
        win.set_keep_above(True)

        screen = win.get_screen()
        visual = screen.get_rgba_visual()
        if visual is not None:
            win.set_visual(visual)

        drawing_area = Gtk.DrawingArea()
        drawing_area.connect("draw", self._on_draw)
        win.add(drawing_area)

        self._window = win
        self._drawing_area = drawing_area

    def _on_draw(self, widget, cr):
        """
        Cairo draw callback -- fills the entire small window with the
        current underline color. The window itself IS the underline;
        we don't draw a line within a larger transparent window,
        because keeping the window exactly underline-sized is simpler
        and avoids needing to manage transparency compositing for any
        area around the line.
        """
        r, g, b = self._current_color
        cr.set_source_rgb(r, g, b)
        cr.paint()
        return False

    def show(self, x, y, width, height, color_hex):
        self._current_color = self._hex_to_rgb(color_hex)
        self._window.move(x, y)
        self._window.resize(max(1, width), max(1, height))
        self._window.show_all()
        self._drawing_area.queue_draw()

        # SAFETY NET (added after real-machine testing found the
        # overlay getting permanently stuck on screen -- see docs/
        # DEVELOPMENT_LOG.md Entry 26 -- because the engine simply never
        # called hide() in several real lifecycle situations, since
        # fixed on the engine side). Defense in depth: even if some
        # future code path on the engine side fails to call hide(),
        # this watchdog guarantees the underline can never persist
        # indefinitely -- it auto-hides itself a short time after the
        # most recent show(), and each new show() call resets the timer.
        if self._auto_hide_timer_id is not None:
            GLib.source_remove(self._auto_hide_timer_id)
        self._auto_hide_timer_id = GLib.timeout_add(
            self.AUTO_HIDE_MS, self._on_auto_hide_timeout
        )

    def _on_auto_hide_timeout(self):
        log.debug("Auto-hide watchdog fired -- hiding underline.")
        self._auto_hide_timer_id = None
        self.hide()
        return False  # GLib.SOURCE_REMOVE -- don't repeat

    def hide(self):
        self._window.hide()
        if self._auto_hide_timer_id is not None:
            GLib.source_remove(self._auto_hide_timer_id)
            self._auto_hide_timer_id = None

    @staticmethod
    def _hex_to_rgb(color_hex):
        color_hex = color_hex.lstrip("#")
        r = int(color_hex[0:2], 16) / 255.0
        g = int(color_hex[2:4], 16) / 255.0
        b = int(color_hex[4:6], 16) / 255.0
        return (r, g, b)

    # ------------------------------------------------------------------
    # Socket server
    # ------------------------------------------------------------------

    def start_socket_server(self):
        if os.path.exists(self._socket_path):
            os.remove(self._socket_path)
        os.makedirs(os.path.dirname(self._socket_path), exist_ok=True)

        server = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        server.bind(self._socket_path)
        server.listen(1)
        log.info("Overlay listening on %s", self._socket_path)

        thread = threading.Thread(
            target=self._serve_forever, args=(server,), daemon=True
        )
        thread.start()

    def _serve_forever(self, server):
        while True:
            try:
                conn, _ = server.accept()
            except OSError:
                break
            threading.Thread(
                target=self._handle_connection, args=(conn,), daemon=True
            ).start()

    def _handle_connection(self, conn):
        with conn:
            buffer = b""
            while True:
                chunk = conn.recv(4096)
                if not chunk:
                    break
                buffer += chunk
                while b"\n" in buffer:
                    line, buffer = buffer.split(b"\n", 1)
                    if line.strip():
                        self._handle_message(line)

    def _handle_message(self, line):
        try:
            msg = json.loads(line.decode("utf-8"))
        except (json.JSONDecodeError, UnicodeDecodeError):
            log.warning("Received malformed message, ignoring: %r", line[:200])
            return

        action = msg.get("action")
        if action == "show":
            try:
                x, y, w, h = msg["x"], msg["y"], msg["width"], msg["height"]
                color = msg.get("color", "#ff0000")
            except KeyError:
                log.warning("'show' message missing required fields: %r", msg)
                return
            # Marshal onto the GTK main thread -- GTK is not safe to
            # call into directly from this background socket thread.
            GLib.idle_add(self.show, x, y, w, h, color)
        elif action == "hide":
            GLib.idle_add(self.hide)
        else:
            log.warning("Unknown action %r, ignoring.", action)


def main():
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(message)s",
        stream=sys.stderr,
    )

    overlay = UnderlineOverlay()
    overlay.start_socket_server()

    Gtk.main()


if __name__ == "__main__":
    main()
