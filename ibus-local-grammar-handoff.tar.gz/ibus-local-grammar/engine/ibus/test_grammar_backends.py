# -*- encoding: UTF-8 -*-
"""
test_grammar_backends.py

Tests for grammar_backends.py.

HungarianGrammarBackend: fully real-tested, no mocking needed -- it's
in-process Python, same as everywhere else in this project.

EnglishGrammarBackend: tested with a MOCK HTTP server, not a real
LanguageTool instance. This verifies our request-building and response-
parsing logic is correct, and that failures (server unreachable) are
handled safely. It does NOT verify that a real LanguageTool server's
actual grammar-checking behavior matches what we expect -- that was
already verified separately back in Phase 1 (see DEVELOPMENT_LOG.md),
and should be re-confirmed on the real machine if this code changes in
ways that might affect the real integration (e.g. changing the request
format).

Run directly: python3 test_grammar_backends.py
"""

import sys
import os
import json
import threading
import http.server
import importlib.util

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(SCRIPT_DIR, "..", "hungarian"))

spec = importlib.util.spec_from_file_location(
    "grammar_backends", os.path.join(SCRIPT_DIR, "grammar_backends.py")
)
grammar_backends = importlib.util.module_from_spec(spec)
spec.loader.exec_module(grammar_backends)


def test_hungarian_backend_real():
    hu = grammar_backends.HungarianGrammarBackend()

    errors = hu.check("Tudtam hogy ez fog történni.")
    ok1 = len(errors) > 0 and any("vessz" in e["message"].lower() for e in errors)

    errors_clean = hu.check("Megint elkezdtem írni.")
    ok2 = len(errors_clean) == 0

    hu.close()

    ok = ok1 and ok2
    print(f"[{'PASS' if ok else 'FAIL'}] Hungarian backend: catches real "
          f"error, no false positive on clean sentence")
    if not ok:
        print(f"       errors on broken sentence: {errors}")
        print(f"       errors on clean sentence: {errors_clean}")
    return ok


def test_english_backend_unreachable_fails_safely():
    en = grammar_backends.EnglishGrammarBackend(base_url="http://localhost:1")
    errors = en.check("Some sentence here.")
    ok = errors == []
    print(f"[{'PASS' if ok else 'FAIL'}] English backend: fails safely "
          f"(empty list, no crash) when server unreachable")
    if not ok:
        print(f"       got: {errors}")
    return ok


def test_english_backend_empty_sentence():
    en = grammar_backends.EnglishGrammarBackend(base_url="http://localhost:1")
    errors = en.check("   ")
    ok = errors == []
    print(f"[{'PASS' if ok else 'FAIL'}] English backend: empty/whitespace "
          f"sentence returns empty list without even trying to connect")
    if not ok:
        print(f"       got: {errors}")
    return ok


def test_english_backend_parses_mock_response():
    fake_response = json.dumps({
        "software": {"name": "LanguageTool"},
        "matches": [
            {
                "message": "Full message here",
                "shortMessage": "Agreement error",
                "offset": 3,
                "length": 5,
                "replacements": [{"value": "does"}, {"value": "did"}],
            }
        ],
    }).encode("utf-8")

    class FakeHandler(http.server.BaseHTTPRequestHandler):
        def do_POST(self):
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(fake_response)

        def log_message(self, *args):
            pass

    server = http.server.HTTPServer(("localhost", 18082), FakeHandler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()

    try:
        en = grammar_backends.EnglishGrammarBackend(base_url="http://localhost:18082")
        errors = en.check("He dont like coffee.")
        expected = [{
            "start": 3, "end": 8,
            "message": "Agreement error",
            "suggestions": ["does", "did"],
        }]
        ok = errors == expected
        print(f"[{'PASS' if ok else 'FAIL'}] English backend: correctly "
              f"parses a realistic LanguageTool-shaped response")
        if not ok:
            print(f"       expected: {expected}")
            print(f"       got:      {errors}")
        return ok
    finally:
        server.shutdown()


def test_english_backend_handles_malformed_json():
    class BadJSONHandler(http.server.BaseHTTPRequestHandler):
        def do_POST(self):
            self.send_response(200)
            self.end_headers()
            self.wfile.write(b"not valid json{{{")

        def log_message(self, *args):
            pass

    server = http.server.HTTPServer(("localhost", 18083), BadJSONHandler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()

    try:
        en = grammar_backends.EnglishGrammarBackend(base_url="http://localhost:18083")
        errors = en.check("Some sentence.")
        ok = errors == []
        print(f"[{'PASS' if ok else 'FAIL'}] English backend: malformed "
              f"JSON response handled safely (empty list, no crash)")
        if not ok:
            print(f"       got: {errors}")
        return ok
    finally:
        server.shutdown()


def main():
    results = [
        test_hungarian_backend_real(),
        test_english_backend_unreachable_fails_safely(),
        test_english_backend_empty_sentence(),
        test_english_backend_parses_mock_response(),
        test_english_backend_handles_malformed_json(),
    ]
    passed = sum(results)
    failed = len(results) - passed
    print(f"\n== Summary: {passed} passed, {failed} failed out of {len(results)} ==")
    print(
        "\nNOTE: the Hungarian backend test above is a REAL, full test. "
        "The English backend tests verify OUR code's correctness via a "
        "mock server -- they do not confirm the real LanguageTool "
        "server's actual behavior, which was separately verified in "
        "Phase 1 (see DEVELOPMENT_LOG.md) and should be re-checked on "
        "the real machine if this integration code changes."
    )
    if failed > 0:
        sys.exit(1)


if __name__ == "__main__":
    main()
