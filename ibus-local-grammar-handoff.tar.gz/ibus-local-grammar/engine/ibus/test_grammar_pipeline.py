# -*- encoding: UTF-8 -*-
"""
test_grammar_pipeline.py

End-to-end integration test for the full debounced, sentence-level
grammar-checking pipeline: incremental word-by-word typing simulation
(via a real GLib main loop) -> debounced grammar check -> sentence
extraction -> language routing -> backend check -> logged result.

This is a regression test for two real bugs found while building this
pipeline:
  1. The grammar check was triggered with the wrong cursor position
     when a sentence-ending period was attached to the just-completed
     word (e.g. "history."), causing sentence_extract to treat that
     period as a boundary and return the (empty) text AFTER it --
     silently skipping the sentence that had just been completed.
  2. The first fix attempt (using word_end instead of the live cursor
     position) was insufficient, because word_end still pointed to
     just after the attached period. The real fix strips trailing
     punctuation from the word before computing the position used for
     sentence extraction.

Run directly: python3 test_grammar_pipeline.py
"""

import sys
import os
import importlib.util

import gi
gi.require_version("IBus", "1.0")
from gi.repository import GLib

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(SCRIPT_DIR, "..", "hungarian"))

spec = importlib.util.spec_from_file_location(
    "engine", os.path.join(SCRIPT_DIR, "engine.py")
)
engine_module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(engine_module)


def simulate_typing(eng, words_and_delays, settle_time_ms=1500):
    """
    Simulates incremental word-by-word typing by scheduling
    _check_and_show_errors calls at increasing delays, via a real GLib
    loop (required since debouncing depends on real timer processing).
    Returns once settle_time_ms has passed after the last scheduled word.
    """
    loop = GLib.MainLoop()
    t = 0
    for text, delay in words_and_delays:
        t += delay
        GLib.timeout_add(
            t,
            lambda text=text: (eng._check_and_show_errors(text, len(text)), False)[1],
        )
    GLib.timeout_add(t + settle_time_ms, lambda: (loop.quit(), False)[1])
    loop.run()


def capture_log_during(fn):
    import io
    import logging
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger = logging.getLogger("ibus-local-grammar")
    old_level = logger.level
    logger.addHandler(handler)
    logger.setLevel(logging.DEBUG)
    try:
        fn()
    finally:
        logger.removeHandler(handler)
        logger.setLevel(old_level)
    return stream.getvalue()


def test_hungarian_sentence_with_trailing_period_still_gets_checked():
    """
    The core regression test: a Hungarian sentence ending in a period,
    with a real grammar error, typed incrementally, must still trigger
    a correct grammar check despite the trailing period.
    """
    eng = engine_module.LocalGrammarEngine()
    eng._ensure_checkers()

    words_and_delays = [
        ("Tudtam ", 50),
        ("Tudtam hogy ", 50),
        ("Tudtam hogy ez ", 50),
        ("Tudtam hogy ez fog ", 50),
        ("Tudtam hogy ez fog történni. ", 50),
    ]

    log_output = capture_log_during(lambda: simulate_typing(eng, words_and_delays))

    checked_right_sentence = (
        "checking sentence 'Tudtam hogy ez fog történni'" in log_output
    )
    used_hungarian_backend = "via Hungarian backend" in log_output
    found_the_comma_error = (
        "would flag" in log_output and "Tudtam hogy" in log_output
    )
    did_not_silently_skip = "sentence '' too short to check" not in log_output

    ok = (
        checked_right_sentence
        and used_hungarian_backend
        and found_the_comma_error
        and did_not_silently_skip
    )
    print(f"[{'PASS' if ok else 'FAIL'}] Hungarian sentence with trailing "
          f"period still gets correctly grammar-checked")
    if not ok:
        print(f"       checked_right_sentence={checked_right_sentence}")
        print(f"       used_hungarian_backend={used_hungarian_backend}")
        print(f"       found_the_comma_error={found_the_comma_error}")
        print(f"       did_not_silently_skip={did_not_silently_skip}")
        print(f"       full log: {log_output}")
    return ok


def test_debounce_collapses_multiple_words_into_one_check():
    """
    Confirms that typing multiple words in quick succession (faster
    than GRAMMAR_CHECK_DEBOUNCE_MS apart) results in only ONE grammar
    check, not one per word -- the whole point of debouncing this.
    """
    eng = engine_module.LocalGrammarEngine()
    eng._ensure_checkers()

    # All words 50ms apart -- much faster than the 700ms grammar debounce
    words_and_delays = [
        ("The ", 50),
        ("The quick ", 50),
        ("The quick brown ", 50),
        ("The quick brown fox ", 50),
    ]

    log_output = capture_log_during(lambda: simulate_typing(eng, words_and_delays))

    check_count = log_output.count("[grammar-check] checking sentence")
    ok = check_count == 1
    print(f"[{'PASS' if ok else 'FAIL'}] rapid word-by-word typing "
          f"collapses to exactly 1 grammar check, not 4")
    if not ok:
        print(f"       check_count={check_count}")
        print(f"       log: {log_output}")
    return ok


def test_too_short_sentence_is_skipped():
    """
    A single word shouldn't trigger a grammar check at all -- not
    enough content to meaningfully check.
    """
    eng = engine_module.LocalGrammarEngine()
    eng._ensure_checkers()

    log_output = capture_log_during(
        lambda: simulate_typing(eng, [("Hello ", 50)])
    )

    skipped = "too short to check yet" in log_output
    no_actual_check_ran = "checking sentence" not in log_output
    ok = skipped and no_actual_check_ran
    print(f"[{'PASS' if ok else 'FAIL'}] single-word 'sentence' is "
          f"correctly skipped, not sent to a grammar backend")
    if not ok:
        print(f"       log: {log_output}")
    return ok


def main():
    results = [
        test_hungarian_sentence_with_trailing_period_still_gets_checked(),
        test_debounce_collapses_multiple_words_into_one_check(),
        test_too_short_sentence_is_skipped(),
    ]
    passed = sum(results)
    failed = len(results) - passed
    print(f"\n== Summary: {passed} passed, {failed} failed out of {len(results)} ==")
    if failed > 0:
        sys.exit(1)


if __name__ == "__main__":
    main()
