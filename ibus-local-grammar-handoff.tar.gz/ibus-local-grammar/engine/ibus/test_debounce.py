# -*- encoding: UTF-8 -*-
"""
test_debounce.py

Automated tests for LocalGrammarEngine._schedule_debounced(), the
generic debounce helper added per user-relayed feedback (rapid key
events/repeats should collapse into a single evaluation rather than
firing once per event).

These tests require a REAL GLib main loop, since debouncing is
fundamentally about how the event loop processes scheduled timers --
this cannot be meaningfully tested by calling functions directly
without a loop running.

Run directly: python3 test_debounce.py
"""

import sys
import os
import importlib.util

import gi
gi.require_version("IBus", "1.0")
from gi.repository import GLib

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
spec = importlib.util.spec_from_file_location(
    "engine", os.path.join(SCRIPT_DIR, "engine.py")
)
engine_module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(engine_module)


def run_with_timeout(setup_fn, total_runtime_ms):
    """
    Runs setup_fn() (which should schedule whatever timeouts it wants
    to test), then runs a real GLib main loop for total_runtime_ms
    before quitting it. Returns nothing -- setup_fn is expected to
    record results into variables it closes over.
    """
    loop = GLib.MainLoop()
    setup_fn()
    GLib.timeout_add(total_runtime_ms, lambda: (loop.quit(), False)[1])
    loop.run()


def test_rapid_calls_collapse_to_one():
    eng = engine_module.LocalGrammarEngine()
    calls = []

    def setup():
        for i, delay in enumerate([0, 5, 10, 15, 20]):
            label = f"call_{i}"
            GLib.timeout_add(
                delay,
                lambda label=label: (
                    eng._schedule_debounced("test", 50, calls.append, label),
                    False,
                )[1],
            )

    run_with_timeout(setup, 200)

    ok = len(calls) == 1 and calls[0] == "call_4"
    print(f"[{'PASS' if ok else 'FAIL'}] 5 rapid calls collapse to exactly 1, "
          f"and it's the LAST one scheduled")
    if not ok:
        print(f"       calls recorded: {calls}")
    return ok


def test_well_spaced_calls_each_fire():
    eng = engine_module.LocalGrammarEngine()
    calls = []

    def setup():
        GLib.timeout_add(
            0, lambda: (eng._schedule_debounced("test", 50, calls.append, "first"), False)[1]
        )
        GLib.timeout_add(
            150, lambda: (eng._schedule_debounced("test", 50, calls.append, "second"), False)[1]
        )
        GLib.timeout_add(
            300, lambda: (eng._schedule_debounced("test", 50, calls.append, "third"), False)[1]
        )

    run_with_timeout(setup, 500)

    ok = calls == ["first", "second", "third"]
    print(f"[{'PASS' if ok else 'FAIL'}] 3 well-spaced calls (beyond debounce "
          f"window) each fire independently")
    if not ok:
        print(f"       calls recorded: {calls}")
    return ok


def test_different_timer_names_dont_interfere():
    eng = engine_module.LocalGrammarEngine()
    calls = []

    def setup():
        GLib.timeout_add(
            0, lambda: (eng._schedule_debounced("timer_a", 50, calls.append, "a"), False)[1]
        )
        GLib.timeout_add(
            5, lambda: (eng._schedule_debounced("timer_b", 50, calls.append, "b"), False)[1]
        )

    run_with_timeout(setup, 150)

    ok = sorted(calls) == ["a", "b"]
    print(f"[{'PASS' if ok else 'FAIL'}] different timer names don't cancel "
          f"each other's pending timers")
    if not ok:
        print(f"       calls recorded: {calls}")
    return ok


def main():
    results = [
        test_rapid_calls_collapse_to_one(),
        test_well_spaced_calls_each_fire(),
        test_different_timer_names_dont_interfere(),
    ]
    passed = sum(results)
    failed = len(results) - passed
    print(f"\n== Summary: {passed} passed, {failed} failed out of {len(results)} ==")
    if failed > 0:
        sys.exit(1)


if __name__ == "__main__":
    main()
