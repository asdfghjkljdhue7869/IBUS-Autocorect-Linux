# -*- encoding: UTF-8 -*-
"""
test_suggestion_popup.py

Automated tests for the suggestion popup feature (_show_underline now
shows a real IBus lookup table instead of just logging, and
do_candidate_clicked replaces the flagged word with the chosen
suggestion). Uses mocked IBus calls (update_lookup_table,
hide_lookup_table, delete_surrounding_text, commit_text) since they
need a real bus connection this standalone test doesn't have -- this
verifies OUR logic (suggestion fetching, state tracking, offset math,
cleanup) which is the part that can have real bugs independent of
whether IBus's actual rendering looks right (that part needs the real
machine).

Run directly: python3 test_suggestion_popup.py
"""

import sys
import os
import importlib.util

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(SCRIPT_DIR, "..", "hungarian"))

spec = importlib.util.spec_from_file_location(
    "engine", os.path.join(SCRIPT_DIR, "engine.py")
)
engine_module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(engine_module)


def make_mocked_engine():
    eng = engine_module.LocalGrammarEngine()
    eng._calls = []
    eng.update_lookup_table = lambda lt, visible: eng._calls.append(("update_lookup_table", lt, visible))
    eng.hide_lookup_table = lambda: eng._calls.append(("hide_lookup_table",))
    eng.delete_surrounding_text = lambda offset, length: eng._calls.append(("delete_surrounding_text", offset, length))
    eng.commit_text = lambda text: eng._calls.append(("commit_text", text.get_text()))
    eng._ensure_checkers()
    return eng


def test_misspelled_word_shows_popup_with_real_suggestions():
    eng = make_mocked_engine()
    eng._show_underline("wrld", 0, 4, 5)

    showed_popup = any(c[0] == "update_lookup_table" for c in eng._calls)
    ok = (
        showed_popup
        and eng._active_suggestion_word == "wrld"
        and len(eng._active_suggestion_list) > 0
        and len(eng._active_suggestion_list) <= 3
    )
    print(f"[{'PASS' if ok else 'FAIL'}] misspelled word shows a popup "
          f"with 1-3 real suggestions tracked in state")
    if not ok:
        print(f"       calls={eng._calls} active_list={eng._active_suggestion_list}")
    return ok


def test_correctly_spelled_word_shows_no_popup():
    eng = make_mocked_engine()
    eng._show_underline("world", 0, 5, 6)

    showed_popup = any(c[0] == "update_lookup_table" for c in eng._calls)
    ok = (not showed_popup) and eng._active_suggestion_word is None
    print(f"[{'PASS' if ok else 'FAIL'}] correctly spelled word shows "
          f"NO popup (guard against showing empty/unnecessary suggestions)")
    if not ok:
        print(f"       calls={eng._calls}")
    return ok


def test_clicking_suggestion_replaces_word_with_correct_offset():
    eng = make_mocked_engine()
    text = "I luv teh wrld "
    eng._show_underline("wrld", 10, 14, len(text))
    eng._surrounding_text = text
    eng._surrounding_cursor_pos = len(text)
    eng.do_candidate_clicked(0, 1, 0)

    delete_calls = [c for c in eng._calls if c[0] == "delete_surrounding_text"]
    commit_calls = [c for c in eng._calls if c[0] == "commit_text"]

    ok = len(delete_calls) == 1 and len(commit_calls) == 1
    if ok:
        offset, length = delete_calls[0][1], delete_calls[0][2]
        delete_start = len(text) + offset
        deleted_region = text[delete_start:delete_start + length]
        # "wrld" sits between two spaces, so the space-collapsing fix
        # extends the delete to include the trailing space.
        ok = deleted_region == "wrld "

    print(f"[{'PASS' if ok else 'FAIL'}] clicking a suggestion computes "
          f"the correct delete region (exactly the flagged word, "
          f"verified by slicing the original text)")
    if not ok:
        print(f"       calls={eng._calls}")
    return ok


def test_clicking_suggestion_clears_active_state():
    eng = make_mocked_engine()
    text = "I luv teh wrld "
    eng._show_underline("wrld", 10, 14, len(text))
    eng._surrounding_text = text
    eng._surrounding_cursor_pos = len(text)
    eng.do_candidate_clicked(0, 1, 0)

    ok = (
        eng._active_suggestion_word is None
        and eng._active_suggestion_list == []
        and any(c[0] == "hide_lookup_table" for c in eng._calls)
    )
    print(f"[{'PASS' if ok else 'FAIL'}] clicking a suggestion clears "
          f"all active-suggestion state and hides the lookup table")
    if not ok:
        print(f"       word={eng._active_suggestion_word} list={eng._active_suggestion_list}")
    return ok


def test_right_click_is_ignored():
    eng = make_mocked_engine()
    text = "I luv teh wrld "
    eng._show_underline("wrld", 10, 14, len(text))
    eng._surrounding_text = text
    eng._surrounding_cursor_pos = len(text)
    calls_before = len(eng._calls)
    eng.do_candidate_clicked(0, 3, 0)  # button=3, not left-click

    no_new_calls = len(eng._calls) == calls_before
    state_intact = eng._active_suggestion_word == "wrld"
    ok = no_new_calls and state_intact
    print(f"[{'PASS' if ok else 'FAIL'}] non-left-click is ignored, "
          f"popup state remains intact")
    if not ok:
        print(f"       calls_before={calls_before} calls_after={len(eng._calls)} "
              f"word={eng._active_suggestion_word}")
    return ok


def test_click_with_no_active_suggestion_is_safe():
    eng = make_mocked_engine()
    # No _show_underline call first -- no active suggestion exists.
    try:
        eng.do_candidate_clicked(0, 1, 0)
        ok = True  # didn't raise
    except Exception as e:
        ok = False
        print(f"       raised: {e}")
    print(f"[{'PASS' if ok else 'FAIL'}] clicking when there's no active "
          f"suggestion is handled safely (no crash)")
    return ok


def test_click_with_out_of_range_index_is_safe():
    eng = make_mocked_engine()
    text = "I luv teh wrld "
    eng._show_underline("wrld", 10, 14, len(text))
    eng._surrounding_text = text
    eng._surrounding_cursor_pos = len(text)
    calls_before = len(eng._calls)

    try:
        eng.do_candidate_clicked(99, 1, 0)  # way out of range
        ok = len(eng._calls) == calls_before  # should be a no-op, not a crash
    except Exception as e:
        ok = False
        print(f"       raised: {e}")
    print(f"[{'PASS' if ok else 'FAIL'}] out-of-range candidate index "
          f"is handled safely (no crash, no action taken)")
    return ok


def test_click_after_realistic_typing_drift_still_replaces_correctly():
    """
    THE CRITICAL REGRESSION TEST for the real bug found via real-machine
    testing: a popup is shown for a word, then the user keeps typing
    MORE text before actually clicking (entirely realistic -- clicking
    takes real human time), so the live cursor position and surrounding
    text have moved on by the time the click is processed. The fix
    searches the LIVE text for the word at click time rather than
    trusting any position computed back when the popup first appeared.
    """
    eng = make_mocked_engine()

    # Popup shown when text was "i luv teh " (cursor at 10).
    eng._show_underline("teh", 6, 9, 10)

    # Simulate realistic drift: more text gets typed before the click.
    eng._surrounding_text = "i luv teh wrld "
    eng._surrounding_cursor_pos = 15

    eng.do_candidate_clicked(0, 1, 0)

    delete_calls = [c for c in eng._calls if c[0] == "delete_surrounding_text"]
    commit_calls = [c for c in eng._calls if c[0] == "commit_text"]

    ok = len(delete_calls) == 1 and len(commit_calls) == 1
    if ok:
        offset, length = delete_calls[0][1], delete_calls[0][2]
        live_text = eng._surrounding_text
        delete_start = eng._surrounding_cursor_pos + offset
        deleted_region = live_text[delete_start:delete_start + length]
        # "teh" sits between two spaces in "i luv teh wrld ", so the
        # space-collapsing fix (added after finding the double-space
        # cosmetic issue via real-machine testing) correctly extends
        # the delete to include the trailing space -- "teh " (4 chars),
        # not just "teh" (3 chars) -- and the commit text correspondingly
        # includes a single replacement space, net effect: no doubled
        # space left behind.
        ok = deleted_region == "teh "
        commit_text = commit_calls[0][1]
        ok = ok and commit_text.endswith(" ")

    print(f"[{'PASS' if ok else 'FAIL'}] click after realistic typing "
          f"drift still correctly finds and replaces 'teh', not some "
          f"other position (the actual real-machine bug)")
    if not ok:
        print(f"       calls={eng._calls}")
    return ok


def test_click_when_word_no_longer_exists_is_safe():
    """
    If the flagged word genuinely can't be found anymore (e.g. the user
    deleted/changed it themselves before clicking the stale popup), the
    fix should do nothing rather than guess at a position and risk
    corrupting unrelated text.
    """
    eng = make_mocked_engine()
    eng._show_underline("teh", 6, 9, 10)

    # The word is just gone from the live text now.
    eng._surrounding_text = "i luv  "
    eng._surrounding_cursor_pos = 7

    eng.do_candidate_clicked(0, 1, 0)

    no_delete = not any(c[0] == "delete_surrounding_text" for c in eng._calls)
    no_commit = not any(c[0] == "commit_text" for c in eng._calls)
    ok = no_delete and no_commit
    print(f"[{'PASS' if ok else 'FAIL'}] when the flagged word can no "
          f"longer be found, nothing is deleted or committed (safe no-op)")
    if not ok:
        print(f"       calls={eng._calls}")
    return ok


def test_space_collapse_when_word_between_two_spaces():
    """
    THE FIX for the cosmetic double-space issue found via real-machine
    testing: a word sitting between two spaces should leave exactly ONE
    space behind after replacement, not two.
    """
    eng = make_mocked_engine()
    text = " is why kate "
    eng._show_underline("kate", 8, 12, len(text))
    eng._surrounding_text = text
    eng._surrounding_cursor_pos = len(text)
    eng.do_candidate_clicked(1, 1, 0)  # assume 'Kate' is a suggestion

    delete_calls = [c for c in eng._calls if c[0] == "delete_surrounding_text"]
    commit_calls = [c for c in eng._calls if c[0] == "commit_text"]

    ok = len(delete_calls) == 1 and len(commit_calls) == 1
    if ok:
        offset, length = delete_calls[0][1], delete_calls[0][2]
        commit_text = commit_calls[0][1]
        delete_start = len(text) + offset
        result = text[:delete_start] + commit_text + text[delete_start + length:]
        # The single most important check: no doubled space anywhere.
        ok = "  " not in result

    print(f"[{'PASS' if ok else 'FAIL'}] word between two spaces leaves "
          f"exactly one space behind after replacement (no double space)")
    if not ok:
        print(f"       calls={eng._calls}")
    return ok


def test_no_space_collapse_when_word_at_end_of_text():
    """
    Edge case: if the flagged word is at the very end of the text (no
    trailing space at all, e.g. user hasn't typed anything after it
    yet), the space-collapse logic must NOT fire -- there's no second
    space to collapse, and trying would incorrectly eat into text that
    doesn't exist or isn't a space.
    """
    eng = make_mocked_engine()
    text = "i luv teh"  # no trailing space -- "teh" is the very last thing typed
    eng._show_underline("teh", 6, 9, len(text))
    eng._surrounding_text = text
    eng._surrounding_cursor_pos = len(text)
    eng.do_candidate_clicked(0, 1, 0)

    delete_calls = [c for c in eng._calls if c[0] == "delete_surrounding_text"]
    commit_calls = [c for c in eng._calls if c[0] == "commit_text"]

    ok = len(delete_calls) == 1 and len(commit_calls) == 1
    if ok:
        offset, length = delete_calls[0][1], delete_calls[0][2]
        ok = length == 3  # exactly "teh", NOT extended by a nonexistent trailing space
        commit_text = commit_calls[0][1]
        ok = ok and not commit_text.endswith(" ")  # no extra space appended

    print(f"[{'PASS' if ok else 'FAIL'}] word at the very end of text "
          f"(no trailing space) does not trigger space-collapse logic")
    if not ok:
        print(f"       calls={eng._calls}")
    return ok


def test_hungarian_context_routes_to_hungarian_suggester():
    """
    NOTE: a misspelled word, by definition, fails validity in BOTH
    dictionaries simultaneously (that's what makes it misspelled), so
    its own language vote is always "neither" -- it can never itself
    vote Hungarian or English. The real routing mechanism for
    misspelled words is the SENTENCE CONTEXT fallback (built and
    tested earlier in this project, in language_detect.py), which is
    what this test actually verifies: feeding in surrounding Hungarian
    context first, then checking that the suggester correctly follows.
    """
    eng = make_mocked_engine()

    # Build up Hungarian context first, same as language_detect.py's
    # own tests do -- "kutya" and "itt" are real, correctly-spelled
    # Hungarian words, so they vote Hungarian and shift the context.
    from language_detect import WordLanguageVote
    eng._lang_context.record_vote(WordLanguageVote.HUNGARIAN)
    eng._lang_context.record_vote(WordLanguageVote.HUNGARIAN)

    eng._show_underline("házz", 0, 4, 5)

    ok = (
        eng._active_suggestion_word == "házz"
        and "ház" in eng._active_suggestion_list
    )
    print(f"[{'PASS' if ok else 'FAIL'}] misspelled word with Hungarian "
          f"sentence context gets Hungarian suggestions")
    if not ok:
        print(f"       active_list={eng._active_suggestion_list}")
    return ok


def main():
    results = [
        test_misspelled_word_shows_popup_with_real_suggestions(),
        test_correctly_spelled_word_shows_no_popup(),
        test_clicking_suggestion_replaces_word_with_correct_offset(),
        test_clicking_suggestion_clears_active_state(),
        test_right_click_is_ignored(),
        test_click_with_no_active_suggestion_is_safe(),
        test_click_with_out_of_range_index_is_safe(),
        test_click_after_realistic_typing_drift_still_replaces_correctly(),
        test_click_when_word_no_longer_exists_is_safe(),
        test_space_collapse_when_word_between_two_spaces(),
        test_no_space_collapse_when_word_at_end_of_text(),
        test_hungarian_context_routes_to_hungarian_suggester(),
    ]
    passed = sum(results)
    failed = len(results) - passed
    print(f"\n== Summary: {passed} passed, {failed} failed out of {len(results)} ==")
    if failed > 0:
        sys.exit(1)


if __name__ == "__main__":
    main()
