# -*- encoding: UTF-8 -*-
"""
test_language_detect.py

Automated tests for language_detect.py, using REAL Hunspell dictionaries
(not fakes), since this module's entire value proposition is "does it
correctly classify real words" -- a fake would test nothing meaningful
here.

Run directly: python3 test_language_detect.py
"""

import sys
import os
import importlib.util

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(SCRIPT_DIR, "..", "hungarian"))

spec = importlib.util.spec_from_file_location(
    "language_detect", os.path.join(SCRIPT_DIR, "language_detect.py")
)
language_detect = importlib.util.module_from_spec(spec)
spec.loader.exec_module(language_detect)

from hunspell_morph import HunspellMorphAnalyzer


# (word, expected_vote)
WORD_VOTE_CASES = [
    ("hello", language_detect.WordLanguageVote.ENGLISH),
    ("world", language_detect.WordLanguageVote.ENGLISH),
    ("kutya", language_detect.WordLanguageVote.HUNGARIAN),  # "dog"
    ("ház", language_detect.WordLanguageVote.HUNGARIAN),    # "house"
    ("van", language_detect.WordLanguageVote.BOTH),  # genuine cross-language homograph
    ("xqzwj", language_detect.WordLanguageVote.NEITHER),  # not a real word in either
    ("", language_detect.WordLanguageVote.NEITHER),
]

# Sentence-context resolution scenarios:
# (list of (word, vote) pairs to feed in as context, then which vote to
#  resolve, expected resolution)
CONTEXT_CASES = [
    (
        "All-English context, then an ambiguous word -> should resolve English",
        [
            (language_detect.WordLanguageVote.ENGLISH,),
            (language_detect.WordLanguageVote.ENGLISH,),
            (language_detect.WordLanguageVote.ENGLISH,),
        ],
        language_detect.WordLanguageVote.ENGLISH,
    ),
    (
        "All-Hungarian context, then an ambiguous word -> should resolve Hungarian",
        [
            (language_detect.WordLanguageVote.HUNGARIAN,),
            (language_detect.WordLanguageVote.HUNGARIAN,),
        ],
        language_detect.WordLanguageVote.HUNGARIAN,
    ),
    (
        "No context at all (start of sentence) -> default to English",
        [],
        language_detect.WordLanguageVote.ENGLISH,
    ),
    (
        "Mixed context, Hungarian slightly ahead -> resolves Hungarian",
        [
            (language_detect.WordLanguageVote.HUNGARIAN,),
            (language_detect.WordLanguageVote.HUNGARIAN,),
            (language_detect.WordLanguageVote.ENGLISH,),
        ],
        language_detect.WordLanguageVote.HUNGARIAN,
    ),
    (
        "BOTH and NEITHER votes don't count as evidence either way -- "
        "tie remains, defaults to English",
        [
            (language_detect.WordLanguageVote.BOTH,),
            (language_detect.WordLanguageVote.NEITHER,),
        ],
        language_detect.WordLanguageVote.ENGLISH,
    ),
]


def main():
    print("Loading real Hunspell dictionaries (en_GB, hu_HU)...")
    en = HunspellMorphAnalyzer(dictionary="en_GB")
    hu = HunspellMorphAnalyzer(dictionary="hu_HU")
    detector = language_detect.LanguageDetector(en, hu)

    passed = 0
    failed = 0

    print("\n== Word-level vote tests ==")
    for word, expected in WORD_VOTE_CASES:
        actual = detector.vote_for_word(word)
        ok = actual == expected
        status = "PASS" if ok else "FAIL"
        if ok:
            passed += 1
        else:
            failed += 1
        print(f"[{status}] {word!r} -> expected {expected}, got {actual}")

    print("\n== Sentence-context resolution tests ==")
    for description, context_votes, expected in CONTEXT_CASES:
        ctx = language_detect.LanguageContext()
        for (vote,) in context_votes:
            ctx.record_vote(vote)
        actual = ctx.resolve_ambiguous()
        ok = actual == expected
        status = "PASS" if ok else "FAIL"
        if ok:
            passed += 1
        else:
            failed += 1
        print(f"[{status}] {description}")
        if not ok:
            print(f"       expected {expected}, got {actual}, stats={ctx.stats()}")

    en.close()
    hu.close()

    print(f"\n== Summary: {passed} passed, {failed} failed out of {len(WORD_VOTE_CASES) + len(CONTEXT_CASES)} ==")
    if failed > 0:
        sys.exit(1)


if __name__ == "__main__":
    main()
