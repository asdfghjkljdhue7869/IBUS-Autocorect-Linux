# -*- encoding: UTF-8 -*-
"""
language_detect.py

Decides whether a word/sentence is English or Hungarian, for routing to
the correct spelling/grammar backend.

WHY NOT A STATISTICAL LANGUAGE DETECTOR:
Tested python3-langdetect (a standard, widely-used statistical detector,
ported from Google's language-detection library) directly against single
words we'll actually encounter during live typing. Results were
essentially random noise: "hello" detected as Finnish, "van" (a real
Hungarian word, and the EXACT ambiguous English/Hungarian case this
project's user originally flagged as the hard problem) detected as
Afrikaans, "kutya" (Hungarian for "dog") detected as Swahili. This is
not a close-but-imperfect tool for our purpose -- statistical n-gram
detectors fundamentally need much more text than a single word to mean
anything, and using one here would produce confidently wrong answers,
which is worse than admitting uncertainty.

THE APPROACH USED INSTEAD: dual-dictionary lookup.
Ask both the English (en_GB) and Hungarian (hu_HU) Hunspell dictionaries
directly "do you recognize this word" and use that as the real signal:
  - Recognized by English only -> English
  - Recognized by Hungarian only -> Hungarian
  - Recognized by BOTH (genuine cross-language homographs, e.g. "van")
    or NEITHER (misspelled in both, or a name/number/etc.) -> ambiguous,
    fall back to sentence-level context (see LanguageContext below).

This was verified directly: "kutya" correctly resolves to Hungarian-only,
"hello" correctly resolves to English-only, and "van" correctly comes
back as recognized by BOTH (not a wrong guess -- a correct statement of
real ambiguity), which is exactly the case sentence-context fallback is
for.
"""

import logging
import sys
import os

log = logging.getLogger("ibus-local-grammar")

sys.path.insert(
    0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "hungarian")
)


class WordLanguageVote:
    """Result of checking a single word against both dictionaries."""

    ENGLISH = "en"
    HUNGARIAN = "hu"
    BOTH = "both"
    NEITHER = "neither"


class LanguageDetector:
    """
    Dual-dictionary word-level language detection, with a simple
    sentence-context fallback for genuinely ambiguous words.
    """

    def __init__(self, english_hunspell, hungarian_hunspell):
        """
        Takes two already-constructed HunspellMorphAnalyzer instances
        (or anything with an is_valid(word) method) -- one for each
        language. Constructed this way (dependency injection) rather
        than creating its own internally, so tests can pass in fakes
        without needing real Hunspell processes running.
        """
        self._en = english_hunspell
        self._hu = hungarian_hunspell

    def vote_for_word(self, word):
        """
        Returns one of WordLanguageVote's four constants for a single
        word, based on dual-dictionary lookup.
        """
        if not word:
            return WordLanguageVote.NEITHER

        en_valid = self._en.is_valid(word)
        hu_valid = self._hu.is_valid(word)

        if en_valid and hu_valid:
            return WordLanguageVote.BOTH
        if en_valid:
            return WordLanguageVote.ENGLISH
        if hu_valid:
            return WordLanguageVote.HUNGARIAN
        return WordLanguageVote.NEITHER


class LanguageContext:
    """
    Tracks a simple running tally of recent per-word language votes for
    the CURRENT sentence, used to break ties when a word is ambiguous
    (recognized by both dictionaries, or neither).

    Deliberately simple for this stage: a running count of EN vs HU
    votes seen so far in the current sentence. Reset when a new
    sentence starts (see reset_for_new_sentence). This is intentionally
    NOT a sophisticated model -- it's "what has the rest of this
    sentence mostly been," which is a much better-justified guess for a
    genuinely ambiguous word than a statistical guess on the word alone
    would be.
    """

    def __init__(self):
        self._en_votes = 0
        self._hu_votes = 0

    def reset_for_new_sentence(self):
        self._en_votes = 0
        self._hu_votes = 0

    def record_vote(self, vote):
        if vote == WordLanguageVote.ENGLISH:
            self._en_votes += 1
        elif vote == WordLanguageVote.HUNGARIAN:
            self._hu_votes += 1
        # BOTH and NEITHER deliberately don't move the tally -- an
        # ambiguous or unrecognized word shouldn't count as evidence
        # for either language.

    def resolve_ambiguous(self):
        """
        Called when a word's own vote was BOTH or NEITHER, to decide
        which language to actually use for checking IT specifically,
        based on context seen so far in this sentence.

        Returns WordLanguageVote.ENGLISH or HUNGARIAN. If there's truly
        no context yet (very start of a sentence, e.g. typing "van" as
        literally the first word), defaults to ENGLISH -- an arbitrary
        but explicit choice, documented here rather than left as an
        implicit accident. This default is a deliberate placeholder and
        a reasonable thing to revisit later if real usage shows it's
        wrong more often than right.
        """
        if self._hu_votes > self._en_votes:
            return WordLanguageVote.HUNGARIAN
        return WordLanguageVote.ENGLISH

    def stats(self):
        return {"en_votes": self._en_votes, "hu_votes": self._hu_votes}
