# -*- encoding: UTF-8 -*-
"""
document_scan.py

Scans an entire document's text for spelling and grammar errors, rather
than checking only live-typed text word by word. This is the backend
for "open a document, find everything wrong with it" -- reuses the
exact same checking backends (Hunspell bilingual spelling, LanguageTool
+ our Hungarian engine for grammar) already built and proven for live
typing, just applied to a full block of text instead of one word/
sentence at a time.

No positional memory between sessions (confirmed with the user this
isn't needed) -- a fresh scan is run every time. The ignore-list
(separate module, ignore_list.py) is consulted here so previously-
dismissed words are filtered out of the results.

EFFICIENCY HIERARCHY (per user's request: "skip through where it can
go faster, focus where there might be a problem"):
  - Spelling check (Hunspell) is extremely fast (sub-millisecond per
    word, measured in earlier phases) -- run on EVERY word, no skipping
    needed at all here.
  - Grammar check (LanguageTool / Hungarian engine) is much more
    expensive (LanguageTool: ~89ms per call even warmed up, measured in
    Phase 1) -- this is the one that needs the "hierarchy". We batch by
    SENTENCE (already proven correct via sentence_extract.py) rather
    than checking the whole document as one giant blob (which risks
    timeouts/slowness on large documents) or word-by-word (wasteful,
    grammar needs sentence context anyway).
  - Within grammar checking, we skip sentences that contain ZERO
    spelling errors AND are short/simple -- no, actually: we do NOT skip
    any sentence for grammar checking based on spelling results, because
    grammar errors (real-word errors like "form" vs "from", missing
    commas) are independent of spelling correctness. The "hierarchy" is
    really about NOT re-deriving sentence boundaries character-by-
    character across a huge document (using a single pass to split into
    sentences first, then checking each sentence once) rather than any
    content-based skipping -- skipping based on guessed "likely fine"
    content risks missing real errors, which would undermine the whole
    point of the feature.
"""

import logging
import sys
import os

log = logging.getLogger("ibus-local-grammar")

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(
    0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "hungarian")
)

from sentence_extract import SENTENCE_ENDERS


def split_into_sentences(text):
    """
    Split a full document's text into a list of (sentence_text,
    start_offset) tuples, where start_offset is the character position
    of the sentence's start within the original `text`.

    Simple, single-pass split on sentence-ending punctuation (. ! ?),
    consistent with sentence_extract.py's existing boundary logic (same
    SENTENCE_ENDERS set) so behavior matches what live-typing checking
    already does -- we don't want the document-scan feature to use
    different sentence-boundary rules than the live-typing feature.
    """
    sentences = []
    current_start = 0
    i = 0
    n = len(text)
    while i < n:
        if text[i] in SENTENCE_ENDERS:
            sentence_text = text[current_start:i + 1]
            if sentence_text.strip():
                # Find where the actual content starts (skip leading
                # whitespace), matching extract_current_sentence's
                # behavior of stripping leading whitespace after a
                # sentence-ender.
                stripped_start = current_start
                while stripped_start < i and text[stripped_start].isspace():
                    stripped_start += 1
                sentences.append((text[stripped_start:i + 1], stripped_start))
            current_start = i + 1
        i += 1

    # Trailing content with no closing punctuation (e.g. the document
    # doesn't end in a period) -- still worth checking.
    if current_start < n:
        stripped_start = current_start
        while stripped_start < n and text[stripped_start].isspace():
            stripped_start += 1
        trailing = text[stripped_start:n]
        if trailing.strip():
            sentences.append((trailing, stripped_start))

    return sentences


class DocumentScanner:
    """
    Ties together language detection, spelling checking (both
    languages), and grammar checking (both backends) to scan a full
    document's text and return all findings.
    """

    def __init__(self, hunspell_en, hunspell_hu, lang_detector,
                 grammar_en, grammar_hu, ignore_list=None):
        """
        Takes already-constructed checker instances (dependency
        injection, same pattern as language_detect.py) so this can be
        tested with the same real backends the live engine uses,
        without this module needing to know how to construct them.

        ignore_list: optional object with a method is_ignored(word) ->
        bool. If None, nothing is filtered (useful for testing this
        module before ignore_list.py exists).
        """
        self._hunspell_en = hunspell_en
        self._hunspell_hu = hunspell_hu
        self._lang_detector = lang_detector
        self._grammar_en = grammar_en
        self._grammar_hu = grammar_hu
        self._ignore_list = ignore_list

    def _is_ignored(self, word):
        if self._ignore_list is None:
            return False
        return self._ignore_list.is_ignored(word)

    def scan(self, document_text):
        """
        Returns a list of finding dicts, each with:
          start, end       -- character offsets within document_text
          word_or_phrase    -- the flagged text
          kind              -- "spelling" or "grammar"
          suggestions       -- list of suggested replacements
          message           -- human-readable explanation
        Sorted by start offset.
        """
        findings = []
        findings.extend(self._scan_spelling(document_text))
        findings.extend(self._scan_grammar(document_text))
        findings.sort(key=lambda f: f["start"])
        return findings

    def _scan_spelling(self, document_text):
        """
        Fast pass: check every individual word's spelling. No skipping
        -- this is cheap enough (sub-millisecond per word) to run on
        every word in even a large document without needing any
        shortcuts.
        """
        from language_detect import WordLanguageVote, LanguageContext

        findings = []
        local_context = LanguageContext()  # fresh tally for this scan, independent of any live-typing context
        i = 0
        n = len(document_text)
        while i < n:
            if document_text[i].isspace():
                i += 1
                continue
            word_start = i
            while i < n and not document_text[i].isspace():
                i += 1
            raw_word = document_text[word_start:i]

            # Strip trailing punctuation for the spelling check itself
            # (a period/comma/etc. attached to a word like "wrld." would
            # otherwise make Hunspell check "wrld." as one token, which
            # it correctly calls invalid, but for a different reason
            # than the actual misspelling -- and showing "wrld." in a
            # suggestion bubble with a dangling period looks wrong).
            # Leading punctuation (e.g. an opening quote) is left alone
            # for now -- this mirrors the live-typing checker's existing
            # word-boundary behavior (whitespace-only splitting) closely
            # enough while fixing the specific trailing-punctuation case
            # that affects what gets shown to the user.
            trailing_punct_len = 0
            while (
                trailing_punct_len < len(raw_word)
                and not raw_word[-(trailing_punct_len + 1)].isalnum()
            ):
                trailing_punct_len += 1
            word_end = i - trailing_punct_len
            word = document_text[word_start:word_end]

            if not word:
                continue

            if self._is_ignored(word):
                continue

            vote = self._lang_detector.vote_for_word(word)
            if vote == WordLanguageVote.ENGLISH:
                resolved_lang = WordLanguageVote.ENGLISH
            elif vote == WordLanguageVote.HUNGARIAN:
                resolved_lang = WordLanguageVote.HUNGARIAN
            else:
                resolved_lang = local_context.resolve_ambiguous()
            local_context.record_vote(vote)

            checker = (
                self._hunspell_en if resolved_lang == WordLanguageVote.ENGLISH
                else self._hunspell_hu
            )
            if not checker.is_valid(word):
                findings.append({
                    "start": word_start,
                    "end": word_end,
                    "word_or_phrase": word,
                    "kind": "spelling",
                    "suggestions": [],  # spelling-only pass doesn't fetch suggestions; grammar pass below does for English via LanguageTool
                    "message": "Possible spelling mistake",
                })

            if raw_word and raw_word[-1] in ".!?":
                local_context.reset_for_new_sentence()
        return findings

    def _scan_grammar(self, document_text):
        """
        Slower pass: check each sentence for grammar errors via the
        appropriate backend (English via LanguageTool, Hungarian via
        our engine), routed by majority language vote across that
        sentence's words -- same routing logic as live-typing grammar
        checking, just applied per-sentence across the whole document
        in one pass rather than triggered incrementally.
        """
        from language_detect import WordLanguageVote

        findings = []
        sentences = split_into_sentences(document_text)
        log.info("Document scan: %d sentences to grammar-check.", len(sentences))

        for sentence_text, sentence_start in sentences:
            words = sentence_text.split()
            if len(words) < 2:
                continue  # too short to meaningfully grammar-check, same rule as live typing

            en_votes = 0
            hu_votes = 0
            for w in words:
                vote = self._lang_detector.vote_for_word(w)
                if vote == WordLanguageVote.ENGLISH:
                    en_votes += 1
                elif vote == WordLanguageVote.HUNGARIAN:
                    hu_votes += 1

            backend = self._grammar_hu if hu_votes > en_votes else self._grammar_en
            errors = backend.check(sentence_text)

            for e in errors:
                flagged_text = sentence_text[e["start"]:e["end"]]
                if self._is_ignored(flagged_text):
                    continue
                findings.append({
                    "start": sentence_start + e["start"],
                    "end": sentence_start + e["end"],
                    "word_or_phrase": flagged_text,
                    "kind": "grammar",
                    "suggestions": e["suggestions"],
                    "message": e["message"],
                })
        return findings
