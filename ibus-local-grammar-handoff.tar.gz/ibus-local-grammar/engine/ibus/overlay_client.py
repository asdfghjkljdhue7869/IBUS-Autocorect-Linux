# -*- encoding: UTF-8 -*-
"""
overlay_client.py

Tiny client the IBus engine uses to send show/hide commands to the
separate overlay.py process over its Unix socket. Fails silently if
the overlay isn't running -- the underline is a visual nice-to-have,
never something that should crash or block the engine.
"""

import json
import socket
import logging

log = logging.getLogger("ibus-local-grammar")

DEFAULT_SOCKET_PATH_CLIENT = "~/.local/share/ibus-local-grammar/overlay.sock"


class OverlayClient:
    def __init__(self, socket_path=None):
        import os
        self._socket_path = socket_path or os.path.expanduser(
            DEFAULT_SOCKET_PATH_CLIENT
        )
        self._warned_unreachable = False

    def _send(self, msg):
        try:
            with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as s:
                s.settimeout(0.5)
                s.connect(self._socket_path)
                s.sendall((json.dumps(msg) + "\n").encode("utf-8"))
            self._warned_unreachable = False
        except OSError as e:
            if not self._warned_unreachable:
                log.warning(
                    "Cannot reach overlay process at %s (%s). Underline "
                    "display disabled until it's running. (Logged once.)",
                    self._socket_path, e,
                )
                self._warned_unreachable = True

    def show(self, x, y, width, height, color_hex):
        self._send({
            "action": "show", "x": x, "y": y,
            "width": width, "height": height, "color": color_hex,
        })

    def hide(self):
        self._send({"action": "hide"})
