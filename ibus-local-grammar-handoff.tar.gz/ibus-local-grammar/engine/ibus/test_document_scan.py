# -*- encoding: UTF-8 -*-
"""
test_document_scan.py

Automated tests for document_scan.py, using REAL backends (Hunspell for
both languages, our real Hungarian grammar engine) since this module's
value is entirely about correctly finding real errors in real text. The
English grammar backend is pointed at an unreachable address
deliberately (same pattern as test_grammar_backends.py) -- this module
doesn't need a live LanguageTool server to be correctly tested, since
we're testing OUR scanning/routing/offset logic, and the English
backend's own correctness was already verified separately.

Run directly: python3 test_document_scan.py
"""

import sys
import os
import importlib.util

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(SCRIPT_DIR, "..", "hungarian"))
sys.path.insert(0, SCRIPT_DIR)

from hunspell_morph import HunspellMorphAnalyzer
from language_detect import LanguageDetector
from grammar_backends import HungarianGrammarBackend, EnglishGrammarBackend
import document_scan


class FakeIgnoreList:
    """Minimal stand-in for ignore_list.py's interface, used to test
    that DocumentScanner correctly consults it, before that module
    exists for real."""
    def __init__(self, ignored_words):
        self._ignored = set(w.lower() for w in ignored_words)

    def is_ignored(self, word):
        return word.lower() in self._ignored


def make_scanner(ignore_list=None):
    en = HunspellMorphAnalyzer(dictionary="en_GB")
    hu = HunspellMorphAnalyzer(dictionary="hu_HU")
    detector = LanguageDetector(en, hu)
    grammar_hu = HungarianGrammarBackend()
    grammar_en = EnglishGrammarBackend(base_url="http://localhost:1")  # unreachable on purpose
    scanner = document_scan.DocumentScanner(
        en, hu, detector, grammar_en, grammar_hu, ignore_list=ignore_list
    )
    return scanner, en, hu, grammar_hu


def test_sentence_splitting():
    doc = "First sentence. Second sentence! Third one? Trailing without punctuation"
    sentences = document_scan.split_into_sentences(doc)
    expected = [
        ("First sentence.", 0),
        ("Second sentence!", 16),
        ("Third one?", 33),
        ("Trailing without punctuation", 44),
    ]
    ok = sentences == expected
    print(f"[{'PASS' if ok else 'FAIL'}] sentence splitting on a realistic "
          f"multi-sentence, multi-punctuation document")
    if not ok:
        print(f"       expected: {expected}")
        print(f"       actual:   {sentences}")
    return ok


def test_finds_real_spelling_errors_with_correct_offsets():
    scanner, en, hu, grammar_hu = make_scanner()
    doc = "This is a tset document with a wrld of misspeligns."
    findings = scanner.scan(doc)

    spelling_findings = [f for f in findings if f["kind"] == "spelling"]
    words_found = {f["word_or_phrase"] for f in spelling_findings}
    expected_words = {"tset", "wrld", "misspeligns"}

    # Verify offsets are actually correct by slicing the original text.
    offsets_correct = all(
        doc[f["start"]:f["end"]] == f["word_or_phrase"] for f in spelling_findings
    )

    ok = words_found == expected_words and offsets_correct
    print(f"[{'PASS' if ok else 'FAIL'}] finds real misspellings with "
          f"correct character offsets, trailing punctuation excluded")
    if not ok:
        print(f"       words_found={words_found} expected={expected_words}")
        print(f"       offsets_correct={offsets_correct}")
        print(f"       findings={findings}")
    en.close()
    hu.close()
    grammar_hu.close()
    return ok


def test_finds_hungarian_grammar_error_with_document_offset():
    scanner, en, hu, grammar_hu = make_scanner()
    doc = "It also has som Hungarian: Tudtam hogy ez fog történni."
    findings = scanner.scan(doc)

    grammar_findings = [f for f in findings if f["kind"] == "grammar"]
    found_comma_issue = any(
        "Tudtam hogy" in f["word_or_phrase"] for f in grammar_findings
    )
    # Verify the offset actually points at the right place in the FULL
    # document text, not just the sentence-local offset.
    offset_correct = any(
        doc[f["start"]:f["end"]] == "Tudtam hogy" for f in grammar_findings
    )

    ok = found_comma_issue and offset_correct
    print(f"[{'PASS' if ok else 'FAIL'}] finds Hungarian grammar error "
          f"with offset correctly adjusted into full-document coordinates")
    if not ok:
        print(f"       findings={grammar_findings}")
    en.close()
    hu.close()
    grammar_hu.close()
    return ok


def test_clean_sentence_produces_no_findings():
    scanner, en, hu, grammar_hu = make_scanner()
    doc = "And a clean sentence that should have no errors at all."
    findings = scanner.scan(doc)
    ok = len(findings) == 0
    print(f"[{'PASS' if ok else 'FAIL'}] a genuinely clean sentence "
          f"produces zero findings")
    if not ok:
        print(f"       findings={findings}")
    en.close()
    hu.close()
    grammar_hu.close()
    return ok


def test_ignore_list_filters_spelling_findings():
    ignore_list = FakeIgnoreList(["wrld"])
    scanner, en, hu, grammar_hu = make_scanner(ignore_list=ignore_list)
    doc = "This is a tset document with a wrld of misspeligns."
    findings = scanner.scan(doc)

    words_found = {f["word_or_phrase"] for f in findings if f["kind"] == "spelling"}
    ok = "wrld" not in words_found and "tset" in words_found
    print(f"[{'PASS' if ok else 'FAIL'}] ignore-list correctly filters "
          f"out an ignored word while still flagging others")
    if not ok:
        print(f"       words_found={words_found}")
    en.close()
    hu.close()
    grammar_hu.close()
    return ok


def test_findings_sorted_by_position():
    scanner, en, hu, grammar_hu = make_scanner()
    doc = "This is a tset document with a wrld of misspeligns."
    findings = scanner.scan(doc)
    starts = [f["start"] for f in findings]
    ok = starts == sorted(starts)
    print(f"[{'PASS' if ok else 'FAIL'}] findings are sorted by position "
          f"in the document")
    if not ok:
        print(f"       starts={starts}")
    en.close()
    hu.close()
    grammar_hu.close()
    return ok


def main():
    results = [
        test_sentence_splitting(),
        test_finds_real_spelling_errors_with_correct_offsets(),
        test_finds_hungarian_grammar_error_with_document_offset(),
        test_clean_sentence_produces_no_findings(),
        test_ignore_list_filters_spelling_findings(),
        test_findings_sorted_by_position(),
    ]
    passed = sum(results)
    failed = len(results) - passed
    print(f"\n== Summary: {passed} passed, {failed} failed out of {len(results)} ==")
    if failed > 0:
        sys.exit(1)


if __name__ == "__main__":
    main()
