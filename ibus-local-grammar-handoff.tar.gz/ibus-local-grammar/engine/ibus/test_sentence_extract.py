# -*- encoding: UTF-8 -*-
"""
test_sentence_extract.py

Automated tests for sentence_extract.py. Pure string logic, no IBus or
external dependency at all -- fully testable in isolation.

Run directly: python3 test_sentence_extract.py
"""

import sys
import importlib.util
import os

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
spec = importlib.util.spec_from_file_location(
    "sentence_extract", os.path.join(SCRIPT_DIR, "sentence_extract.py")
)
sentence_extract = importlib.util.module_from_spec(spec)
spec.loader.exec_module(sentence_extract)


# (description, text, cursor_pos, expected_sentence, expected_start)
TEST_CASES = [
    (
        "Single sentence, no punctuation yet, cursor at end",
        "Hello world", 11, "Hello world", 0,
    ),
    (
        "Two sentences, cursor in the second",
        "Hi. How are you", 15, "How are you", 4,
    ),
    (
        "Cursor right after a sentence-ender + space, nothing typed yet",
        "Hi. ", 4, "", 4,
    ),
    (
        "Cursor right after a sentence-ender, no space yet",
        "Hi.", 3, "", 3,
    ),
    (
        "Three sentences, cursor in the third",
        "One. Two. Three", 15, "Three", 10,
    ),
    (
        "Question mark as sentence-ender",
        "Are you ok? Yes", 15, "Yes", 12,
    ),
    (
        "Exclamation mark as sentence-ender",
        "Watch out! Run", 14, "Run", 11,
    ),
    (
        "Cursor in the middle of the FIRST sentence (not at the end of "
        "all text) -- should still extract correctly up to cursor",
        "Hello world. Goodbye", 5, "Hello", 0,
    ),
    (
        "Empty text entirely",
        "", 0, "", 0,
    ),
    (
        "Multiple spaces after sentence-ender",
        "Hi.   World", 11, "World", 6,
    ),
]

WORD_COUNT_CASES = [
    ("", 0),
    ("hello", 1),
    ("hello world", 2),
    ("  hello   world  ", 2),
    ("one two three four", 4),
]


def main():
    passed = 0
    failed = 0

    print("== extract_current_sentence tests ==")
    for description, text, cursor_pos, expected_sentence, expected_start in TEST_CASES:
        sentence, start = sentence_extract.extract_current_sentence(text, cursor_pos)
        ok = (sentence == expected_sentence) and (start == expected_start)
        status = "PASS" if ok else "FAIL"
        if ok:
            passed += 1
        else:
            failed += 1
        print(f"[{status}] {description}")
        if not ok:
            print(f"       text={text!r} cursor={cursor_pos}")
            print(f"       expected: sentence={expected_sentence!r} start={expected_start}")
            print(f"       actual:   sentence={sentence!r} start={start}")

    print("\n== count_words tests ==")
    for text, expected_count in WORD_COUNT_CASES:
        actual = sentence_extract.count_words(text)
        ok = actual == expected_count
        status = "PASS" if ok else "FAIL"
        if ok:
            passed += 1
        else:
            failed += 1
        print(f"[{status}] count_words({text!r}) -> expected {expected_count}, got {actual}")

    print(f"\n== Summary: {passed} passed, {failed} failed out of {passed + failed} ==")
    if failed > 0:
        sys.exit(1)


if __name__ == "__main__":
    main()
