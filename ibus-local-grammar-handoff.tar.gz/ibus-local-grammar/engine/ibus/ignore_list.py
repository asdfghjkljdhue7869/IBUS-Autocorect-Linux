# -*- encoding: UTF-8 -*-
"""
ignore_list.py

A simple, toggleable personal list of words the user has dismissed
("don't flag this for me"). This is intentionally minimal per the
user's explicit scope decision: no document-position memory, no
per-document tracking -- just "this specific word, anywhere, stop
flagging it" (or stop entirely if the whole feature is toggled off).

Storage: a plain text file, one word per line, lowercased. Deliberately
the simplest possible format -- easy to inspect/edit by hand if needed,
no JSON/database overhead for what's fundamentally a small set of
strings. Default location follows the same pattern as the engine's own
log file (~/.local/share/ibus-local-grammar/).

The toggle (enabled/disabled) is a separate, simple boolean, NOT stored
in the same file as the words themselves -- this means turning the
feature off doesn't require touching or losing the word list, and
turning it back on restores exactly what was there before.
"""

import os
import logging

log = logging.getLogger("ibus-local-grammar")

DEFAULT_IGNORE_LIST_PATH = os.path.expanduser(
    "~/.local/share/ibus-local-grammar/ignore_list.txt"
)


class IgnoreList:
    """
    Tracks a set of dismissed words, with an enabled/disabled toggle.
    When disabled, is_ignored() always returns False regardless of
    what's in the list -- this lets the user turn the whole feature
    off without losing their accumulated list.
    """

    def __init__(self, path=None, enabled=True):
        self._path = path or DEFAULT_IGNORE_LIST_PATH
        self._enabled = enabled
        self._words = set()
        self._load()

    def _load(self):
        if not os.path.exists(self._path):
            self._words = set()
            return
        try:
            with open(self._path, "r", encoding="utf-8") as f:
                self._words = {
                    line.strip().lower() for line in f if line.strip()
                }
            log.info(
                "Loaded %d words from ignore list at %s.",
                len(self._words), self._path,
            )
        except OSError:
            log.exception(
                "Failed to read ignore list at %s. Starting with an "
                "empty list rather than crashing.",
                self._path,
            )
            self._words = set()

    def _save(self):
        try:
            os.makedirs(os.path.dirname(self._path), exist_ok=True)
            with open(self._path, "w", encoding="utf-8") as f:
                for word in sorted(self._words):
                    f.write(word + "\n")
        except OSError:
            log.exception(
                "Failed to write ignore list to %s. The word was added "
                "in memory for this session but won't persist.",
                self._path,
            )

    def is_ignored(self, word):
        """
        The interface DocumentScanner (and, later, the live engine)
        consults. Returns False unconditionally when the feature is
        disabled, regardless of list contents.
        """
        if not self._enabled:
            return False
        return word.lower() in self._words

    def add(self, word):
        """Dismiss a word -- add it to the ignore list and persist."""
        normalized = word.lower()
        if normalized in self._words:
            return  # already there, nothing to do
        self._words.add(normalized)
        self._save()
        log.info("Added %r to ignore list.", word)

    def remove(self, word):
        """Un-dismiss a word, in case the user changes their mind."""
        normalized = word.lower()
        if normalized not in self._words:
            return
        self._words.discard(normalized)
        self._save()
        log.info("Removed %r from ignore list.", word)

    def clear(self):
        """Remove everything -- a full reset."""
        self._words = set()
        self._save()
        log.info("Ignore list cleared.")

    def set_enabled(self, enabled):
        """
        Toggle the whole feature on/off WITHOUT touching the underlying
        word list -- turning it back on restores exactly what was
        there before.
        """
        self._enabled = enabled
        log.info("Ignore list feature %s.", "enabled" if enabled else "disabled")

    def is_enabled(self):
        return self._enabled

    def all_words(self):
        """Returns a sorted list of all currently-ignored words, for
        display in some future settings UI."""
        return sorted(self._words)

    def count(self):
        return len(self._words)
