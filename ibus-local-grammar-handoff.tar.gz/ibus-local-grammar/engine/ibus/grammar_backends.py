# -*- encoding: UTF-8 -*-
"""
grammar_backends.py

Two grammar-checking backends behind a common interface:
  - HungarianGrammarBackend: wraps our own lightproof_engine.py
    (Phase 1B), runs fully in-process, no network/server needed.
  - EnglishGrammarBackend: calls a local LanguageTool HTTP server
    (Phase 1), needs that server running separately.

Common interface: check(sentence) -> list of dicts, each with at least
  "start", "end" (character offsets within the sentence), "message",
  and "suggestions" (list of strings). This lets engine.py call either
  backend the same way without caring which language it's dealing with.

IMPORTANT, stated honestly: the EnglishGrammarBackend's actual HTTP
round-trip to a real LanguageTool server CANNOT be verified in the
build sandbox -- the sandbox's network allowlist doesn't include
languagetool.org (confirmed back in Phase 1), and the LanguageTool jar
itself isn't persisted between sessions. This class is built and unit-
tested with the HTTP call mocked out; the actual live-server behavior
needs to be confirmed on the user's machine, where a working
LanguageTool server from Phase 1 testing should still be available.
"""

import logging
import sys
import os
import json
import urllib.request
import urllib.parse
import urllib.error

log = logging.getLogger("ibus-local-grammar")

sys.path.insert(
    0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "hungarian")
)


class HungarianGrammarBackend:
    """
    Wraps lightproof_engine.HungarianGrammarChecker (built and verified
    in Phase 1B -- see docs/DEVELOPMENT_LOG.md entries 3-6). Fully
    in-process, no server/network involved, so this is real-machine-
    testable as well as sandbox-testable -- no asymmetry here.
    """

    def __init__(self):
        from lightproof_engine import HungarianGrammarChecker
        self._checker = HungarianGrammarChecker()
        log.info("Hungarian grammar backend (lightproof_engine) loaded.")

    def check(self, sentence):
        if not sentence.strip():
            return []
        raw_errors = self._checker.check(sentence)
        return [
            {
                "start": e["start"],
                "end": e["end"],
                "message": e["message"],
                "suggestions": e["suggestions"],
            }
            for e in raw_errors
        ]

    def close(self):
        self._checker.close()


class EnglishGrammarBackend:
    """
    Calls a local LanguageTool HTTP server (see Phase 1 in
    DEVELOPMENT_LOG.md -- the server itself is set up and run
    separately via scripts/setup_languagetool.sh and
    scripts/test_languagetool.sh, NOT started by this class).

    This class does NOT start or manage the LanguageTool server
    process -- it only makes HTTP calls to whatever's already running
    on the configured port. If nothing is listening there, check()
    logs a clear warning and returns an empty list (fails safe -- no
    grammar checking for English rather than crashing the engine).
    """

    def __init__(self, base_url="http://localhost:8081", language="en-GB", timeout_seconds=5):
        self._base_url = base_url
        self._language = language
        self._timeout = timeout_seconds
        self._warned_unreachable = False

    def check(self, sentence):
        if not sentence.strip():
            return []

        url = f"{self._base_url}/v2/check"
        data = urllib.parse.urlencode({
            "language": self._language,
            "text": sentence,
        }).encode("utf-8")

        try:
            request = urllib.request.Request(url, data=data, method="POST")
            with urllib.request.urlopen(request, timeout=self._timeout) as response:
                body = response.read().decode("utf-8")
        except (urllib.error.URLError, OSError) as e:
            if not self._warned_unreachable:
                log.warning(
                    "Cannot reach LanguageTool server at %s (%s). English "
                    "grammar checking disabled until it's reachable. "
                    "(This warning is logged only once, not on every call, "
                    "to avoid log spam while typing.) See "
                    "scripts/setup_languagetool.sh / test_languagetool.sh "
                    "to start the server.",
                    self._base_url, e,
                )
                self._warned_unreachable = True
            return []

        self._warned_unreachable = False

        try:
            parsed = json.loads(body)
        except json.JSONDecodeError:
            log.error("LanguageTool returned non-JSON response: %r", body[:200])
            return []

        results = []
        for match in parsed.get("matches", []):
            results.append({
                "start": match["offset"],
                "end": match["offset"] + match["length"],
                "message": match.get("shortMessage") or match.get("message", ""),
                "suggestions": [
                    r["value"] for r in match.get("replacements", [])
                ],
            })
        return results

    def close(self):
        pass
