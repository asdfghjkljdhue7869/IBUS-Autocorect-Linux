# -*- encoding: UTF-8 -*-
"""
test_ignore_list.py

Automated tests for ignore_list.py: persistence to disk, case
insensitivity, the enabled/disabled toggle (and that toggling off
doesn't lose the underlying word list), add/remove/clear.

Uses a temp file path for each test so tests don't interfere with each
other or with any real ignore list the user might have.

Run directly: python3 test_ignore_list.py
"""

import sys
import os
import tempfile
import importlib.util

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
spec = importlib.util.spec_from_file_location(
    "ignore_list", os.path.join(SCRIPT_DIR, "ignore_list.py")
)
ignore_list_module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ignore_list_module)


def fresh_path():
    fd, path = tempfile.mkstemp(suffix=".txt")
    os.close(fd)
    os.remove(path)  # we want it to NOT exist yet, mkstemp creates it
    return path


def test_fresh_list_ignores_nothing():
    path = fresh_path()
    il = ignore_list_module.IgnoreList(path=path)
    ok = il.is_ignored("anything") is False and il.count() == 0
    print(f"[{'PASS' if ok else 'FAIL'}] a fresh list with no file on disk "
          f"ignores nothing and has count 0")
    return ok


def test_add_and_check():
    path = fresh_path()
    il = ignore_list_module.IgnoreList(path=path)
    il.add("wrld")
    ok = il.is_ignored("wrld") is True and il.count() == 1
    print(f"[{'PASS' if ok else 'FAIL'}] adding a word makes it ignored")
    os.remove(path)
    return ok


def test_case_insensitive():
    path = fresh_path()
    il = ignore_list_module.IgnoreList(path=path)
    il.add("WrLd")
    ok = il.is_ignored("wrld") and il.is_ignored("WRLD") and il.is_ignored("Wrld")
    print(f"[{'PASS' if ok else 'FAIL'}] matching is case-insensitive in "
          f"both directions (add mixed case, check various cases)")
    os.remove(path)
    return ok


def test_persists_across_reload():
    path = fresh_path()
    il1 = ignore_list_module.IgnoreList(path=path)
    il1.add("wrld")
    il1.add("teh")

    # Fresh instance, simulating an engine restart reading the same file.
    il2 = ignore_list_module.IgnoreList(path=path)
    ok = il2.is_ignored("wrld") and il2.is_ignored("teh") and il2.count() == 2
    print(f"[{'PASS' if ok else 'FAIL'}] words persist across a simulated "
          f"restart (reload from the same file path)")
    os.remove(path)
    return ok


def test_disabling_hides_list_without_losing_it():
    path = fresh_path()
    il = ignore_list_module.IgnoreList(path=path)
    il.add("wrld")

    il.set_enabled(False)
    disabled_check = il.is_ignored("wrld")  # should be False even though "wrld" IS in the list

    il.set_enabled(True)
    reenabled_check = il.is_ignored("wrld")  # should be True again

    ok = (disabled_check is False) and (reenabled_check is True) and il.count() == 1
    print(f"[{'PASS' if ok else 'FAIL'}] disabling hides the list "
          f"(is_ignored returns False) without deleting it; re-enabling "
          f"restores it exactly")
    if not ok:
        print(f"       disabled_check={disabled_check} reenabled_check={reenabled_check} count={il.count()}")
    os.remove(path)
    return ok


def test_remove():
    path = fresh_path()
    il = ignore_list_module.IgnoreList(path=path)
    il.add("wrld")
    il.add("teh")
    il.remove("teh")
    ok = il.is_ignored("wrld") and not il.is_ignored("teh") and il.count() == 1
    print(f"[{'PASS' if ok else 'FAIL'}] removing a word un-ignores it "
          f"without affecting other words")
    os.remove(path)
    return ok


def test_remove_nonexistent_is_safe():
    path = fresh_path()
    il = ignore_list_module.IgnoreList(path=path)
    il.add("wrld")
    il.remove("never-was-there")  # should not raise, should not affect anything
    ok = il.is_ignored("wrld") and il.count() == 1
    print(f"[{'PASS' if ok else 'FAIL'}] removing a word that was never "
          f"in the list is a safe no-op")
    os.remove(path)
    return ok


def test_clear():
    path = fresh_path()
    il = ignore_list_module.IgnoreList(path=path)
    il.add("wrld")
    il.add("teh")
    il.clear()
    ok = il.count() == 0 and not il.is_ignored("wrld") and not il.is_ignored("teh")
    print(f"[{'PASS' if ok else 'FAIL'}] clear() empties the entire list")
    os.remove(path)
    return ok


def test_all_words_sorted():
    path = fresh_path()
    il = ignore_list_module.IgnoreList(path=path)
    il.add("zebra")
    il.add("apple")
    il.add("mango")
    ok = il.all_words() == ["apple", "mango", "zebra"]
    print(f"[{'PASS' if ok else 'FAIL'}] all_words() returns a sorted list")
    if not ok:
        print(f"       got: {il.all_words()}")
    os.remove(path)
    return ok


def test_file_format_is_plain_text_one_per_line():
    path = fresh_path()
    il = ignore_list_module.IgnoreList(path=path)
    il.add("wrld")
    il.add("teh")
    with open(path, "r", encoding="utf-8") as f:
        lines = [l.strip() for l in f if l.strip()]
    ok = set(lines) == {"wrld", "teh"}
    print(f"[{'PASS' if ok else 'FAIL'}] on-disk format is plain text, "
          f"one word per line (human-inspectable/editable)")
    if not ok:
        print(f"       file contents: {lines}")
    os.remove(path)
    return ok


def main():
    results = [
        test_fresh_list_ignores_nothing(),
        test_add_and_check(),
        test_case_insensitive(),
        test_persists_across_reload(),
        test_disabling_hides_list_without_losing_it(),
        test_remove(),
        test_remove_nonexistent_is_safe(),
        test_clear(),
        test_all_words_sorted(),
        test_file_format_is_plain_text_one_per_line(),
    ]
    passed = sum(results)
    failed = len(results) - passed
    print(f"\n== Summary: {passed} passed, {failed} failed out of {len(results)} ==")
    if failed > 0:
        sys.exit(1)


if __name__ == "__main__":
    main()
