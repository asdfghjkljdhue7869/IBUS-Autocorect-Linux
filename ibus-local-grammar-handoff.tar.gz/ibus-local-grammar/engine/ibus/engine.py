# -*- encoding: UTF-8 -*-
"""
engine.py

The actual IBus engine for this project. Design (confirmed with the user
before writing this):

  - Every keystroke passes through to the application UNTOUCHED. We
    never intercept, transform, or re-commit typed text ourselves. This
    is fundamentally different from transliteration-style IME engines
    (e.g. Vietnamese/Chinese input engines) which build characters from
    raw keystrokes -- we are NOT doing that. We're closer in spirit to
    a passive observer + annotator, like Typing Booster's underlining
    behavior, not its candidate-selection behavior.

  - We read back what's already been typed using IBus's surrounding-text
    feature (do_set_surrounding_text / get_surrounding_text), check it
    against our spelling/grammar engines, and show errors as pre-edit
    attributes (underline + color) overlaid on a zero-width preedit at
    the cursor position, OR by using IBus's preedit attribute mechanism
    on text we are tracking. (Exact rendering approach is being proven
    out incrementally -- see notes in do_set_surrounding_text below.)

  - KNOWN, DOCUMENTED RISK (confirmed via real bug reports, not just
    theory -- see docs/DEVELOPMENT_LOG.md): surrounding-text support is
    inconsistent across applications. Chrome/Chromium-based browsers
    (which includes Brave) have multiple long-standing, repeated bug
    reports of NOT supporting this feature at all ("has no capability
    of surrounding-text feature"). Terminals and Qt4 apps don't support
    it either. The user has explicitly chosen to proceed and debug
    per-app issues as they appear, rather than pre-testing each app
    first. This file logs clearly when surrounding-text capability
    looks absent, so that when something doesn't work, there's a
    specific, visible reason rather than silent failure.

Run standalone for manual testing via:
    python3 engine.py
This starts the engine connected to a running ibus-daemon. It does NOT
register itself as a system component (no .xml file involved here) --
for that, a separate component registration step is needed, covered in
the project's installation docs. Standalone mode is for fast iteration
without reinstalling a component every time.
"""

import sys
import os
import logging

import gi
gi.require_version("IBus", "1.0")
from gi.repository import IBus
from gi.repository import GLib

# Make the Hungarian engine importable regardless of where this script
# is invoked from.
sys.path.insert(
    0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "hungarian")
)

LOG_FILE_PATH = os.path.expanduser("~/.local/share/ibus-local-grammar/engine.log")
os.makedirs(os.path.dirname(LOG_FILE_PATH), exist_ok=True)

logging.basicConfig(
    level=logging.DEBUG,
    format="%(asctime)s %(levelname)s %(message)s",
    handlers=[
        logging.StreamHandler(sys.stderr),
        logging.FileHandler(LOG_FILE_PATH),
    ],
)
log = logging.getLogger("ibus-local-grammar")
log.info("Logging to stderr AND to file: %s", LOG_FILE_PATH)


# Color used for the misspelling underline in this proof-of-concept stage.
# Hardcoded for now -- Plasma accent color theming is a later, separate
# phase (see docs/DEVELOPMENT_LOG.md build phase list). Using a clearly
# visible red so it's unambiguous during testing whether rendering works
# at all, independent of whether the *color* is right.
UNDERLINE_COLOR_RGB = 0xE51C23  # plain red
UNDERLINE_COLOR_HEX = "#e51c23"  # same color, hex-string form for overlay_client

# How long to wait, after the LAST relevant event, before actually
# evaluating a reopen-check. Chosen as a short, barely-perceptible delay
# -- long enough to absorb rapid key-repeat/arrow-spamming into a single
# evaluation, short enough that it doesn't feel laggy to a human pressing
# arrow keys at normal speed. Not yet tuned against real usage feel on
# the target machine -- a reasonable starting point, adjustable later.
REOPEN_DEBOUNCE_MS = 40

# Grammar checks (LanguageTool / our Hungarian engine) are much more
# expensive than spelling checks -- LanguageTool measured ~89ms per
# call even warmed-up (see Phase 1 in DEVELOPMENT_LOG.md), versus our
# spelling checks at well under 1ms. Debouncing this is essential: we
# don't want a grammar check firing after every single word while
# someone is typing a long sentence quickly. Instead, schedule a check
# this long after the LAST word-boundary completion -- if another word
# finishes before this elapses, the earlier scheduled check is
# cancelled and a new one scheduled, so only the FIRST pause in typing
# (of at least this length) triggers an actual check. Not yet tuned
# against real typing-speed feel on the target machine.
GRAMMAR_CHECK_DEBOUNCE_MS = 700

# NOTE: the cursor-reopen mechanism (re-checking a word when the cursor
# moves back into it) and its associated rendering test/debounce
# constants have been REMOVED -- see git history and
# docs/DEVELOPMENT_LOG.md Entries 11-16 for the full story. That
# mechanism was deliberately retired in favor of the Grammarly-style
# "finish a sentence, see underlines, click to fix" experience, which
# doesn't need live cursor tracking at all.


class LocalGrammarEngine(IBus.Engine):
    __gtype_name__ = "LocalGrammarEngine"

    def __init__(self):
        super(LocalGrammarEngine, self).__init__()
        self._caps = 0
        self._surrounding_text = ""
        self._surrounding_cursor_pos = 0
        # Last known on-screen pixel rectangle of the text cursor, kept
        # updated via do_set_cursor_location (IBus calls this whenever
        # the cursor moves on screen). Used to estimate where a just-
        # flagged word sits on screen, for the custom underline overlay
        # -- see overlay_client.py / engine/overlay/overlay.py.
        self._last_cursor_rect = None  # (x, y, w, h) or None if never received
        from overlay_client import OverlayClient
        self._overlay_client = OverlayClient()
        # Maps debounce timer_name -> GLib source id, for
        # _schedule_debounced. See that method for how this is used.
        self._debounce_timers = {}
        # Both dictionaries + the language detector/context tracker are
        # lazily initialized together -- see _ensure_checkers(). False
        # (not None) is used as the "tried and failed" sentinel for each,
        # matching the existing pattern, so a failure in one doesn't
        # cause repeated retries every keystroke.
        self._hunspell_en = None
        self._hunspell_hu = None
        self._lang_detector = None
        self._lang_context = None
        self._grammar_hu = None
        self._grammar_en = None
        # Suggestion-popup state. False (not None) is the "tried and
        # failed" sentinel for the suggesters, same pattern as the
        # other checkers above. _active_suggestion_* track which word/
        # span the currently-shown popup (if any) refers to, consulted
        # by do_candidate_clicked when the user picks a suggestion.
        # There is only ever ONE active suggestion popup at a time --
        # showing a new one implicitly replaces tracking for any
        # previous one (the previous popup gets hidden by IBus itself
        # when a new lookup table is shown, so no explicit guard against
        # concurrent popups is needed the way the reopen mechanism
        # needed one -- popups don't have a multi-step async lifecycle
        # the way that delete/redraw/delay/recommit sequence did).
        self._hunspell_suggest_en = None
        self._hunspell_suggest_hu = None
        self._active_suggestion_word = None
        self._active_suggestion_start = None
        self._active_suggestion_end = None
        self._active_suggestion_list = []
        log.info("Engine instance created.")

    # ------------------------------------------------------------------
    # Lazy setup of the spelling backend. Kept lazy and defensive so that
    # if Hunspell/the Hungarian module fails to load for any reason, the
    # engine itself doesn't crash IBus -- it just logs and runs with
    # checking disabled, which is a much easier failure mode to diagnose
    # than ibus-daemon refusing to start the engine at all.
    # ------------------------------------------------------------------
    def _ensure_checkers(self):
        if self._hunspell_en is not None:
            return  # already attempted (success or failure) -- don't retry every call
        try:
            from hunspell_morph import HunspellMorphAnalyzer
            from language_detect import LanguageDetector, LanguageContext

            # Plain Hunspell spelling check (NOT the -m morphological
            # mode used for Hungarian grammar in Phase 1B) for both
            # languages, since spelling-only here just needs is_valid().
            self._hunspell_en = HunspellMorphAnalyzer(dictionary="en_GB")
            log.info("English Hunspell analyzer loaded (en_GB).")

            self._hunspell_hu = HunspellMorphAnalyzer(dictionary="hu_HU")
            log.info("Hungarian Hunspell analyzer loaded (hu_HU).")

            self._lang_detector = LanguageDetector(
                self._hunspell_en, self._hunspell_hu
            )
            self._lang_context = LanguageContext()
            log.info("Language detector and context tracker initialized.")

            from grammar_backends import HungarianGrammarBackend, EnglishGrammarBackend
            self._grammar_hu = HungarianGrammarBackend()
            self._grammar_en = EnglishGrammarBackend()
            log.info("Grammar backends initialized (Hungarian in-process, "
                      "English via LanguageTool HTTP).")
        except Exception:
            log.exception(
                "Failed to load checkers. Spelling/grammar checks disabled."
            )
            self._hunspell_en = False  # sentinel: tried and failed
            self._hunspell_hu = False
            self._lang_detector = False
            self._lang_context = False
            self._grammar_hu = False
            self._grammar_en = False

    # ------------------------------------------------------------------
    # IBus lifecycle callbacks
    # ------------------------------------------------------------------

    def do_enable(self):
        log.info("Engine enabled.")
        # Tell the client we want surrounding-text updates. Per IBus's
        # design, the client may or may not actually honor this -- there
        # is no reliable way to know in advance (see module docstring).
        self.get_surrounding_text()

    def do_disable(self):
        log.info("Engine disabled.")
        self.hide_preedit_text()
        # BUG FIX (found via real-machine testing): the overlay window
        # was never being told to hide ANYWHERE, so it would persist
        # indefinitely after the last word it underlined -- including
        # well past switching apps, going fullscreen, or disabling the
        # engine entirely. This is the most important of several
        # missing hide() calls being added now.
        self._overlay_client.hide()

    def do_focus_in(self):
        log.info("Focus in.")
        self.get_surrounding_text()

    def do_reset(self):
        log.info("Engine reset.")
        self.hide_preedit_text()
        self._overlay_client.hide()

    def do_focus_out(self):
        log.info("Focus out.")
        self.hide_preedit_text()
        self._overlay_client.hide()

    def do_set_capabilities(self, caps):
        self._caps = caps
        has_surrounding = bool(caps & IBus.Capabilite.SURROUNDING_TEXT)
        log.info(
            "Client capabilities set. SURROUNDING_TEXT supported: %s",
            has_surrounding,
        )
        if not has_surrounding:
            log.warning(
                "This client/app does NOT advertise surrounding-text support. "
                "Spelling/grammar checking will likely not work here. This is "
                "a known limitation of certain apps (notably Chrome/Chromium-"
                "based browsers), not a bug in this engine. See "
                "docs/DEVELOPMENT_LOG.md."
            )

    def do_process_key_event(self, keyval, keycode, state):
        """
        Pure pass-through -- every key is forwarded to the application
        untouched. This engine never intercepts typing.

        (Previously this also tracked BackSpace/Delete/Left/Right key
        presses to feed a "reopen" detection mechanism -- see git
        history and docs/DEVELOPMENT_LOG.md Entries 11-16 for that full
        story. That mechanism was deliberately retired: it solved a
        problem -- re-checking a word when the cursor moves back into
        it -- that turned out not to be needed for the actual desired
        product experience, which is a Grammarly-style "finish a
        sentence, see underlines, click to fix" flow, not live cursor
        tracking. Removed entirely rather than left disabled-but-
        present, since the user reported the dormant detection logging
        was confusing to see in the logs, looking like something was
        happening when nothing was.)
        """
        return False

    def do_set_cursor_location(self, x, y, w, h):
        """
        Called by IBus whenever the text cursor's on-screen pixel
        location changes. This is the real, confirmed mechanism that
        makes the custom underline overlay possible at all -- IBus
        gives us absolute screen coordinates for the cursor, which we
        use to estimate where a just-flagged word sits on screen (see
        _show_underline below). Just stores the latest value; no other
        side effects here.
        """
        self._last_cursor_rect = (x, y, w, h)

    def do_set_surrounding_text(self, text, cursor_pos, anchor_pos):
        """
        Called by IBus when the client app reports the text around the
        cursor. This is the core data feed for this whole engine. If
        this method is never called for a given app, that app does not
        support surrounding-text and this engine cannot check spelling
        there -- see module docstring for known affected apps.
        """
        plain_text = text.get_text()
        self._surrounding_text = plain_text
        self._surrounding_cursor_pos = cursor_pos

        log.debug(
            "Surrounding text updated: %r (cursor at %d)",
            plain_text,
            cursor_pos,
        )

        self._check_and_show_errors(plain_text, cursor_pos)

    def _schedule_debounced(self, timer_name, delay_ms, callback, *args):
        """
        Generic debounce helper: cancels any previously scheduled timer
        under the same `timer_name`, then schedules `callback(*args)` to
        run after `delay_ms`. If called again with the same timer_name
        before the delay elapses, the earlier call is cancelled and
        never runs -- only the LAST scheduling within any debounce
        window actually fires.

        Used for both the reopen-check debounce (this increment) and
        will be reused for the grammar-check debounce (next increment)
        -- same underlying need ("wait for things to settle before
        doing expensive work"), so one shared mechanism rather than
        two separate ad-hoc timers.
        """
        existing_id = self._debounce_timers.get(timer_name)
        if existing_id is not None:
            GLib.source_remove(existing_id)

        def _fire():
            self._debounce_timers.pop(timer_name, None)
            callback(*args)
            return False  # GLib.SOURCE_REMOVE -- don't repeat

        self._debounce_timers[timer_name] = GLib.timeout_add(delay_ms, _fire)

    # ------------------------------------------------------------------
    # The actual checking + display logic
    # ------------------------------------------------------------------

    def _check_and_show_errors(self, text, cursor_pos):
        self._ensure_checkers()
        if not self._hunspell_en or not self._hunspell_hu:
            return

        # Find the word currently before the cursor (the word being
        # actively typed or just finished). This is intentionally simple
        # for this proof-of-concept stage -- checking only the most
        # recent word, not the whole surrounding text. Full-sentence
        # grammar checking (LanguageTool / our Hungarian engine) is a
        # later phase; this stage proves the underline rendering
        # mechanism with simple Hunspell spelling checks first.
        # CHECK ONLY ON WORD COMPLETION, not on every keystroke.
        #
        # Feedback from reviewing the logs (credit: user's own
        # observation from a separate conversation about this exact
        # issue): checking on every partial keystroke ("w" -> "wr" ->
        # "wrl" -> "wrld") wastes CPU on work that gets immediately
        # redone, and -- much more importantly for UX -- once rendering
        # comes back online, it would flash a red underline under
        # "prog" while someone is still mid-typing "programming". We
        # only check a word once it's "finished": the character just
        # typed is a word-boundary character (whitespace), not while
        # still composing letters in the middle of the word.
        #
        # NOTE: this means a word only gets checked once you've typed
        # PAST it (the next space) or via the reopen-detection path
        # (Left/Right/BackSpace/Delete landing on it) -- not while
        # actively typing its letters. This intentionally does NOT
        # check the word currently being typed in real time.
        #
        # BUG FOUND AND FIXED while writing automated tests for this:
        # an earlier draft of this function ran the OLD unconditional
        # word-lookup (at the raw cursor position) BEFORE this check,
        # and that old lookup would return empty and bail out early
        # whenever the cursor sat right after a space -- which is
        # exactly the one case this new logic needs to handle. That old
        # call has been removed entirely; this boundary check is now
        # the only word-lookup path in this function.
        if cursor_pos > 0 and text[cursor_pos - 1].isspace():
            # Cursor is right after a space -- the word that just
            # finished is the word immediately before that space.
            word, word_start, word_end = self._get_word_before_cursor(
                text, cursor_pos - 1
            )
            if not word:
                self.hide_preedit_text()
                return
        else:
            # Cursor is in the middle of actively typing a word (no
            # boundary just typed) -- do NOT check yet. This is the key
            # behavior change in this increment: previously we checked
            # here unconditionally, on every keystroke.
            self.hide_preedit_text()
            return

        # Safety guard: a real "word" being actively typed should never
        # be absurdly long. This protects against any future feedback
        # bug silently running away unnoticed (see the runaway
        # "wrldwrldwrld..." bug found during real-machine testing,
        # documented in docs/DEVELOPMENT_LOG.md) -- if this fires, it
        # means something is wrong upstream and we should NOT act on
        # the data, just log and bail out.
        if len(word) > 60:
            log.error(
                "Word length sanity check failed (%d chars) -- this looks "
                "like a bug, not real typing. Refusing to process. First "
                "60 chars: %r",
                len(word),
                word[:60],
            )
            return

        # Decide which language this word belongs to, using dual-
        # dictionary voting (see language_detect.py for why we don't
        # use a statistical detector here -- tested directly and found
        # unusable on single words).
        from language_detect import WordLanguageVote

        vote = self._lang_detector.vote_for_word(word)

        if vote == WordLanguageVote.ENGLISH:
            resolved_lang = WordLanguageVote.ENGLISH
        elif vote == WordLanguageVote.HUNGARIAN:
            resolved_lang = WordLanguageVote.HUNGARIAN
        else:
            # BOTH (genuine cross-language homograph like "van") or
            # NEITHER (misspelled in both / not a real word) -- fall
            # back to whichever language the rest of the current
            # sentence has mostly been.
            resolved_lang = self._lang_context.resolve_ambiguous()
            log.debug(
                "Word %r was ambiguous (vote=%s), resolved to %s via "
                "sentence context (stats=%s).",
                word, vote, resolved_lang, self._lang_context.stats(),
            )

        # Update the running sentence-context tally with this word's
        # OWN vote (not the resolved language) -- an ambiguous word
        # shouldn't retroactively count as evidence for the language we
        # just guessed it into; only clear, unambiguous votes should
        # shape future tie-breaking. See LanguageContext.record_vote.
        self._lang_context.record_vote(vote)

        checker = self._hunspell_en if resolved_lang == WordLanguageVote.ENGLISH else self._hunspell_hu
        is_correct = checker.is_valid(word)
        log.debug(
            "Checked word %r (lang=%s) -> valid: %s",
            word, resolved_lang, is_correct,
        )

        # If the word that just completed was immediately followed by
        # sentence-ending punctuation, reset the language context tally
        # -- the next sentence shouldn't be biased by what language the
        # previous one was in. This check is independent of whether the
        # word was spelled correctly.
        if word_end < len(text) and text[word_end] in ".!?":
            self._lang_context.reset_for_new_sentence()
            log.debug("Sentence boundary detected, language context reset.")

        if is_correct:
            self.hide_preedit_text()
            self._overlay_client.hide()

        # Schedule a debounced sentence-level GRAMMAR check (separate
        # from the spelling check above, which already happened
        # synchronously). This is intentionally debounced -- see
        # GRAMMAR_CHECK_DEBOUNCE_MS -- so it only actually runs once
        # typing pauses, not after every single word.
        #
        # IMPORTANT: compute a position right after the word's actual
        # letters, BEFORE any trailing punctuation attached to it (we
        # only split on whitespace, not punctuation, so "history." is
        # one "word" including the period -- see known, documented
        # simplification from increment 1). Bug found via testing: using
        # word_end directly still lands AFTER an attached sentence-
        # ending period, which extract_current_sentence then treats as
        # the boundary, returning the (empty) text after it and
        # silently skipping the sentence that just finished. Stripping
        # trailing punctuation here gives a position safely inside the
        # just-completed sentence, regardless of what punctuation
        # follows the last word.
        non_letter_trailing = 0
        while (
            non_letter_trailing < len(word)
            and not word[-(non_letter_trailing + 1)].isalnum()
        ):
            non_letter_trailing += 1
        grammar_check_pos = word_end - non_letter_trailing

        self._schedule_debounced(
            "grammar_check", GRAMMAR_CHECK_DEBOUNCE_MS,
            self._run_grammar_check, text, grammar_check_pos,
        )

        if not is_correct:
            self._show_underline(word, word_start, word_end, cursor_pos)

    def _run_grammar_check(self, text, cursor_pos):
        """
        DETECTION ONLY, same as the spelling-check underline path -- see
        docs/DEVELOPMENT_LOG.md for why rendering is paused pending a
        safe redesign. This only logs what grammar errors WOULD be
        flagged.

        Extracts the current sentence, decides which language backend
        to use based on a majority vote across the sentence's words
        (reusing the same dual-dictionary voting as single-word
        detection, just tallied across more words), and runs the
        appropriate grammar backend.
        """
        from sentence_extract import extract_current_sentence, count_words
        from language_detect import WordLanguageVote

        sentence, sentence_start = extract_current_sentence(text, cursor_pos)

        if count_words(sentence) < 2:
            # Not enough content yet to meaningfully grammar-check --
            # a single word isn't really a sentence. Avoids wasting a
            # LanguageTool/Hungarian-engine call on "Hello" by itself.
            log.debug(
                "[grammar-check] sentence %r too short to check yet.",
                sentence,
            )
            return

        en_votes = 0
        hu_votes = 0
        for w in sentence.split():
            vote = self._lang_detector.vote_for_word(w)
            if vote == WordLanguageVote.ENGLISH:
                en_votes += 1
            elif vote == WordLanguageVote.HUNGARIAN:
                hu_votes += 1

        backend = self._grammar_hu if hu_votes > en_votes else self._grammar_en
        backend_name = "Hungarian" if hu_votes > en_votes else "English"

        log.debug(
            "[grammar-check] checking sentence %r via %s backend "
            "(en_votes=%d, hu_votes=%d)",
            sentence, backend_name, en_votes, hu_votes,
        )

        errors = backend.check(sentence)
        if not errors:
            log.debug("[grammar-check] no errors found.")
            return

        for e in errors:
            log.info(
                "[GRAMMAR DETECTION ONLY, NOT RENDERED] %s backend would "
                "flag %r in sentence %r -> suggestions=%s (%s)",
                backend_name,
                sentence[e["start"]:e["end"]],
                sentence,
                e["suggestions"],
                e["message"],
            )

    @staticmethod
    def _get_word_before_cursor(text, cursor_pos):
        """
        Return (word, start_index, end_index) for the word immediately
        before cursor_pos in `text`, or ("", 0, 0) if there isn't one.
        Simple whitespace-based splitting -- not yet Unicode-word-aware
        in any sophisticated sense, deliberately simple for this stage.
        """
        before_cursor = text[:cursor_pos]
        stripped_len = len(before_cursor) - len(before_cursor.rstrip())
        if stripped_len > 0:
            # cursor is right after whitespace -- no "current word"
            return "", 0, 0

        i = len(before_cursor)
        while i > 0 and not before_cursor[i - 1].isspace():
            i -= 1
        word = before_cursor[i:]
        return word, i, cursor_pos

    def _show_underline_overlay(self, word, cursor_pos):
        """
        Estimates where `word` sits on screen, using the most recent
        cursor rectangle from do_set_cursor_location, and tells the
        separate overlay process (engine/overlay/overlay.py) to draw a
        colored underline there.

        APPROXIMATION, stated honestly: IBus gives us the cursor's own
        pixel rectangle, not per-character positions. We estimate the
        word's horizontal extent using a fixed average-character-width
        guess (CHAR_WIDTH_ESTIMATE_PX), which will not be pixel-perfect
        for variable-width fonts -- this is a deliberate, acknowledged
        approximation good enough for "underline is roughly under the
        right word," not character-perfect alignment. Real-machine
        testing will show how far off this actually is in practice;
        refining it (e.g. using a monospace assumption per real font
        metrics) is a reasonable follow-up once we see real results.
        """
        if self._last_cursor_rect is None:
            log.debug(
                "No cursor location known yet, cannot position underline "
                "for %r.", word,
            )
            return

        cursor_x, cursor_y, cursor_w, cursor_h = self._last_cursor_rect

        # CALIBRATION NOTE: real-machine testing showed the underline
        # rendering at roughly 1/10th the expected width with the
        # original guess of 8px/char -- almost certainly because of
        # display scaling (Plasma/X11 HiDPI scale factors are common
        # and this code has no way to query the real scale factor from
        # here). If the underline still looks wrong, this is the first
        # number to adjust -- multiply/divide it directly based on what
        # you observe, rather than guessing again from the build
        # sandbox, which has no real display to calibrate against.
        CHAR_WIDTH_ESTIMATE_PX = 8  # ADJUST THIS based on real-machine testing
        word_width_px = len(word) * CHAR_WIDTH_ESTIMATE_PX

        # The cursor is currently AFTER the word (plus whatever
        # whitespace followed it, already accounted for by the time
        # this is called -- see _check_and_show_errors's boundary
        # logic). Estimate the word's left edge as word_width_px to the
        # left of the cursor's current position.
        underline_x = cursor_x - word_width_px
        underline_y = cursor_y + cursor_h  # just below the text baseline
        underline_height = 3

        self._overlay_client.show(
            underline_x, underline_y, word_width_px, underline_height,
            UNDERLINE_COLOR_HEX,
        )
        log.info(
            "Told overlay to underline %r at approx (%d, %d, %d, %d).",
            word, underline_x, underline_y, word_width_px, underline_height,
        )

    def _show_underline(self, word, start, end, cursor_pos):
        """
        REAL IMPLEMENTATION (replacing the disabled stub -- see git
        history / docs/DEVELOPMENT_LOG.md Entries 7 and 16-20 for the
        full story of why this took this long and what was tried and
        rejected first).

        This is fundamentally SAFER than the abandoned cursor-reopen
        mechanism (Entries 11-15) for a specific reason: it triggers
        only on sentence-boundary word completion (already the
        existing, proven-safe trigger for spelling checks), not on
        live cursor navigation -- so there's no risk of rapid, repeated,
        overlapping triggers the way arrow-key movement caused. The
        popup is purely informational until the user deliberately
        clicks a suggestion; nothing about showing it modifies the
        document.

        Shows an IBus lookup table (the same native mechanism used by
        real IME engines for candidate selection, confirmed via direct
        API testing and reading ibus-typing-booster's real usage)
        populated with real suggested corrections fetched from
        hunspell_suggest.py. Clicking a suggestion is handled in
        do_candidate_clicked below.
        """
        self._ensure_suggester()
        if not self._hunspell_suggest_en or not self._hunspell_suggest_hu:
            return

        # Re-detect language for the SUGGESTION fetch (mirrors the
        # language resolution already done for the validity check in
        # _check_and_show_errors -- kept separate here since this
        # function doesn't have direct access to that resolution and
        # re-deriving it is cheap and avoids threading an extra
        # parameter through every call site for this one need).
        #
        # BUG FIX (found while writing automated tests for this): a
        # misspelled word, by definition, fails validity in BOTH
        # dictionaries simultaneously, so vote_for_word() on it always
        # returns NEITHER -- it can never itself vote Hungarian. An
        # earlier version of this code only checked for an explicit
        # HUNGARIAN vote and fell through to English for everything
        # else, which meant the suggestion popup would ALWAYS default
        # to English suggestions for any misspelled word, regardless of
        # surrounding Hungarian sentence context. Fixed by consulting
        # _lang_context.resolve_ambiguous() for BOTH/NEITHER votes, the
        # same fallback _check_and_show_errors already correctly uses.
        from language_detect import WordLanguageVote
        vote = self._lang_detector.vote_for_word(word)
        if vote == WordLanguageVote.HUNGARIAN:
            resolved_lang = WordLanguageVote.HUNGARIAN
        elif vote == WordLanguageVote.ENGLISH:
            resolved_lang = WordLanguageVote.ENGLISH
        else:
            # BOTH or NEITHER -- fall back to sentence context, exactly
            # like _check_and_show_errors does. This is the fix: without
            # this fallback, every misspelled word (always NEITHER)
            # would silently default to English suggestions regardless
            # of context.
            resolved_lang = self._lang_context.resolve_ambiguous()

        suggester = (
            self._hunspell_suggest_hu if resolved_lang == WordLanguageVote.HUNGARIAN
            else self._hunspell_suggest_en
        )

        suggestions = suggester.suggest(word)

        # GUARD (Typing Booster's explicit, hard-won lesson, read
        # directly from their source comments): never show an empty
        # lookup table -- some environments display a visible empty
        # popup, which looks broken rather than just doing nothing.
        if not suggestions:
            log.debug(
                "No suggestions found for %r, not showing a popup.", word
            )
            return

        self._show_underline_overlay(word, cursor_pos)

        # Cap at 3 suggestions, matching the user's explicit Android-
        # bubble-style request (2-3 options plus dismiss), rather than
        # showing Hunspell's full suggestion list which can be much
        # longer and would not match the intended compact UX.
        suggestions = suggestions[:3]

        lookup_table = IBus.LookupTable.new(
            len(suggestions),  # page_size -- show all of them on one page, no paging needed for 2-3 items
            0,                  # cursor_pos
            True,               # cursor_visible
            False,              # round
        )
        for s in suggestions:
            lookup_table.append_candidate(IBus.Text.new_from_string(s))

        # Track what this popup is FOR, so do_candidate_clicked knows
        # which word/span to replace when the user picks one. This is
        # the one piece of state this feature needs to track; kept as
        # simple instance attributes rather than a more elaborate
        # structure since there's only ever one active suggestion
        # popup at a time (see _active_suggestion_word guard below).
        self._active_suggestion_word = word
        self._active_suggestion_start = start
        self._active_suggestion_end = end
        self._active_suggestion_list = suggestions

        self.update_lookup_table(lookup_table, True)
        log.info(
            "Showing suggestion popup for %r: %s", word, suggestions,
        )

    def do_candidate_clicked(self, index, button, state):
        """
        Called by IBus when the user clicks a candidate in the lookup
        table. `index` is which suggestion was clicked (0-based, within
        the visible page -- fine since we never page, always <= 3
        items). `button` is the mouse button (1 = left click, per
        ibus-typing-booster's documented convention, confirmed by
        reading their real do_candidate_clicked implementation).

        Replaces the flagged word with the chosen suggestion. This is
        a DELIBERATE USER ACTION (a click), not an automatic trigger on
        cursor movement -- the key safety difference from the abandoned
        cursor-reopen mechanism. There's no risk of this firing
        repeatedly/concurrently the way arrow-key navigation did,
        since it only happens once per actual click.
        """
        if button != 1:
            return  # only handle left-click for now; right-click/other buttons not yet defined

        if self._active_suggestion_word is None:
            log.warning(
                "do_candidate_clicked fired but no active suggestion "
                "is tracked -- ignoring (popup may be stale)."
            )
            return

        if index < 0 or index >= len(self._active_suggestion_list):
            log.warning(
                "do_candidate_clicked index %d out of range for %d "
                "suggestions -- ignoring.",
                index, len(self._active_suggestion_list),
            )
            return

        chosen = self._active_suggestion_list[index]
        word = self._active_suggestion_word

        log.info(
            "User clicked suggestion %r to replace %r.",
            chosen, word,
        )

        try:
            # REAL BUG, FOUND VIA REAL-MACHINE TESTING: the original
            # version of this code computed the delete offset using
            # the word's start/end position (or a cursor snapshot) from
            # back when the popup was first SHOWN, then used that
            # stale number at CLICK time. But delete_surrounding_text's
            # offset is relative to the LIVE cursor position at the
            # moment it's actually called -- and real clicks happen
            # seconds after the popup appears, during which the user
            # keeps typing and the live cursor moves on. Real testing
            # showed every single click landing in the wrong place as
            # a result (e.g. "teh" -> "the" produced "I luv  the"
            # instead of "I luv the"; another case prepended the
            # replacement to the very START of the whole text).
            #
            # FIX: at click time, search the CURRENT live surrounding
            # text for the flagged word, find it fresh, and compute the
            # delete offset relative to where it ACTUALLY is right now
            # -- not where it was when the popup first appeared. If the
            # word can no longer be found nearby (e.g. the user already
            # deleted or changed it themselves), we safely do nothing
            # rather than guess and risk corrupting something else.
            live_text = self._surrounding_text
            live_cursor = self._surrounding_cursor_pos

            # Search backwards from the cursor for the most recent
            # occurrence of the flagged word -- this is where it's
            # overwhelmingly most likely to still be, since the whole
            # feature only ever flags the word that was JUST completed,
            # right before the cursor's current vicinity.
            search_region = live_text[:live_cursor]
            found_at = search_region.rfind(word)

            if found_at == -1:
                log.warning(
                    "Could not find %r in the current live text near "
                    "the cursor -- the document may have changed since "
                    "the popup was shown. Doing nothing rather than "
                    "guessing at a position and risking corruption.",
                    word,
                )
            else:
                word_len = len(word)

                # COSMETIC FIX (found via real-machine testing): a
                # misspelled word sitting between two spaces will, by
                # simple arithmetic, leave two adjacent spaces behind
                # once it's deleted and the replacement is inserted in
                # its place -- e.g. "is why kate " -> delete "kate" ->
                # "is why  " (note the double space) -> insert "Kate"
                # -> "is why  Kate". This isn't a correctness bug (the
                # right word was found and replaced), just a cosmetic
                # gap real autocorrect systems avoid by consuming one
                # of the two adjacent spaces. We extend the delete
                # region by one character (the trailing space) when
                # both a leading AND trailing space are present around
                # the word, and put exactly one space back after the
                # replacement -- net effect: single spacing preserved,
                # same as if the word had been carefully hand-edited.
                has_leading_space = found_at > 0 and live_text[found_at - 1] == " "
                trailing_space_pos = found_at + word_len
                has_trailing_space = (
                    trailing_space_pos < len(live_text)
                    and live_text[trailing_space_pos] == " "
                )

                if has_leading_space and has_trailing_space:
                    # Consume the trailing space in the delete, then
                    # re-add exactly one space after the replacement
                    # text, collapsing what would otherwise be a double
                    # space down to a single one.
                    offset_from_cursor = -(live_cursor - found_at)
                    self.delete_surrounding_text(offset_from_cursor, word_len + 1)
                    self.commit_text(IBus.Text.new_from_string(chosen + " "))
                else:
                    offset_from_cursor = -(live_cursor - found_at)
                    self.delete_surrounding_text(offset_from_cursor, word_len)
                    self.commit_text(IBus.Text.new_from_string(chosen))
        except Exception:
            log.exception(
                "Exception while replacing %r with %r -- the document "
                "may be in an inconsistent state. This is exactly the "
                "kind of failure real-machine testing needs to confirm "
                "does or doesn't actually happen.",
                word, chosen,
            )
        finally:
            self.hide_lookup_table()
            self._overlay_client.hide()
            self._active_suggestion_word = None
            self._active_suggestion_start = None
            self._active_suggestion_end = None
            self._active_suggestion_list = []

    def _ensure_suggester(self):
        if self._hunspell_suggest_en is not None:
            return
        try:
            from hunspell_suggest import HunspellSuggester
            self._hunspell_suggest_en = HunspellSuggester(dictionary="en_GB")
            self._hunspell_suggest_hu = HunspellSuggester(dictionary="hu_HU")
            log.info("Hunspell suggestion fetchers loaded (en_GB, hu_HU).")
        except Exception:
            log.exception(
                "Failed to load suggestion fetchers. Suggestion popups "
                "disabled, spelling/grammar DETECTION still works."
            )
            self._hunspell_suggest_en = False
            self._hunspell_suggest_hu = False



def main():
    # Real IBus engines conventionally accept an --ibus flag, used when
    # ibus-daemon itself launches the engine (via the <exec> line in the
    # component XML) versus a developer running it manually to watch
    # logs. Behavior is the same either way for this simple engine --
    # we just track it for clarity in the logs.
    launched_by_daemon = "--ibus" in sys.argv
    log.info(
        "Starting LocalGrammarEngine (launched_by_daemon=%s)...",
        launched_by_daemon,
    )
    bus = IBus.Bus()
    if not bus.is_connected():
        log.error(
            "Could not connect to ibus-daemon. Is IBus running? "
            "Try: ibus-daemon -drx"
        )
        sys.exit(1)

    mainloop = GLib.MainLoop()
    bus.connect("disconnected", lambda *_: mainloop.quit())

    factory = IBus.Factory.new(bus.get_connection())
    factory.add_engine("local-grammar-test", LocalGrammarEngine)

    if launched_by_daemon:
        # BUG FIX (found via real-machine testing -- see
        # docs/DEVELOPMENT_LOG.md): this branch previously did nothing
        # but log a message. That was wrong. When ibus-daemon launches
        # us via the component XML's <exec> line, the XML has already
        # told the daemon "this engine lives at D-Bus service name
        # org.freedesktop.IBus.LocalGrammar" -- but nothing actually
        # CLAIMS that service name on the bus until we call
        # bus.request_name() ourselves. Without this call, the daemon's
        # attempt to hand off control to our engine (e.g. via
        # `ibus engine local-grammar-test`) times out waiting for a
        # service that was never actually there to answer, which is
        # exactly the failure observed during testing ("Set global
        # engine failed: Timeout was reached").
        #
        # Confirmed against a real working reference engine
        # (ibus-replace-with-kanji) which follows exactly this pattern:
        # request_name() when launched by the daemon (exec_by_ibus），
        # register_component() only for standalone/manual testing.
        bus.request_name("org.freedesktop.IBus.LocalGrammar", 0)
        log.info(
            "Requested D-Bus name org.freedesktop.IBus.LocalGrammar "
            "(daemon-launched mode). Waiting for activation..."
        )
    else:
        # Standalone testing mode: no component XML involved at all, so
        # we must register the component ourselves for the engine to be
        # discoverable.
        component = IBus.Component.new(
            "org.freedesktop.IBus.LocalGrammar",
            "Local Grammar Checker (test mode)",
            "0.1.0",
            "GPL-3.0",
            "ibus-local-grammar project",
            "https://github.com/",  # placeholder until the user pushes this
            "",
            "ibus-local-grammar",
        )
        engine_desc = IBus.EngineDesc.new(
            "local-grammar-test",
            "Local Grammar (test)",
            "Local spelling/grammar checker -- test mode",
            "en",
            "GPL-3.0",
            "ibus-local-grammar project",
            "",
            "default",
        )
        component.add_engine(engine_desc)
        bus.register_component(component)
        log.info(
            "Engine registered standalone (no component XML needed for "
            "this mode). Switch to it via the IBus input method menu."
        )

    try:
        mainloop.run()
    except KeyboardInterrupt:
        log.info("Stopped by user.")


if __name__ == "__main__":
    main()
