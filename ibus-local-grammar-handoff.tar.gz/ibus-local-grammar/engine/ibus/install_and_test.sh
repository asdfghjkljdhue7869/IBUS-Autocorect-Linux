#!/usr/bin/env bash
# Phase 2 install + test: register the engine with IBus and run it so
# you can switch to it and test real-world underline rendering.
#
# Run this from the project's engine/ibus/ directory.

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

echo "== Checking for required system packages =="
MISSING=()
command -v python3 &> /dev/null || MISSING+=("python3")
python3 -c "import gi; gi.require_version('IBus', '1.0'); from gi.repository import IBus" 2>/dev/null \
    || MISSING+=("gir1.2-ibus-1.0 python3-gi")
command -v hunspell &> /dev/null || MISSING+=("hunspell")
[ -f /usr/share/hunspell/en_GB.dic ] || MISSING+=("hunspell-en-gb")

if [ ${#MISSING[@]} -ne 0 ]; then
    echo "Missing packages detected. Installing: ${MISSING[*]}"
    sudo apt-get install -y "${MISSING[@]}"
else
    echo "All required packages present."
fi

echo ""
echo "== Registering the IBus component (user-local install, no sudo needed) =="
COMPONENT_DIR="$HOME/.local/share/ibus/component"
mkdir -p "$COMPONENT_DIR"

ENGINE_PATH="$SCRIPT_DIR/engine.py"
COMPONENT_FILE="$COMPONENT_DIR/ibus-local-grammar.xml"

sed "s|PLACEHOLDER_EXEC_PATH|/usr/bin/python3 $ENGINE_PATH --ibus|" \
    component_template.xml > "$COMPONENT_FILE"

echo "Component file written to: $COMPONENT_FILE"
cat "$COMPONENT_FILE"

echo ""
echo "== Restarting ibus-daemon so it picks up the new component =="
echo "(This may briefly disrupt other input methods -- that's expected.)"
ibus restart || {
    echo "ibus restart failed or 'ibus' command not found directly -- trying alternate method..."
    killall ibus-daemon 2>/dev/null || true
    sleep 1
    ibus-daemon -drx &
    sleep 2
}

echo ""
echo "== Checking if the engine shows up in IBus's engine list =="
sleep 2
ibus list-engine 2>&1 | grep -i "local" || {
    echo "WARNING: 'local-grammar-test' not found in 'ibus list-engine' output."
    echo "This means the component registration didn't take. Common causes:"
    echo "  - ibus-daemon needs a full restart (try logging out and back in)"
    echo "  - the component XML has a syntax error (check the cat output above)"
    echo "Paste this full output back for debugging."
}

echo ""
echo "== Next steps (manual) =="
echo "1. Open IBus settings (or right-click the keyboard icon in your system"
echo "   tray / panel) and add 'Local Grammar (test)' as an active input method."
echo "2. Switch to it (usually Super+Space or your configured IBus switch key)."
echo "3. Open a text editor (Kate is a good first test -- best IBus support)"
echo "   and type a misspelled word, e.g. 'wrld' instead of 'world'."
echo "4. Report back what you see: does it underline in red? Nothing at all?"
echo ""
echo "IMPORTANT: at this point, ibus-daemon will try to launch the engine"
echo "itself (via the <exec> path in the component XML) when you switch to"
echo "it in step 2 -- you do NOT need to run engine.py manually for this"
echo "to work. ibus-daemon launches it as its own background process."
echo ""
echo "To see live debug logs WHILE you test, open a SEPARATE terminal and run:"
echo "    tail -f ~/.local/share/ibus-local-grammar/engine.log"
echo "This file is written by the engine itself, so it should work"
echo "regardless of how ibus-daemon captures (or doesn't capture) stderr."
echo ""
echo "This script is now done. Go test in your apps, then report back."

