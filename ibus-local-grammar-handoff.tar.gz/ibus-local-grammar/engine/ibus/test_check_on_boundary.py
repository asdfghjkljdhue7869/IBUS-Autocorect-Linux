# -*- encoding: UTF-8 -*-
"""
test_check_on_boundary.py

Automated tests confirming _check_and_show_errors only fires the actual
Hunspell check when a word boundary (space) has just been typed, NOT on
every mid-word keystroke. This behavior change came directly from user
feedback after reviewing live logs that showed checks firing on every
partial keystroke ("w" -> "wr" -> "wrl" -> "wrld").

This also serves as a regression test for a real bug found while writing
these tests: an earlier version of the fix had a leftover unconditional
word-lookup at the top of the function that short-circuited (returned
early) whenever the cursor sat right after a space -- exactly the one
case the new boundary-check logic needed to handle. That dead code has
been removed; these tests would catch it coming back.

Run directly: python3 test_check_on_boundary.py
"""

import sys
import io
import logging
import importlib.util
import os

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
spec = importlib.util.spec_from_file_location(
    "engine", os.path.join(SCRIPT_DIR, "engine.py")
)
engine_module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(engine_module)


def capture_log(fn, *args, **kwargs):
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger = logging.getLogger("ibus-local-grammar")
    old_level = logger.level
    logger.addHandler(handler)
    logger.setLevel(logging.DEBUG)
    try:
        fn(*args, **kwargs)
    finally:
        logger.removeHandler(handler)
        logger.setLevel(old_level)
    return stream.getvalue()


# Each case: (description, text, cursor_pos, should_check)
# should_check: True if we expect a "Checked word" log line to appear,
# False if we expect NO check to have happened (still mid-word).
TEST_CASES = [
    ("Single letter, mid-word", "w", 1, False),
    ("Two letters, mid-word", "wr", 2, False),
    ("Three letters, mid-word", "wrl", 3, False),
    ("Word + trailing space -> boundary just typed, SHOULD check", "wrl ", 4, True),
    ("Valid word + trailing space -> SHOULD check (and find no error)", "hello ", 6, True),
    ("Mid-word in a longer sentence context", "the quick br", 12, False),
    ("Completed word in a longer sentence context", "the quick br ", 13, True),
    ("Cursor at absolute start, no word yet", "", 0, False),
    (
        "Cursor right after TWO spaces -- word before the immediately "
        "preceding space is empty (it's another space), should not check",
        "hello  ", 7, False,
    ),
]


def main():
    eng = engine_module.LocalGrammarEngine()
    eng._ensure_checkers()

    passed = 0
    failed = 0

    for description, text, cursor_pos, should_check in TEST_CASES:
        log_output = capture_log(eng._check_and_show_errors, text, cursor_pos)
        did_check = "Checked word" in log_output

        ok = (did_check == should_check)
        status = "PASS" if ok else "FAIL"
        if ok:
            passed += 1
        else:
            failed += 1

        print(f"[{status}] {description}")
        if not ok:
            print(f"       text={text!r} cursor={cursor_pos}")
            print(f"       expected check={should_check}, got check={did_check}")
            print(f"       log output: {log_output.strip()!r}")
        print()

    print(f"== Summary: {passed} passed, {failed} failed out of {len(TEST_CASES)} ==")
    if failed > 0:
        sys.exit(1)


if __name__ == "__main__":
    main()
