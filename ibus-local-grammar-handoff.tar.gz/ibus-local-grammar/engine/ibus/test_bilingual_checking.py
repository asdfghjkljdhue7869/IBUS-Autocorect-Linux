# -*- encoding: UTF-8 -*-
"""
test_bilingual_checking.py

Integration tests confirming _check_and_show_errors correctly routes
words to the right dictionary based on language detection, including
the genuinely ambiguous cross-language cases and sentence-context
tie-breaking, end to end through the real function (not just testing
language_detect.py in isolation).

Run directly: python3 test_bilingual_checking.py
"""

import sys
import io
import logging
import importlib.util
import os

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(SCRIPT_DIR, "..", "hungarian"))

spec = importlib.util.spec_from_file_location(
    "engine", os.path.join(SCRIPT_DIR, "engine.py")
)
engine_module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(engine_module)


def capture_log(fn, *args, **kwargs):
    stream = io.StringIO()
    handler = logging.StreamHandler(stream)
    handler.setLevel(logging.DEBUG)
    logger = logging.getLogger("ibus-local-grammar")
    old_level = logger.level
    logger.addHandler(handler)
    logger.setLevel(logging.DEBUG)
    try:
        fn(*args, **kwargs)
    finally:
        logger.removeHandler(handler)
        logger.setLevel(old_level)
    return stream.getvalue()


def main():
    eng = engine_module.LocalGrammarEngine()
    eng._ensure_checkers()

    passed = 0
    failed = 0

    def check(description, text, cursor_pos, expect_lang=None, expect_flagged=None):
        nonlocal passed, failed
        log_output = capture_log(eng._check_and_show_errors, text, cursor_pos)

        ok = True
        reasons = []

        if expect_lang is not None:
            if f"lang={expect_lang}" not in log_output:
                ok = False
                reasons.append(f"expected lang={expect_lang} not found in log")

        if expect_flagged is not None:
            # UPDATED: _show_underline used to only log "Would flag
            # misspelled word" (the old detection-only stub). It now
            # actually shows a real suggestion popup (see Entry 20+ /
            # test_suggestion_popup.py for dedicated tests of that
            # behavior) -- "Checked word ... -> valid: False" is the
            # correct, current signal that a word was flagged as
            # misspelled, independent of what _show_underline does with
            # that information downstream.
            was_flagged = "-> valid: False" in log_output
            if was_flagged != expect_flagged:
                ok = False
                reasons.append(
                    f"expected flagged={expect_flagged}, got flagged={was_flagged}"
                )

        status = "PASS" if ok else "FAIL"
        if ok:
            passed += 1
        else:
            failed += 1
        print(f"[{status}] {description}")
        if not ok:
            print(f"       reasons: {reasons}")
            print(f"       log: {log_output.strip()!r}")
        print()

    # Pure English sentence -- every word should resolve to English.
    check(
        "Pure English word, clean spelling",
        "hello world ", 12,
        expect_lang="en", expect_flagged=False,
    )

    # Pure Hungarian word, clean spelling.
    check(
        "Pure Hungarian word ('kutya' = dog), clean spelling",
        "kutya ", 6,
        expect_lang="hu", expect_flagged=False,
    )

    # Reset context between independent test calls -- otherwise leftover
    # state from previous calls in this same script would bleed across
    # test cases that are meant to be independent.
    eng._lang_context.reset_for_new_sentence()

    # Misspelled English word.
    check(
        "Misspelled English word",
        "wrld ", 5,
        expect_lang="en", expect_flagged=True,
    )

    eng._lang_context.reset_for_new_sentence()

    # The genuinely ambiguous case: "van" with English context before it.
    # IMPORTANT: must drive this WORD BY WORD, matching how real typing
    # actually works -- each completed word triggers its own check and
    # its own context-vote update. Calling the function once on the
    # whole finished sentence (as an earlier draft of this test did)
    # skips that incremental accumulation and was a bug in the TEST,
    # not the engine -- caught by checking the resulting context stats
    # directly and seeing they were still zero.
    capture_log(eng._check_and_show_errors, "I ", 2)
    capture_log(eng._check_and_show_errors, "I bought ", 9)
    capture_log(eng._check_and_show_errors, "I bought a ", 11)
    check(
        "'van' (English/Hungarian homograph) after English context "
        "-> should resolve English, and since 'van' IS a real English "
        "word (a vehicle), should NOT be flagged",
        "I bought a van ", 15,
        expect_lang="en", expect_flagged=False,
    )

    eng._lang_context.reset_for_new_sentence()

    # The same ambiguous word, but with Hungarian context before it.
    # Same fix applied: drive word by word.
    capture_log(eng._check_and_show_errors, "A ", 2)
    capture_log(eng._check_and_show_errors, "A kutya ", 8)
    capture_log(eng._check_and_show_errors, "A kutya itt ", 12)
    check(
        "'van' after Hungarian context -> should resolve Hungarian, "
        "and since 'van' IS a real Hungarian word (3rd person 'is'), "
        "should NOT be flagged",
        "A kutya itt van ", 16,
        expect_lang="hu", expect_flagged=False,
    )

    eng.close = lambda: None  # engine has no close(); avoid AttributeError if called
    eng._hunspell_en.close()
    eng._hunspell_hu.close()

    print(f"== Summary: {passed} passed, {failed} failed out of {passed + failed} ==")
    if failed > 0:
        sys.exit(1)


if __name__ == "__main__":
    main()
