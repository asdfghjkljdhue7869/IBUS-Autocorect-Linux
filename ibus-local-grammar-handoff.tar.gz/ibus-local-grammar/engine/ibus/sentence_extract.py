# -*- encoding: UTF-8 -*-
"""
sentence_extract.py

Extracts "the current sentence" from surrounding text + cursor position,
for feeding to grammar checkers (LanguageTool, the Hungarian engine).
This is the text from the last sentence-ending punctuation (. ! ?) up
to the cursor -- the sentence currently being written/just finished.

Kept as its own small, independently-tested module rather than buried
inline in engine.py, since engine.py is already accumulating real
complexity and this piece of logic (pure string manipulation, no IBus
dependency at all) deserves to be testable in total isolation.
"""

SENTENCE_ENDERS = ".!?"


def extract_current_sentence(text, cursor_pos):
    """
    Returns (sentence, sentence_start) where `sentence` is the text from
    just after the last sentence-ending punctuation before cursor_pos
    (or the very start of `text` if there is none) up to cursor_pos, and
    `sentence_start` is that starting index within `text`.

    Leading whitespace right after the sentence-ending punctuation is
    stripped, since "Hello. World" shouldn't yield " World" with an
    awkward leading space when checking the second sentence.

    Examples:
        extract_current_sentence("Hello world", 11) -> ("Hello world", 0)
        extract_current_sentence("Hi. How are you", 15) -> ("How are you", 4)
        extract_current_sentence("Hi. ", 4) -> ("", 4)
    """
    before_cursor = text[:cursor_pos]

    last_ender_pos = -1
    for i, ch in enumerate(before_cursor):
        if ch in SENTENCE_ENDERS:
            last_ender_pos = i

    sentence_start = last_ender_pos + 1
    # Skip whitespace right after the sentence-ender.
    while sentence_start < len(before_cursor) and before_cursor[sentence_start].isspace():
        sentence_start += 1

    sentence = before_cursor[sentence_start:cursor_pos]
    return sentence, sentence_start


def count_words(sentence):
    """
    Simple whitespace-based word count, used to decide whether a
    sentence has "enough" content to be worth a grammar check yet (a
    single word isn't really a sentence to grammar-check, even though
    it might be a fine candidate for a spelling check).
    """
    return len([w for w in sentence.split() if w])
