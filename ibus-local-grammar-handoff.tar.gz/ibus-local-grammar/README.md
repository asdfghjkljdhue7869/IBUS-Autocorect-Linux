# ibus-local-grammar

An OS-wide, fully local, privacy-respecting grammar and spell checker for Linux,
built as a custom IBus input engine. No cloud calls, no telemetry, no AI model
dependency for the core checking (LanguageTool's rule-based engine + Hunspell).

Inspired by wanting a Grammarly/Gboard-like experience without proprietary,
closed-source, cloud-dependent software.

## Status: early development (Phase 1 of 7)

This is being built incrementally and documented honestly as it goes,
including the parts that don't work yet. See `docs/KNOWN_ISSUES.md`.

## Target environment

Originally built and tested on:
- Linux Mint 22.3 (Ubuntu 24.04 LTS base)
- KDE Plasma 5.27.12
- Brave browser (.deb)

Plasma 6 portability is a goal but not yet validated -- see Known Issues.

## Architecture

```
┌─────────────────┐      ┌──────────────────────┐      ┌─────────────────┐
│   IBus engine    │◄────►│  Hunspell / enchant   │      │  Plasma theme    │
│  (Python, GObject│      │  (spelling, en_GB +   │      │  (accent color   │
│   IBus.Engine)   │      │   hu_HU + slang dicts)│      │  read at runtime)│
└────────┬─────────┘      └──────────────────────┘      └────────┬────────┘
         │                                                        │
         │           ┌──────────────────────┐                    │
         └──────────►│  LanguageTool server  │◄───────────────────┘
                      │  (local HTTP, JVM,    │   underline color
                      │   grammar checking)   │   sourced from here
                      └──────────────────────┘
```

The IBus engine is the OS-wide hook -- any app with IBus input support gets
spelling/grammar underlines drawn using IBus's native pre-edit underline
attribute, colored to match your current Plasma accent color.

## Power modes

- **Active mode**: LanguageTool server running, full grammar + spelling checks.
- **Low-power mode**: LanguageTool server stopped, spelling-only via Hunspell
  (near-zero resource cost). Auto-engages on battery / low battery via UPower,
  or toggle manually.

## Build phases

1. ✅ (in progress) LanguageTool server standalone, manually verified
2. ⬜ Minimal IBus engine -- spelling underline only, proof of concept
3. ⬜ Live Plasma accent color theming
4. ⬜ LanguageTool grammar integration (debounced)
5. ⬜ Hungarian + slang dictionaries
6. ⬜ Active/low-power toggle + battery awareness
7. ⬜ Packaging (systemd user service, tray toggle)

## License

GPL-3.0 -- see `LICENSE`. Forks and derivatives welcome.

## Why this exists instead of using Grammarly/Gboard

Those are closed-source and require sending your text to a remote server.
This project trades some accuracy and polish for being fully local and
auditable. See `docs/KNOWN_ISSUES.md` for an honest comparison of where
this currently falls short of those products.
